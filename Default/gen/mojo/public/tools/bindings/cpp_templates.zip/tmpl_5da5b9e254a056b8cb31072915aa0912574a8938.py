from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'struct_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_serialize = l_0_deserialize = l_0_assert_nullable_output_type_if_necessary = missing
    t_1 = environment.filters['format']
    t_2 = environment.filters['get_container_validate_params_ctor_args']
    t_3 = environment.filters['indent']
    t_4 = environment.filters['is_any_handle_kind']
    t_5 = environment.filters['is_any_handle_or_interface_kind']
    t_6 = environment.filters['is_any_interface_kind']
    t_7 = environment.filters['is_array_kind']
    t_8 = environment.filters['is_associated_kind']
    t_9 = environment.filters['is_enum_kind']
    t_10 = environment.filters['is_map_kind']
    t_11 = environment.filters['is_native_only_kind']
    t_12 = environment.filters['is_nullable_kind']
    t_13 = environment.filters['is_object_kind']
    t_14 = environment.filters['is_union_kind']
    t_15 = environment.filters['under_to_camel']
    t_16 = environment.filters['unmapped_type_for_serializer']
    pass
    yield '\n\n'
    def macro(l_1_struct, l_1_struct_display_name, l_1_input_field_pattern, l_1_fragment, l_1_input_may_be_temp):
        t_17 = []
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        if l_1_struct_display_name is missing:
            l_1_struct_display_name = undefined("parameter 'struct_display_name' was not provided", name='struct_display_name')
        if l_1_input_field_pattern is missing:
            l_1_input_field_pattern = undefined("parameter 'input_field_pattern' was not provided", name='input_field_pattern')
        if l_1_fragment is missing:
            l_1_fragment = undefined("parameter 'fragment' was not provided", name='fragment')
        if l_1_input_may_be_temp is missing:
            l_1_input_may_be_temp = False
        pass
        t_17.extend((
            to_string(l_1_fragment),
            '.Allocate();',
        ))
        for l_2_pf in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields_in_ordinal_order'):
            l_2_original_input_field = resolve('original_input_field')
            l_2_input_field = l_2_name = l_2_kind = l_2_serializer_type = missing
            pass
            l_2_input_field = t_1(l_1_input_field_pattern, environment.getattr(environment.getattr(l_2_pf, 'field'), 'name'))
            l_2_name = environment.getattr(environment.getattr(l_2_pf, 'field'), 'name')
            l_2_kind = environment.getattr(environment.getattr(l_2_pf, 'field'), 'kind')
            l_2_serializer_type = t_16((undefined(name='kind') if l_2_kind is missing else l_2_kind))
            if (t_13((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_5((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                pass
                l_2_original_input_field = t_1(l_1_input_field_pattern, (undefined(name='name') if l_2_name is missing else l_2_name))
                l_2_input_field = (t_1('in_%s', (undefined(name='name') if l_2_name is missing else l_2_name)) if l_1_input_may_be_temp else (undefined(name='original_input_field') if l_2_original_input_field is missing else l_2_original_input_field))
                if l_1_input_may_be_temp:
                    pass
                    t_17.extend((
                        '\n  decltype(',
                        to_string((undefined(name='original_input_field') if l_2_original_input_field is missing else l_2_original_input_field)),
                        ') in_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ' = ',
                        to_string((undefined(name='original_input_field') if l_2_original_input_field is missing else l_2_original_input_field)),
                        ';',
                    ))
            if t_13((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                pass
                if (t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_10((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    t_17.extend((
                        '\n  mojo::internal::MessageFragment<\n      typename decltype(',
                        to_string(l_1_fragment),
                        '->',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ')::BaseType>\n      ',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '_fragment(',
                        to_string(l_1_fragment),
                        '.message());\n  const mojo::internal::ContainerValidateParams ',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '_validate_params(\n      ',
                        to_string(t_3(t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind)), 10)),
                        ');\n  mojo::internal::Serialize<',
                        to_string((undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type)),
                        '>(\n      ',
                        to_string((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                        ', ',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '_fragment, &',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '_validate_params);\n  ',
                        to_string(l_1_fragment),
                        '->',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '.Set(\n      ',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '_fragment.is_null() ? nullptr : ',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '_fragment.data());',
                    ))
                elif t_14((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_17.extend((
                        '\n  mojo::internal::MessageFragment<decltype(',
                        to_string(l_1_fragment),
                        '->',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ')>\n      ',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '_fragment(',
                        to_string(l_1_fragment),
                        '.message());\n  ',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '_fragment.Claim(&',
                        to_string(l_1_fragment),
                        '->',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n  mojo::internal::Serialize<',
                        to_string((undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type)),
                        '>(\n      ',
                        to_string((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                        ', ',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '_fragment, true);',
                    ))
                else:
                    pass
                    t_17.extend((
                        '\n  mojo::internal::MessageFragment<\n      typename decltype(',
                        to_string(l_1_fragment),
                        '->',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ')::BaseType> ',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '_fragment(\n          ',
                        to_string(l_1_fragment),
                        '.message());\n  mojo::internal::Serialize<',
                        to_string((undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type)),
                        '>(\n      ',
                        to_string((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                        ', ',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '_fragment);\n  ',
                        to_string(l_1_fragment),
                        '->',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '.Set(\n      ',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '_fragment.is_null() ? nullptr : ',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '_fragment.data());',
                    ))
                if (not t_12((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    t_17.extend((
                        '\n  MOJO_INTERNAL_DLOG_SERIALIZATION_WARNING(\n      ',
                        to_string(l_1_fragment),
                        '->',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '.is_null(),\n      mojo::internal::VALIDATION_ERROR_UNEXPECTED_NULL_POINTER,\n      "null ',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ' in ',
                        to_string(l_1_struct_display_name),
                        '");',
                    ))
            elif t_5((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                pass
                t_17.extend((
                    '\n  mojo::internal::Serialize<',
                    to_string((undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type)),
                    '>(\n      ',
                    to_string((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                    ', &',
                    to_string(l_1_fragment),
                    '->',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ', &',
                    to_string(l_1_fragment),
                    '.message());',
                ))
                if (not t_12((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    t_17.extend((
                        '\n  MOJO_INTERNAL_DLOG_SERIALIZATION_WARNING(\n      !mojo::internal::IsHandleOrInterfaceValid(',
                        to_string(l_1_fragment),
                        '->',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '),',
                    ))
                    if t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                        pass
                        t_17.append(
                            '\n      mojo::internal::VALIDATION_ERROR_UNEXPECTED_INVALID_INTERFACE_ID,',
                        )
                    else:
                        pass
                        t_17.append(
                            '\n      mojo::internal::VALIDATION_ERROR_UNEXPECTED_INVALID_HANDLE,',
                        )
                    t_17.extend((
                        '\n      "invalid ',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ' in ',
                        to_string(l_1_struct_display_name),
                        '");',
                    ))
            elif t_9((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                pass
                t_17.extend((
                    '\n  mojo::internal::Serialize<',
                    to_string((undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type)),
                    '>(\n      ',
                    to_string((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                    ', &',
                    to_string(l_1_fragment),
                    '->',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ');',
                ))
            else:
                pass
                t_17.extend((
                    '\n  ',
                    to_string(l_1_fragment),
                    '->',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ' = ',
                    to_string((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                    ';',
                ))
        l_2_pf = l_2_input_field = l_2_name = l_2_kind = l_2_serializer_type = l_2_original_input_field = missing
        return concat(t_17)
    context.exported_vars.add('serialize')
    context.vars['serialize'] = l_0_serialize = Macro(environment, macro, 'serialize', ('struct', 'struct_display_name', 'input_field_pattern', 'fragment', 'input_may_be_temp'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_struct, l_1_input, l_1_output_field_pattern, l_1_success):
        t_18 = []
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        if l_1_input is missing:
            l_1_input = undefined("parameter 'input' was not provided", name='input')
        if l_1_output_field_pattern is missing:
            l_1_output_field_pattern = undefined("parameter 'output_field_pattern' was not provided", name='output_field_pattern')
        if l_1_success is missing:
            l_1_success = undefined("parameter 'success' was not provided", name='success')
        pass
        for l_2_pf in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields_in_ordinal_order'):
            l_2_output_field = l_2_name = l_2_kind = missing
            pass
            l_2_output_field = t_1(l_1_output_field_pattern, environment.getattr(environment.getattr(l_2_pf, 'field'), 'name'))
            l_2_name = environment.getattr(environment.getattr(l_2_pf, 'field'), 'name')
            l_2_kind = environment.getattr(environment.getattr(l_2_pf, 'field'), 'kind')
            if (t_13((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_9((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                pass
                t_18.extend((
                    '\n  if (',
                    to_string(l_1_success),
                    ' && !',
                    to_string(l_1_input),
                    '.Read',
                    to_string(t_15((undefined(name='name') if l_2_name is missing else l_2_name))),
                    '(&',
                    to_string((undefined(name='output_field') if l_2_output_field is missing else l_2_output_field)),
                    '))\n    ',
                    to_string(l_1_success),
                    ' = false;',
                ))
            elif t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                pass
                t_18.extend((
                    '\n  if (',
                    to_string(l_1_success),
                    ')\n    ',
                    to_string((undefined(name='output_field') if l_2_output_field is missing else l_2_output_field)),
                    ' = ',
                    to_string(l_1_input),
                    '.Take',
                    to_string(t_15((undefined(name='name') if l_2_name is missing else l_2_name))),
                    '();',
                ))
            elif t_6((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                pass
                t_18.extend((
                    '\n  if (',
                    to_string(l_1_success),
                    ') {\n    ',
                    to_string((undefined(name='output_field') if l_2_output_field is missing else l_2_output_field)),
                    ' =\n        ',
                    to_string(l_1_input),
                    '.Take',
                    to_string(t_15((undefined(name='name') if l_2_name is missing else l_2_name))),
                    '<decltype(',
                    to_string((undefined(name='output_field') if l_2_output_field is missing else l_2_output_field)),
                    ')>();\n  }',
                ))
            else:
                pass
                t_18.extend((
                    '\n  if (',
                    to_string(l_1_success),
                    ')\n    ',
                    to_string((undefined(name='output_field') if l_2_output_field is missing else l_2_output_field)),
                    ' = ',
                    to_string(l_1_input),
                    '.',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    '();',
                ))
        l_2_pf = l_2_output_field = l_2_name = l_2_kind = missing
        return concat(t_18)
    context.exported_vars.add('deserialize')
    context.vars['deserialize'] = l_0_deserialize = Macro(environment, macro, 'deserialize', ('struct', 'input', 'output_field_pattern', 'success'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_kind, l_1_name):
        t_19 = []
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (t_12(l_1_kind) and (not t_11(l_1_kind))):
            pass
            t_19.extend((
                '\nstatic_assert(\n    mojo::internal::IsValidUserTypeForOptionalValue<\n        ',
                to_string(t_16(l_1_kind)),
                ', UserType>(),\n    "Attempting to read the optional `',
                to_string(l_1_name),
                '` field into a type which "\n    "cannot represent a null value. Either wrap the destination object "\n    "with absl::optional, ensure that any corresponding "\n    "{Struct/Union/Array/String}Traits define the necessary IsNull and "\n    "SetToNull methods, or use `MaybeRead',
                to_string(t_15(l_1_name)),
                '` instead "\n    "of `Read',
                to_string(t_15(l_1_name)),
                ' if you\'re fine with null values being "\n    "silently ignored in this case.");',
            ))
        return concat(t_19)
    context.exported_vars.add('assert_nullable_output_type_if_necessary')
    context.vars['assert_nullable_output_type_if_necessary'] = l_0_assert_nullable_output_type_if_necessary = Macro(environment, macro, 'assert_nullable_output_type_if_necessary', ('kind', 'name'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '17=29&19=43&20=46&21=50&22=51&23=52&24=53&26=54&27=56&28=57&30=58&31=62&35=69&36=71&38=75&39=79&40=83&41=85&42=87&43=89&44=95&45=99&46=104&47=108&48=112&49=116&50=122&51=124&54=133&55=139&56=141&57=143&58=147&59=151&61=156&63=160&65=164&68=169&69=173&70=175&71=184&73=188&74=193&79=205&82=210&83=214&84=216&87=227&106=238&107=249&108=252&109=253&110=254&111=255&112=259&113=267&114=270&115=274&116=276&117=283&118=287&119=289&120=291&123=302&124=304&129=315&130=322&133=326&134=328&138=330&139=332'