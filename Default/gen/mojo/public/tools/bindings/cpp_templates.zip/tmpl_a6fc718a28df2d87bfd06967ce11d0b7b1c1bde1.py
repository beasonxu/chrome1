from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'wrapper_union_class_template_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    t_1 = environment.filters['is_any_handle_or_interface_kind']
    t_2 = environment.filters['is_object_kind']
    t_3 = environment.filters['under_to_camel']
    pass
    yield 'template <typename UnionPtrType>\n'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'Ptr '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::Clone() const {\n  switch (tag_) {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        pass
        yield '\n    case Tag::k'
        yield to_string(t_3(environment.getattr(l_1_field, 'name')))
        yield ':'
        if (t_2(environment.getattr(l_1_field, 'kind')) or t_1(environment.getattr(l_1_field, 'kind'))):
            pass
            yield '\n      return New'
            yield to_string(t_3(environment.getattr(l_1_field, 'name')))
            yield '(\n          mojo::Clone(*data_.'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield '));'
        else:
            pass
            yield '\n      return New'
            yield to_string(t_3(environment.getattr(l_1_field, 'name')))
            yield '(\n          mojo::Clone(data_.'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield '));'
    l_1_field = missing
    yield '\n  }\n  return nullptr;\n}\n\ntemplate <typename T,\n          typename std::enable_if<std::is_same<\n              T, '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '>::value>::type*>\nbool '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::Equals(const T& other) const {\n  if (tag_ != other.which())\n    return false;\n\n  switch (tag_) {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        pass
        yield '\n    case Tag::k'
        yield to_string(t_3(environment.getattr(l_1_field, 'name')))
        yield ':'
        if (t_2(environment.getattr(l_1_field, 'kind')) or t_1(environment.getattr(l_1_field, 'kind'))):
            pass
            yield '\n      return mojo::Equals(*(data_.'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield '), *(other.data_.'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield '));'
        else:
            pass
            yield '\n      return mojo::Equals(data_.'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ', other.data_.'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ');'
    l_1_field = missing
    yield '\n  }\n\n  return false;\n}'

blocks = {}
debug_info = '2=16&4=20&5=23&6=25&8=28&9=30&11=35&12=37&21=41&22=43&27=45&28=48&29=50&31=53&33=60'