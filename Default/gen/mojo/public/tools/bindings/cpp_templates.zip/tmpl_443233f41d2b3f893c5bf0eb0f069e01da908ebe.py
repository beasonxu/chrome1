from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'module.cc.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_variant = resolve('variant')
    l_0_module = resolve('module')
    l_0_variant_path = resolve('variant_path')
    l_0_for_blink = resolve('for_blink')
    l_0_extra_traits_headers = resolve('extra_traits_headers')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_interfaces = resolve('interfaces')
    l_0_header_guard_for_jumbo = l_0_namespace_begin = l_0_namespace_end = l_0_interface_macros = missing
    t_1 = environment.filters['constant_value']
    t_2 = environment.filters['cpp_pod_type']
    t_3 = environment.filters['cpp_wrapper_call_type']
    t_4 = environment.filters['cpp_wrapper_param_type']
    t_5 = environment.filters['format']
    t_6 = environment.filters['is_native_only_kind']
    t_7 = environment.filters['is_string_kind']
    t_8 = environment.filters['replace']
    t_9 = environment.filters['reverse']
    t_10 = environment.filters['upper']
    pass
    yield '// Copyright 2013 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
        pass
        l_0_variant_path = t_5('%s-%s', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant))
        context.vars['variant_path'] = l_0_variant_path
        context.exported_vars.add('variant_path')
    else:
        pass
        l_0_variant_path = environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path')
        context.vars['variant_path'] = l_0_variant_path
        context.exported_vars.add('variant_path')
    l_0_header_guard_for_jumbo = t_5('%s_JUMBO_H_', t_8(context.eval_ctx, t_8(context.eval_ctx, t_8(context.eval_ctx, t_10((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path)), '/', '_'), '.', '_'), '-', '_'))
    context.vars['header_guard_for_jumbo'] = l_0_header_guard_for_jumbo
    context.exported_vars.add('header_guard_for_jumbo')
    yield '\n\n#if defined(__clang__)\n#pragma clang diagnostic push\n#pragma clang diagnostic ignored "-Wunused-private-field"\n#endif\n\n#include "'
    yield to_string((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path))
    yield '.h"\n\n#include <math.h>\n#include <stdint.h>\n#include <utility>\n\n#include "base/debug/alias.h"\n#include "base/hash/md5_constexpr.h"\n#include "base/run_loop.h"\n#include "base/strings/string_number_conversions.h"\n#include "base/trace_event/trace_event.h"\n#include "base/trace_event/typed_macros.h"\n#include "mojo/public/cpp/bindings/lib/generated_code_util.h"\n#include "mojo/public/cpp/bindings/lib/message_internal.h"\n#include "mojo/public/cpp/bindings/lib/send_message_helper.h"\n#include "mojo/public/cpp/bindings/lib/proxy_to_responder.h"\n#include "mojo/public/cpp/bindings/lib/serialization_util.h"\n#include "mojo/public/cpp/bindings/lib/unserialized_message_context.h"\n#include "mojo/public/cpp/bindings/lib/validate_params.h"\n#include "mojo/public/cpp/bindings/lib/validation_errors.h"\n#include "mojo/public/cpp/bindings/mojo_buildflags.h"\n#include "mojo/public/interfaces/bindings/interface_control_messages.mojom.h"\n#include "third_party/perfetto/include/perfetto/tracing/traced_value.h"\n\n#include "'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-params-data.h"\n#include "'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-shared-message-ids.h"\n\n#include "'
    yield to_string((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path))
    yield '-import-headers.h"\n#include "'
    yield to_string((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path))
    yield '-test-utils.h"'
    if (undefined(name='for_blink') if l_0_for_blink is missing else l_0_for_blink):
        pass
        yield '\n#include "mojo/public/cpp/bindings/lib/wtf_serialization.h"'
    yield '\n\n\n#ifndef '
    yield to_string((undefined(name='header_guard_for_jumbo') if l_0_header_guard_for_jumbo is missing else l_0_header_guard_for_jumbo))
    yield '\n#define '
    yield to_string((undefined(name='header_guard_for_jumbo') if l_0_header_guard_for_jumbo is missing else l_0_header_guard_for_jumbo))
    for l_1_header in (undefined(name='extra_traits_headers') if l_0_extra_traits_headers is missing else l_0_extra_traits_headers):
        pass
        yield '\n#include "'
        yield to_string(l_1_header)
        yield '"'
    l_1_header = missing
    yield '\n#endif'
    def macro():
        t_11 = []
        l_1_namespaces_as_array = resolve('namespaces_as_array')
        pass
        for l_2_namespace in (undefined(name='namespaces_as_array') if l_1_namespaces_as_array is missing else l_1_namespaces_as_array):
            pass
            t_11.extend((
                '\nnamespace ',
                to_string(l_2_namespace),
                ' {',
            ))
        l_2_namespace = missing
        if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
            pass
            t_11.extend((
                '\nnamespace ',
                to_string((undefined(name='variant') if l_0_variant is missing else l_0_variant)),
                ' {',
            ))
        return concat(t_11)
    context.exported_vars.add('namespace_begin')
    context.vars['namespace_begin'] = l_0_namespace_begin = Macro(environment, macro, 'namespace_begin', (), False, False, False, context.eval_ctx.autoescape)
    def macro():
        t_12 = []
        l_1_namespaces_as_array = resolve('namespaces_as_array')
        pass
        if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
            pass
            t_12.extend((
                '\n}  // namespace ',
                to_string((undefined(name='variant') if l_0_variant is missing else l_0_variant)),
            ))
        for l_2_namespace in t_9((undefined(name='namespaces_as_array') if l_1_namespaces_as_array is missing else l_1_namespaces_as_array)):
            pass
            t_12.extend((
                '\n}  // namespace ',
                to_string(l_2_namespace),
            ))
        l_2_namespace = missing
        return concat(t_12)
    context.exported_vars.add('namespace_end')
    context.vars['namespace_end'] = l_0_namespace_end = Macro(environment, macro, 'namespace_end', (), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n\n'
    yield to_string(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin)))
    for l_1_constant in environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'):
        pass
        if t_7(environment.getattr(l_1_constant, 'kind')):
            pass
            yield '\nconst char '
            yield to_string(environment.getattr(l_1_constant, 'name'))
            yield '[] = '
            yield to_string(t_1(l_1_constant))
            yield ';'
    l_1_constant = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        for l_2_constant in environment.getattr(l_1_struct, 'constants'):
            pass
            if t_7(environment.getattr(l_2_constant, 'kind')):
                pass
                yield '\nconst char '
                yield to_string(environment.getattr(l_1_struct, 'name'))
                yield '::'
                yield to_string(environment.getattr(l_2_constant, 'name'))
                yield '[] = '
                yield to_string(t_1(l_2_constant))
                yield ';'
            else:
                pass
                yield '\nconstexpr '
                yield to_string(t_2(environment.getattr(l_2_constant, 'kind')))
                yield ' '
                yield to_string(environment.getattr(l_1_struct, 'name'))
                yield '::'
                yield to_string(environment.getattr(l_2_constant, 'name'))
                yield ';'
        l_2_constant = missing
    l_1_struct = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        if (not t_6(l_1_struct)):
            pass
            template = environment.get_template('wrapper_class_definition.tmpl', 'module.cc.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'header_guard_for_jumbo': l_0_header_guard_for_jumbo, 'interface_macros': l_0_interface_macros, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'struct': l_1_struct, 'variant_path': l_0_variant_path})):
                yield event
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        template = environment.get_template('wrapper_union_class_definition.tmpl', 'module.cc.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'header_guard_for_jumbo': l_0_header_guard_for_jumbo, 'interface_macros': l_0_interface_macros, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'union': l_1_union, 'variant_path': l_0_variant_path})):
            yield event
    l_1_union = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        template = environment.get_template('interface_definition.tmpl', 'module.cc.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'header_guard_for_jumbo': l_0_header_guard_for_jumbo, 'interface': l_1_interface, 'interface_macros': l_0_interface_macros, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
            yield event
    l_1_interface = missing
    yield '\n\n'
    yield to_string(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end)))
    yield '\n\n\nnamespace mojo {'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        if (not t_6(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('struct_traits_definition.tmpl', 'module.cc.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'header_guard_for_jumbo': l_0_header_guard_for_jumbo, 'interface_macros': l_0_interface_macros, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'struct': l_1_struct, 'variant_path': l_0_variant_path})):
                yield event
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        template = environment.get_template('union_traits_definition.tmpl', 'module.cc.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'header_guard_for_jumbo': l_0_header_guard_for_jumbo, 'interface_macros': l_0_interface_macros, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'union': l_1_union, 'variant_path': l_0_variant_path})):
            yield event
    l_1_union = missing
    yield '\n\n}  // namespace mojo\n\n\n// Symbols declared in the -test-utils.h header are defined here instead of a\n// separate .cc file to save compile time.\n\n'
    yield to_string(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin)))
    l_0_interface_macros = context.vars['interface_macros'] = environment.get_template('interface_macros.tmpl', 'module.cc.tmpl')._get_default_module()
    context.exported_vars.discard('interface_macros')
    yield '\n\n'
    l_1_loop = missing
    for l_1_interface, l_1_loop in LoopContext((undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces), undefined):
        pass
        l_2_loop = missing
        for l_2_method, l_2_loop in LoopContext(environment.getattr(l_1_interface, 'methods'), undefined):
            pass
            yield '\nvoid '
            yield to_string(environment.getattr(l_1_interface, 'name'))
            yield 'InterceptorForTesting::'
            yield to_string(environment.getattr(l_2_method, 'name'))
            yield '('
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_request_params'), '', l_2_method))
            yield ') {\n  GetForwardingInterface()->'
            yield to_string(environment.getattr(l_2_method, 'name'))
            yield '('
            l_3_loop = missing
            for l_3_param, l_3_loop in LoopContext(environment.getattr(l_2_method, 'parameters'), undefined):
                pass
                yield 'std::move('
                yield to_string(environment.getattr(l_3_param, 'name'))
                yield ')'
                if (not environment.getattr(l_3_loop, 'last')):
                    pass
                    yield ', '
            l_3_loop = l_3_param = missing
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                if environment.getattr(l_2_method, 'parameters'):
                    pass
                    yield ', '
                yield 'std::move(callback)'
            yield ');\n}'
        l_2_loop = l_2_method = missing
        yield '\n'
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter::'
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter(\n    '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield '* proxy) : proxy_(proxy) {}\n\n'
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter::~'
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter() = default;\n\n'
        def t_13(fiter):
            for l_2_method in fiter:
                if (environment.getattr(l_2_method, 'response_parameters') != None):
                    yield l_2_method
        for l_2_method in t_13(environment.getattr(l_1_interface, 'methods')):
            pass
            yield 'void '
            yield to_string(environment.getattr(l_1_interface, 'name'))
            yield 'AsyncWaiter::'
            yield to_string(environment.getattr(l_2_method, 'name'))
            yield '(\n    '
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_sync_method_params'), '', l_2_method))
            yield ') {\n  base::RunLoop loop;\n  proxy_->'
            yield to_string(environment.getattr(l_2_method, 'name'))
            yield '('
            for l_3_param in environment.getattr(l_2_method, 'parameters'):
                pass
                yield 'std::move('
                yield to_string(environment.getattr(l_3_param, 'name'))
                yield '),'
            l_3_param = missing
            yield '\n      base::BindOnce(\n          [](base::RunLoop* loop'
            for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                pass
                yield ',\n             '
                yield to_string(t_3(environment.getattr(l_3_param, 'kind')))
                yield '* out_'
                yield to_string(environment.getattr(l_3_param, 'name'))
                yield '\n'
            l_3_param = missing
            for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                pass
                yield ',\n             '
                yield to_string(t_4(environment.getattr(l_3_param, 'kind')))
                yield ' '
                yield to_string(environment.getattr(l_3_param, 'name'))
            l_3_param = missing
            yield ') {'
            for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                pass
                yield '*out_'
                yield to_string(environment.getattr(l_3_param, 'name'))
                yield ' = std::move('
                yield to_string(environment.getattr(l_3_param, 'name'))
                yield ');'
            l_3_param = missing
            yield '\n            loop->Quit();\n          },\n          &loop'
            for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                pass
                yield ',\n          out_'
                yield to_string(environment.getattr(l_3_param, 'name'))
            l_3_param = missing
            yield '));\n  loop.Run();\n}\n'
        l_2_method = missing
        yield '\n\n'
    l_1_loop = l_1_interface = missing
    yield '\n\n'
    yield to_string(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end)))
    yield '\n\n\n#if defined(__clang__)\n#pragma clang diagnostic pop\n#endif'

blocks = {}
debug_info = '5=31&6=33&8=38&11=41&20=45&44=47&45=49&47=51&48=53&50=55&55=59&56=61&57=62&58=65&63=69&64=73&65=77&67=81&68=85&72=91&73=95&74=99&76=101&77=105&82=112&85=113&86=115&87=118&92=123&93=125&94=127&95=130&97=139&103=147&104=149&105=151&110=155&111=157&115=161&116=163&119=168&125=170&126=172&127=175&132=179&133=181&142=186&144=187&146=191&149=194&150=197&151=203&152=206&153=209&155=215&156=217&164=224&165=228&167=230&169=234&170=241&171=245&173=247&174=249&175=252&179=256&180=259&182=264&183=267&185=272&186=275&191=281&192=284&200=291'