from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'struct_data_view_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    t_1 = environment.filters['cpp_data_view_type']
    t_2 = environment.filters['is_object_kind']
    t_3 = environment.filters['is_union_kind']
    t_4 = environment.filters['under_to_camel']
    pass
    for l_1_pf in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields_in_ordinal_order'):
        l_1_kind = l_1_name = missing
        pass
        l_1_kind = environment.getattr(environment.getattr(l_1_pf, 'field'), 'kind')
        l_1_name = environment.getattr(environment.getattr(l_1_pf, 'field'), 'name')
        if t_3((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\ninline void '
            yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
            yield 'DataView::Get'
            yield to_string(t_4((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield 'DataView(\n    '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '* output) {'
            if (environment.getattr(l_1_pf, 'min_version') != 0):
                pass
                yield '\n  auto pointer = data_->header_.version >= '
                yield to_string(environment.getattr(l_1_pf, 'min_version'))
                yield '\n                 ? &data_->'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ' : nullptr;'
            else:
                pass
                yield '\n  auto pointer = &data_->'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ';'
            yield '\n  *output = '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '(pointer, message_);\n}'
        elif t_2((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\ninline void '
            yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
            yield 'DataView::Get'
            yield to_string(t_4((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield 'DataView(\n    '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '* output) {'
            if (environment.getattr(l_1_pf, 'min_version') != 0):
                pass
                yield '\n  auto pointer = data_->header_.version >= '
                yield to_string(environment.getattr(l_1_pf, 'min_version'))
                yield '\n                 ? data_->'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '.Get() : nullptr;'
            else:
                pass
                yield '\n  auto pointer = data_->'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '.Get();'
            yield '\n  *output = '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '(pointer, message_);\n}'
    l_1_pf = l_1_kind = l_1_name = missing
    yield '\n'

blocks = {}
debug_info = '1=16&2=19&3=20&5=21&6=24&7=28&8=30&9=33&10=35&12=40&14=43&17=45&18=48&19=52&20=54&21=57&22=59&24=64&26=67'