from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'module-test-utils.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_variant = resolve('variant')
    l_0_module = resolve('module')
    l_0_variant_path = resolve('variant_path')
    l_0_export_header = resolve('export_header')
    l_0_interfaces = resolve('interfaces')
    l_0_header_guard = l_0_namespace_begin = l_0_namespace_end = l_0_interface_macros = missing
    t_1 = environment.filters['format']
    t_2 = environment.filters['replace']
    t_3 = environment.filters['reverse']
    t_4 = environment.filters['upper']
    pass
    yield '// Copyright 2019 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
        pass
        l_0_variant_path = t_1('%s-%s', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant))
        context.vars['variant_path'] = l_0_variant_path
        context.exported_vars.add('variant_path')
    else:
        pass
        l_0_variant_path = environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path')
        context.vars['variant_path'] = l_0_variant_path
        context.exported_vars.add('variant_path')
    l_0_header_guard = t_1('%s_TEST_UTILS_H_', t_2(context.eval_ctx, t_2(context.eval_ctx, t_2(context.eval_ctx, t_4((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path)), '/', '_'), '.', '_'), '-', '_'))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    def macro():
        t_5 = []
        l_1_namespaces_as_array = resolve('namespaces_as_array')
        pass
        for l_2_namespace in (undefined(name='namespaces_as_array') if l_1_namespaces_as_array is missing else l_1_namespaces_as_array):
            pass
            t_5.extend((
                '\nnamespace ',
                to_string(l_2_namespace),
                ' {',
            ))
        l_2_namespace = missing
        if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
            pass
            t_5.extend((
                '\nnamespace ',
                to_string((undefined(name='variant') if l_0_variant is missing else l_0_variant)),
                ' {',
            ))
        return concat(t_5)
    context.exported_vars.add('namespace_begin')
    context.vars['namespace_begin'] = l_0_namespace_begin = Macro(environment, macro, 'namespace_begin', (), False, False, False, context.eval_ctx.autoescape)
    def macro():
        t_6 = []
        l_1_namespaces_as_array = resolve('namespaces_as_array')
        pass
        if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
            pass
            t_6.extend((
                '\n}  // namespace ',
                to_string((undefined(name='variant') if l_0_variant is missing else l_0_variant)),
            ))
        for l_2_namespace in t_3((undefined(name='namespaces_as_array') if l_1_namespaces_as_array is missing else l_1_namespaces_as_array)):
            pass
            t_6.extend((
                '\n}  // namespace ',
                to_string(l_2_namespace),
            ))
        l_2_namespace = missing
        return concat(t_6)
    context.exported_vars.add('namespace_end')
    context.vars['namespace_end'] = l_0_namespace_end = Macro(environment, macro, 'namespace_end', (), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n#ifndef '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include "'
    yield to_string((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path))
    yield '.h"'
    if (undefined(name='export_header') if l_0_export_header is missing else l_0_export_header):
        pass
        yield '\n#include "'
        yield to_string((undefined(name='export_header') if l_0_export_header is missing else l_0_export_header))
        yield '"'
    yield '\n\n'
    yield to_string(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin)))
    l_0_interface_macros = context.vars['interface_macros'] = environment.get_template('interface_macros.tmpl', 'module-test-utils.h.tmpl')._get_default_module()
    context.exported_vars.discard('interface_macros')
    yield '\n\n'
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        l_1_export_attribute = resolve('export_attribute')
        pass
        yield '\nclass '
        yield to_string((undefined(name='export_attribute') if l_1_export_attribute is missing else l_1_export_attribute))
        yield ' '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'InterceptorForTesting : public '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield ' {\n  virtual '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield '* GetForwardingInterface() = 0;'
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            pass
            yield '\n  void '
            yield to_string(environment.getattr(l_2_method, 'name'))
            yield '('
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_request_params'), '', l_2_method))
            yield ') override;'
        l_2_method = missing
        yield '\n};\nclass '
        yield to_string((undefined(name='export_attribute') if l_1_export_attribute is missing else l_1_export_attribute))
        yield ' '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter {\n public:\n  explicit '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter('
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield '* proxy);\n\n  '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter(const '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter&) = delete;\n  '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter& operator=(const '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter&) = delete;\n\n  ~'
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter();'
        def t_7(fiter):
            for l_2_method in fiter:
                if (environment.getattr(l_2_method, 'response_parameters') != None):
                    yield l_2_method
        for l_2_method in t_7(environment.getattr(l_1_interface, 'methods')):
            pass
            yield '\n  void '
            yield to_string(environment.getattr(l_2_method, 'name'))
            yield '(\n      '
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_sync_method_params'), '', l_2_method))
            yield ');'
        l_2_method = missing
        yield '\n\n private:\n  '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield '* const proxy_;\n};\n\n'
    l_1_interface = l_1_export_attribute = missing
    yield '\n\n'
    yield to_string(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end)))
    yield '\n\n#endif  // '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=22&6=24&8=29&11=32&16=35&17=39&18=43&20=47&21=51&25=57&26=61&27=65&29=67&30=71&34=78&35=80&37=82&39=84&40=87&43=90&45=91&47=94&50=98&51=104&53=106&54=109&59=115&61=119&63=123&64=127&66=131&68=133&69=140&70=142&74=146&79=150&81=152'