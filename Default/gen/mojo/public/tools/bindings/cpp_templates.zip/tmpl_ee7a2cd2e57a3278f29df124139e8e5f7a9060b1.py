from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'struct_serialization_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_struct_macros = l_0_data_view = l_0_data_type = missing
    t_1 = environment.filters['get_qualified_name_for_kind']
    t_2 = environment.filters['indent']
    t_3 = environment.filters['use_custom_serializer']
    pass
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'struct_serialization_declaration.tmpl')._get_default_module()
    context.exported_vars.discard('struct_macros')
    l_0_data_view = unicode_join((t_1((undefined(name='struct') if l_0_struct is missing else l_0_struct)), 'DataView', ))
    context.vars['data_view'] = l_0_data_view
    context.exported_vars.add('data_view')
    l_0_data_type = t_1((undefined(name='struct') if l_0_struct is missing else l_0_struct), internal=True)
    context.vars['data_type'] = l_0_data_type
    context.exported_vars.add('data_type')
    if (not t_3((undefined(name='struct') if l_0_struct is missing else l_0_struct))):
        pass
        yield '\n\nnamespace internal {\n\ntemplate <typename MaybeConstUserType>\nstruct Serializer<'
        yield to_string((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
        yield ', MaybeConstUserType> {\n  using UserType = typename std::remove_const<MaybeConstUserType>::type;\n  using Traits = StructTraits<'
        yield to_string((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
        yield ', UserType>;\n\n  static void Serialize(\n      MaybeConstUserType& input,\n      mojo::internal::MessageFragment<'
        yield to_string((undefined(name='data_type') if l_0_data_type is missing else l_0_data_type))
        yield '>& fragment) {\n    if (CallIsNullIfExists<Traits>(input))\n      return;\n    '
        yield to_string(t_2(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'serialize'), (undefined(name='struct') if l_0_struct is missing else l_0_struct), unicode_join((environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'), ' struct', )), 'Traits::%s(input)', 'fragment', True), 2))
        yield '\n  }\n\n  static bool Deserialize('
        yield to_string((undefined(name='data_type') if l_0_data_type is missing else l_0_data_type))
        yield '* input,\n                          UserType* output,\n                          Message* message) {\n    if (!input)\n      return CallSetToNullIfExists<Traits>(output);\n\n    '
        yield to_string((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
        yield ' data_view(input, message);\n    return Traits::Read(data_view, output);\n  }\n};\n\n}  // namespace internal'

blocks = {}
debug_info = '1=16&2=18&3=21&5=24&10=27&12=29&16=31&21=33&24=35&30=37'