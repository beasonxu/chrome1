from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'union_traits_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_mojom_type = missing
    t_1 = environment.filters['cpp_wrapper_type']
    t_2 = environment.filters['get_qualified_name_for_kind']
    t_3 = environment.filters['is_any_handle_kind']
    t_4 = environment.filters['is_any_interface_kind']
    t_5 = environment.filters['is_enum_kind']
    t_6 = environment.filters['is_object_kind']
    t_7 = environment.filters['under_to_camel']
    t_8 = environment.filters['unmapped_type_for_serializer']
    pass
    l_0_mojom_type = t_2((undefined(name='union') if l_0_union is missing else l_0_union))
    context.vars['mojom_type'] = l_0_mojom_type
    context.exported_vars.add('mojom_type')
    yield '\n\n// static\nbool UnionTraits<'
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView, '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr>::Read(\n    '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView input,\n    '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr* output) {\n  using UnionType = '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield ';\n  using Tag = UnionType::Tag;\n\n  switch (input.tag()) {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        l_1_name = l_1_kind = l_1_serializer_type = missing
        pass
        yield '\n    case Tag::k'
        yield to_string(t_7(environment.getattr(l_1_field, 'name')))
        yield ': {'
        l_1_name = environment.getattr(l_1_field, 'name')
        l_1_kind = environment.getattr(l_1_field, 'kind')
        l_1_serializer_type = t_8((undefined(name='kind') if l_1_kind is missing else l_1_kind))
        if t_6((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n      '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind), True))
            yield ' result_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ';\n      if (!input.Read'
            yield to_string(t_7((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '(&result_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '))\n        return false;\n\n      *output = UnionType::New'
            yield to_string(t_7(environment.getattr(l_1_field, 'name')))
            yield '(\n          std::move(result_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '));'
        elif t_3((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n      *output = UnionType::New'
            yield to_string(t_7(environment.getattr(l_1_field, 'name')))
            yield '(\n          input.Take'
            yield to_string(t_7((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '());'
        elif t_4((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n      *output = UnionType::New'
            yield to_string(t_7(environment.getattr(l_1_field, 'name')))
            yield '(\n          input.Take'
            yield to_string(t_7((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '<'
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind), True))
            yield '>());'
        elif t_5((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n      '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind), True))
            yield ' result_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ';\n      if (!input.Read'
            yield to_string(t_7((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '(&result_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '))\n        return false;\n\n      *output = UnionType::New'
            yield to_string(t_7(environment.getattr(l_1_field, 'name')))
            yield '(result_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ');'
        else:
            pass
            yield '\n      *output = UnionType::New'
            yield to_string(t_7(environment.getattr(l_1_field, 'name')))
            yield '(input.'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '());'
        yield '\n      break;\n    }'
    l_1_field = l_1_name = l_1_kind = l_1_serializer_type = missing
    yield '\n    default:\n'
    if environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'extensible'):
        pass
        yield '\n      *output = UnionType::New'
        yield to_string(t_7(environment.getattr(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'default_field'), 'name')))
        yield '({});\n      return true;'
    else:
        pass
        yield '\n      return false;'
    yield '\n  }\n  return true;\n}'

blocks = {}
debug_info = '1=21&4=25&5=29&6=31&7=33&11=35&12=39&13=41&14=42&15=43&16=44&17=47&18=51&21=55&22=57&23=59&24=62&25=64&27=66&28=69&29=71&31=75&32=78&33=82&36=86&38=93&44=100&45=103'