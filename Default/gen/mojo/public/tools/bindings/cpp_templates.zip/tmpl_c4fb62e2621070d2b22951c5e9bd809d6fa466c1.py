from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'module-shared-message-ids.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_interfaces = resolve('interfaces')
    l_0_header_guard = missing
    t_1 = environment.filters['format']
    t_2 = environment.filters['replace']
    t_3 = environment.filters['reverse']
    t_4 = environment.filters['upper']
    pass
    yield '// Copyright 2018 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    l_0_header_guard = t_1('%s_SHARED_MESSAGE_IDS_H_', t_2(context.eval_ctx, t_2(context.eval_ctx, t_2(context.eval_ctx, t_4(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path')), '/', '_'), '.', '_'), '-', '_'))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    yield '\n\n#ifndef '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include <stdint.h>'
    for l_1_namespace in (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array):
        pass
        yield '\nnamespace '
        yield to_string(l_1_namespace)
        yield ' {'
    l_1_namespace = missing
    yield '\n\nnamespace internal {\n\n'
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_method_name = missing
            pass
            l_2_method_name = t_1('k%s_%s_Name', environment.getattr(l_1_interface, 'name'), environment.getattr(l_2_method, 'name'))
            if environment.getattr(l_2_method, 'ordinal_comment'):
                pass
                yield '\n// '
                yield to_string(environment.getattr(l_2_method, 'ordinal_comment'))
            yield '\nconstexpr uint32_t '
            yield to_string((undefined(name='method_name') if l_2_method_name is missing else l_2_method_name))
            yield ' = '
            yield to_string(environment.getattr(l_2_method, 'ordinal'))
            yield ';'
        l_2_method = l_2_method_name = missing
    l_1_interface = missing
    yield '\n\n}  // namespace internal'
    for l_1_namespace in t_3((undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)):
        pass
        yield '\n}  // namespace '
        yield to_string(l_1_namespace)
    l_1_namespace = missing
    yield '\n\n#endif  // '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=20&9=24&10=26&14=28&15=31&20=35&21=37&22=40&23=41&24=44&26=46&31=53&32=56&35=59'