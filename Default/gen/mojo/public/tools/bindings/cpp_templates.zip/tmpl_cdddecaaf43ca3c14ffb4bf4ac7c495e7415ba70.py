from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'wrapper_union_class_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_default_field = missing
    t_1 = environment.filters['cpp_wrapper_param_type_new']
    t_2 = environment.filters['cpp_wrapper_type']
    t_3 = environment.filters['is_any_handle_or_interface_kind']
    t_4 = environment.filters['is_hashable']
    t_5 = environment.filters['is_object_kind']
    t_6 = environment.filters['under_to_camel']
    pass
    l_0_default_field = environment.getitem(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'), 0)
    context.vars['default_field'] = l_0_default_field
    context.exported_vars.add('default_field')
    yield '\n'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '() : tag_(Tag::k'
    yield to_string(t_6(environment.getattr((undefined(name='default_field') if l_0_default_field is missing else l_0_default_field), 'name')))
    yield ') {'
    if (t_5(environment.getattr((undefined(name='default_field') if l_0_default_field is missing else l_0_default_field), 'kind')) or t_3(environment.getattr((undefined(name='default_field') if l_0_default_field is missing else l_0_default_field), 'kind'))):
        pass
        yield '\n  data_.'
        yield to_string(environment.getattr((undefined(name='default_field') if l_0_default_field is missing else l_0_default_field), 'name'))
        yield ' = new '
        yield to_string(t_2(environment.getattr((undefined(name='default_field') if l_0_default_field is missing else l_0_default_field), 'kind')))
        yield ';'
    else:
        pass
        yield '\n  data_.'
        yield to_string(environment.getattr((undefined(name='default_field') if l_0_default_field is missing else l_0_default_field), 'name'))
        yield ' = '
        yield to_string(t_2(environment.getattr((undefined(name='default_field') if l_0_default_field is missing else l_0_default_field), 'kind')))
        yield '();'
    yield '\n}\n\n'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::~'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '() {\n  DestroyActive();\n}\n\n'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        pass
        yield '\nvoid '
        yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '::set_'
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield '(\n    '
        yield to_string(t_1(environment.getattr(l_1_field, 'kind')))
        yield ' '
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield ') {'
        if (t_5(environment.getattr(l_1_field, 'kind')) or t_3(environment.getattr(l_1_field, 'kind'))):
            pass
            yield '\n  if (tag_ == Tag::k'
            yield to_string(t_6(environment.getattr(l_1_field, 'name')))
            yield ') {\n    *(data_.'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ') = std::move('
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ');\n  } else {\n    DestroyActive();\n    tag_ = Tag::k'
            yield to_string(t_6(environment.getattr(l_1_field, 'name')))
            yield ';\n    data_.'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ' = new '
            yield to_string(t_2(environment.getattr(l_1_field, 'kind')))
            yield '(\n        std::move('
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield '));\n  }'
        else:
            pass
            yield '\n  if (tag_ != Tag::k'
            yield to_string(t_6(environment.getattr(l_1_field, 'name')))
            yield ') {\n    DestroyActive();\n    tag_ = Tag::k'
            yield to_string(t_6(environment.getattr(l_1_field, 'name')))
            yield ';\n  }\n  data_.'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ' = '
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ';'
        yield '\n}'
    l_1_field = missing
    yield '\n\nvoid '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::DestroyActive() {\n  switch (tag_) {\n'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        pass
        yield '\n    case Tag::k'
        yield to_string(t_6(environment.getattr(l_1_field, 'name')))
        yield ':\n'
        if (t_5(environment.getattr(l_1_field, 'kind')) or t_3(environment.getattr(l_1_field, 'kind'))):
            pass
            yield '\n      delete data_.'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ';'
        yield '\n      break;'
    l_1_field = missing
    yield '\n  }\n}'
    if t_4((undefined(name='union') if l_0_union is missing else l_0_union)):
        pass
        yield '\nsize_t '
        yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '::Hash(size_t seed) const {\n  seed = mojo::internal::HashCombine(seed, static_cast<uint32_t>(tag_));\n  switch (tag_) {\n'
        for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
            l_1_for_blink = resolve('for_blink')
            pass
            yield '\n    case Tag::k'
            yield to_string(t_6(environment.getattr(l_1_field, 'name')))
            yield ':'
            if (undefined(name='for_blink') if l_1_for_blink is missing else l_1_for_blink):
                pass
                yield '\n      return mojo::internal::WTFHash(seed, data_.'
                yield to_string(environment.getattr(l_1_field, 'name'))
                yield ');'
            else:
                pass
                yield '\n      return mojo::internal::Hash(seed, data_.'
                yield to_string(environment.getattr(l_1_field, 'name'))
                yield ');'
        l_1_field = l_1_for_blink = missing
        yield '\n    default:\n      NOTREACHED();\n      return seed;\n  }\n}'
    yield '\n\nbool '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::Validate(\n    const void* data,\n    mojo::internal::ValidationContext* validation_context) {\n  return Data_::Validate(data, validation_context, false);\n}'

blocks = {}
debug_info = '1=19&2=23&3=29&5=32&7=39&11=44&15=48&16=51&17=55&18=59&20=62&21=64&24=68&25=70&26=74&29=79&31=81&33=83&38=90&40=92&41=95&42=97&44=100&51=105&52=108&55=110&56=114&57=116&58=119&60=124&70=129'