from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'struct_data_view_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_struct_macros = missing
    t_1 = environment.filters['cpp_data_view_type']
    t_2 = environment.filters['is_any_handle_kind']
    t_3 = environment.filters['is_any_interface_kind']
    t_4 = environment.filters['is_enum_kind']
    t_5 = environment.filters['is_object_kind']
    t_6 = environment.filters['is_typemapped_kind']
    t_7 = environment.filters['is_union_kind']
    t_8 = environment.filters['requires_context_for_data_view']
    t_9 = environment.filters['under_to_camel']
    t_10 = environment.filters['unmapped_type_for_serializer']
    pass
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'struct_data_view_declaration.tmpl')._get_default_module()
    context.exported_vars.discard('struct_macros')
    yield '\n\nclass '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'DataView {\n public:\n  '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'DataView() = default;\n\n  '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'DataView(\n      internal::'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '_Data* data,\n      mojo::Message* message)'
    if t_8((undefined(name='struct') if l_0_struct is missing else l_0_struct)):
        pass
        yield '\n      : data_(data), message_(message) {}'
    else:
        pass
        yield '\n      : data_(data) {}'
    yield '\n\n  bool is_null() const { return !data_; }'
    for l_1_pf in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields_in_ordinal_order'):
        l_1_kind = l_1_name = missing
        pass
        l_1_kind = environment.getattr(environment.getattr(l_1_pf, 'field'), 'kind')
        l_1_name = environment.getattr(environment.getattr(l_1_pf, 'field'), 'name')
        if t_7((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n  inline void Get'
            yield to_string(t_9((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield 'DataView(\n      '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '* output);\n\n  template <typename UserType>\n  [[nodiscard]] bool Read'
            yield to_string(t_9((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '(UserType* output) {\n    '
            yield to_string(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'assert_nullable_output_type_if_necessary'), (undefined(name='kind') if l_1_kind is missing else l_1_kind), (undefined(name='name') if l_1_name is missing else l_1_name)))
            if (environment.getattr(l_1_pf, 'min_version') != 0):
                pass
                yield '\n    auto* pointer = data_->header_.version >= '
                yield to_string(environment.getattr(l_1_pf, 'min_version'))
                yield ' && !data_->'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '.is_null()\n                    ? &data_->'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ' : nullptr;'
            else:
                pass
                yield '\n    auto* pointer = !data_->'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '.is_null() ? &data_->'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ' : nullptr;'
            yield '\n    return mojo::internal::Deserialize<'
            yield to_string(t_10((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '>(\n        pointer, output, message_);\n  }'
        elif t_5((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n  inline void Get'
            yield to_string(t_9((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield 'DataView(\n      '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '* output);\n\n  template <typename UserType>\n  [[nodiscard]] bool Read'
            yield to_string(t_9((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '(UserType* output) {\n    '
            yield to_string(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'assert_nullable_output_type_if_necessary'), (undefined(name='kind') if l_1_kind is missing else l_1_kind), (undefined(name='name') if l_1_name is missing else l_1_name)))
            if (environment.getattr(l_1_pf, 'min_version') != 0):
                pass
                yield '\n    auto* pointer = data_->header_.version >= '
                yield to_string(environment.getattr(l_1_pf, 'min_version'))
                yield '\n                    ? data_->'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '.Get() : nullptr;'
            else:
                pass
                yield '\n    auto* pointer = data_->'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '.Get();'
            yield '\n    return mojo::internal::Deserialize<'
            yield to_string(t_10((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '>(\n        pointer, output, message_);\n  }'
        elif t_4((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n  template <typename UserType>\n  [[nodiscard]] bool Read'
            yield to_string(t_9((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '(UserType* output) const {'
            if (environment.getattr(l_1_pf, 'min_version') != 0):
                pass
                yield '\n    auto data_value = data_->header_.version >= '
                yield to_string(environment.getattr(l_1_pf, 'min_version'))
                yield '\n                      ? data_->'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ' : 0;'
            else:
                pass
                yield '\n    auto data_value = data_->'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ';'
            yield '\n    return mojo::internal::Deserialize<'
            yield to_string(t_10((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '>(\n        data_value, output);\n  }'
            if (not t_6((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
                pass
                yield '\n  '
                yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield ' '
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '() const {'
                if (environment.getattr(l_1_pf, 'min_version') != 0):
                    pass
                    yield '\n    if (data_->header_.version < '
                    yield to_string(environment.getattr(l_1_pf, 'min_version'))
                    yield ')\n      return '
                    yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                    yield '{};'
                yield '\n    return ::mojo::internal::ToKnownEnumValueHelper(\n          static_cast<'
                yield to_string(t_10((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield '>(data_->'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '));\n  }'
        elif t_2((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n  '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield ' Take'
            yield to_string(t_9((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '() {\n    '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield ' result;'
            if (environment.getattr(l_1_pf, 'min_version') != 0):
                pass
                yield '\n    if (data_->header_.version < '
                yield to_string(environment.getattr(l_1_pf, 'min_version'))
                yield ')\n      return result;'
            yield '\n    bool ret =\n        mojo::internal::Deserialize<'
            yield to_string(t_10((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '>(\n            &data_->'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ', &result, message_);\n    DCHECK(ret);\n    return result;\n  }'
        elif t_3((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n  template <typename UserType>\n  UserType Take'
            yield to_string(t_9((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '() {\n    UserType result;'
            if (environment.getattr(l_1_pf, 'min_version') != 0):
                pass
                yield '\n    if (data_->header_.version < '
                yield to_string(environment.getattr(l_1_pf, 'min_version'))
                yield ')\n      return result;'
            yield '\n    bool ret =\n        mojo::internal::Deserialize<'
            yield to_string(t_10((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '>(\n            &data_->'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ', &result, message_);\n    DCHECK(ret);\n    return result;\n  }'
        else:
            pass
            yield '\n  '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield ' '
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '() const {'
            if (environment.getattr(l_1_pf, 'min_version') != 0):
                pass
                yield '\n    if (data_->header_.version < '
                yield to_string(environment.getattr(l_1_pf, 'min_version'))
                yield ')\n      return '
                yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield '{};'
            yield '\n    return data_->'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ';\n  }'
    l_1_pf = l_1_kind = l_1_name = missing
    yield '\n private:\n  internal::'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '_Data* data_ = nullptr;'
    if t_8((undefined(name='struct') if l_0_struct is missing else l_0_struct)):
        pass
        yield '\n  mojo::Message* message_ = nullptr;'
    yield '\n};\n'

blocks = {}
debug_info = '1=23&3=26&5=28&7=30&8=32&10=34&18=41&19=44&20=45&21=46&22=49&23=51&26=53&27=55&28=56&29=59&30=63&32=68&34=73&38=75&39=78&40=80&43=82&44=84&45=85&46=88&47=90&49=95&51=98&55=100&57=103&58=105&59=108&60=110&62=115&64=118&68=120&69=123&70=127&71=130&72=132&75=135&79=139&80=142&81=146&82=148&83=151&87=154&88=156&93=158&95=161&97=163&98=166&102=169&103=171&109=176&110=180&111=183&112=185&114=188&120=192&121=194'