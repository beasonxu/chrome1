from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'union_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_export_attribute = resolve('export_attribute')
    l_0_kythe_annotation = l_0_class_name = l_0_enum_name = l_0_struct_macros = missing
    t_1 = environment.filters['cpp_union_field_type']
    t_2 = environment.filters['format']
    t_3 = environment.filters['get_full_mojom_name_for_kind']
    t_4 = environment.filters['under_to_camel']
    pass
    def macro(l_1_name):
        t_5 = []
        l_1_enable_kythe_annotations = resolve('enable_kythe_annotations')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (undefined(name='enable_kythe_annotations') if l_1_enable_kythe_annotations is missing else l_1_enable_kythe_annotations):
            pass
            t_5.extend((
                '\n// @generated_from: ',
                to_string(l_1_name),
            ))
        return concat(t_5)
    context.exported_vars.add('kythe_annotation')
    context.vars['kythe_annotation'] = l_0_kythe_annotation = Macro(environment, macro, 'kythe_annotation', ('name',), False, False, False, context.eval_ctx.autoescape)
    l_0_class_name = unicode_join((environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'), '_Data', ))
    context.vars['class_name'] = l_0_class_name
    context.exported_vars.add('class_name')
    l_0_enum_name = unicode_join((environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'), '_Tag', ))
    context.vars['enum_name'] = l_0_enum_name
    context.exported_vars.add('enum_name')
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'union_declaration.tmpl')._get_default_module()
    context.exported_vars.discard('struct_macros')
    yield '\n\nclass '
    yield to_string((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' '
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield ' {\n public:\n  // Used to identify Mojom Union Data Classes.\n  typedef void MojomUnionDataType;\n\n  '
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield "() = default;\n  // Do nothing in the destructor since it won't be called when it is a\n  // non-inlined union.\n  ~"
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '() = default;\n\n  static bool Validate(const void* data,\n                       mojo::internal::ValidationContext* validation_context,\n                       bool inlined);\n\n  bool is_null() const { return size == 0; }\n\n  void set_null() {\n    size = 0U;\n    tag = static_cast<'
    yield to_string((undefined(name='enum_name') if l_0_enum_name is missing else l_0_enum_name))
    yield '>(0);\n    data.unknown = 0U;\n  }\n\n  // TODO(crbug.com/1148486): SHOUTY_CASE values are being deprecated per C++ code style\n  // guidelines (https://google.github.io/styleguide/cppguide.html#Enumerator_Names),\n  // please use kCamelCase values instead.  Cleanup NULL_VALUE, BOOL_VALUE, INT_VALUE, etc.\n  // generation once codebase is transitioned to kNullValue, kBoolValue, kIntValue, etc.\n  enum class '
    yield to_string((undefined(name='enum_name') if l_0_enum_name is missing else l_0_enum_name))
    yield ' : uint32_t {\n'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        pass
        yield '\n    '
        yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_2('%s.%s', t_3((undefined(name='union') if l_0_union is missing else l_0_union)), environment.getattr(l_1_field, 'name'))))
        yield '\n    k'
        yield to_string(t_4(environment.getattr(l_1_field, 'name')))
        yield ','
    l_1_field = missing
    yield '\n  };\n\n  // A note on layout:\n  // "Each non-static data member is allocated as if it were the sole member of\n  // a struct." - Section 9.5.2 ISO/IEC 14882:2011 (The C++ Spec)\n  union MOJO_ALIGNAS(8) Union_ {\n    Union_() : unknown(0) {}'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        pass
        if (environment.getattr(environment.getattr(l_1_field, 'kind'), 'spec') == 'b'):
            pass
            yield '\n    uint8_t f_'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ' : 1;'
        else:
            pass
            yield '\n    '
            yield to_string(t_1(environment.getattr(l_1_field, 'kind')))
            yield ' f_'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ';'
    l_1_field = missing
    yield '\n    uint64_t unknown;\n  };\n\n  uint32_t size;\n  '
    yield to_string((undefined(name='enum_name') if l_0_enum_name is missing else l_0_enum_name))
    yield ' tag;\n  Union_ data;\n};\nstatic_assert(sizeof('
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield ') == mojo::internal::kUnionDataSize,\n              "Bad sizeof('
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield ')");'

blocks = {}
debug_info = '1=18&2=24&3=28&7=33&8=36&9=39&11=42&16=46&19=48&29=50&37=52&38=54&39=57&40=59&50=63&51=65&52=68&54=73&61=79&64=81&65=83'