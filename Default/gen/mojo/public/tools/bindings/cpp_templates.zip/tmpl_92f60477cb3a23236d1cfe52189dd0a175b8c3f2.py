from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'struct_traits_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_struct_macros = l_0_mojom_type = missing
    t_1 = environment.filters['get_qualified_name_for_kind']
    t_2 = environment.filters['indent']
    pass
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'struct_traits_definition.tmpl')._get_default_module()
    context.exported_vars.discard('struct_macros')
    l_0_mojom_type = t_1((undefined(name='struct') if l_0_struct is missing else l_0_struct))
    context.vars['mojom_type'] = l_0_mojom_type
    context.exported_vars.add('mojom_type')
    yield '\n\n// static\nbool StructTraits<'
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView, '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr>::Read(\n    '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView input,\n    '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr* output) {\n  bool success = true;\n  '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr result('
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::New());\n  '
    yield to_string(t_2(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'deserialize'), (undefined(name='struct') if l_0_struct is missing else l_0_struct), 'input', 'result->%s', 'success'), 4))
    yield '\n  *output = std::move(result);\n  return success;\n}'

blocks = {}
debug_info = '1=15&2=17&5=21&6=25&7=27&9=29&11=33'