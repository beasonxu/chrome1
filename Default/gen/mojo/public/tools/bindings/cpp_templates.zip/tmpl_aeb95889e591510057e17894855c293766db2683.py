from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'module-shared.cc.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_extra_traits_headers = resolve('extra_traits_headers')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_all_enums = resolve('all_enums')
    l_0_unions = resolve('unions')
    l_0_structs = resolve('structs')
    l_0_interfaces = resolve('interfaces')
    l_0_enum_stream = l_0_enum_to_string = l_0_enum_trace_format_traits = missing
    t_1 = environment.filters['is_native_only_kind']
    t_2 = environment.filters['reverse']
    pass
    yield '// Copyright 2016 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.\n\n#include "'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-shared.h"\n\n// Used to support stream output operator for enums.\n// TODO(dcheng): Consider omitting this somehow if not needed.\n#include <ostream>\n#include <utility>\n\n#include "base/strings/stringprintf.h"\n#include "mojo/public/cpp/bindings/lib/validate_params.h"\n#include "mojo/public/cpp/bindings/lib/validation_errors.h"\n#include "mojo/public/cpp/bindings/lib/validation_util.h"\n#include "third_party/perfetto/include/perfetto/tracing/traced_value.h"\n\n#include "'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-params-data.h"'
    for l_1_header in (undefined(name='extra_traits_headers') if l_0_extra_traits_headers is missing else l_0_extra_traits_headers):
        pass
        yield '\n#include "'
        yield to_string(l_1_header)
        yield '"'
    l_1_header = missing
    for l_1_namespace in (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array):
        pass
        yield '\nnamespace '
        yield to_string(l_1_namespace)
        yield ' {'
    l_1_namespace = missing
    included_template = environment.get_template('enum_macros.tmpl', 'module-shared.cc.tmpl')._get_default_module()
    l_0_enum_stream = getattr(included_template, 'enum_stream', missing)
    if l_0_enum_stream is missing:
        l_0_enum_stream = undefined("the template %r (imported on line 29 in 'module-shared.cc.tmpl') does not export the requested name 'enum_stream'" % included_template.__name__, name='enum_stream')
    l_0_enum_to_string = getattr(included_template, 'enum_to_string', missing)
    if l_0_enum_to_string is missing:
        l_0_enum_to_string = undefined("the template %r (imported on line 29 in 'module-shared.cc.tmpl') does not export the requested name 'enum_to_string'" % included_template.__name__, name='enum_to_string')
    context.vars.update({'enum_stream': l_0_enum_stream, 'enum_to_string': l_0_enum_to_string})
    context.exported_vars.difference_update(('enum_stream', 'enum_to_string'))
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        pass
        if (not t_1(l_1_enum)):
            pass
            yield '\n'
            yield to_string(context.call((undefined(name='enum_to_string') if l_0_enum_to_string is missing else l_0_enum_to_string), l_1_enum))
            yield '\n'
            yield to_string(context.call((undefined(name='enum_stream') if l_0_enum_stream is missing else l_0_enum_stream), l_1_enum))
    l_1_enum = missing
    yield '\n\nnamespace internal {'
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        yield '\n'
        template = environment.get_template('union_definition.tmpl', 'module-shared.cc.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_stream': l_0_enum_stream, 'enum_to_string': l_0_enum_to_string, 'enum_trace_format_traits': l_0_enum_trace_format_traits, 'union': l_1_union})):
            yield event
    l_1_union = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        if (not t_1(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('struct_definition.tmpl', 'module-shared.cc.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_stream': l_0_enum_stream, 'enum_to_string': l_0_enum_to_string, 'enum_trace_format_traits': l_0_enum_trace_format_traits, 'struct': l_1_struct})):
                yield event
    l_1_struct = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_struct = missing
            pass
            l_2_struct = environment.getattr(l_2_method, 'param_struct')
            yield '\n'
            template = environment.get_template('struct_definition.tmpl', 'module-shared.cc.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_stream': l_0_enum_stream, 'enum_to_string': l_0_enum_to_string, 'enum_trace_format_traits': l_0_enum_trace_format_traits, 'interface': l_1_interface, 'method': l_2_method, 'struct': l_2_struct})):
                yield event
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                l_2_struct = environment.getattr(l_2_method, 'response_param_struct')
                yield '\n'
                template = environment.get_template('struct_definition.tmpl', 'module-shared.cc.tmpl')
                for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_stream': l_0_enum_stream, 'enum_to_string': l_0_enum_to_string, 'enum_trace_format_traits': l_0_enum_trace_format_traits, 'interface': l_1_interface, 'method': l_2_method, 'struct': l_2_struct})):
                    yield event
        l_2_method = l_2_struct = missing
    l_1_interface = missing
    yield '\n\n}  // namespace internal'
    for l_1_namespace in t_2((undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)):
        pass
        yield '\n}  // namespace '
        yield to_string(l_1_namespace)
    l_1_namespace = missing
    included_template = environment.get_template('enum_macros.tmpl', 'module-shared.cc.tmpl')._get_default_module()
    l_0_enum_trace_format_traits = getattr(included_template, 'enum_trace_format_traits', missing)
    if l_0_enum_trace_format_traits is missing:
        l_0_enum_trace_format_traits = undefined("the template %r (imported on line 70 in 'module-shared.cc.tmpl') does not export the requested name 'enum_trace_format_traits'" % included_template.__name__, name='enum_trace_format_traits')
    context.vars['enum_trace_format_traits'] = l_0_enum_trace_format_traits
    context.exported_vars.discard('enum_trace_format_traits')
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        pass
        if (not t_1(l_1_enum)):
            pass
            yield '\n'
            yield to_string(context.call((undefined(name='enum_trace_format_traits') if l_0_enum_trace_format_traits is missing else l_0_enum_trace_format_traits), l_1_enum))
    l_1_enum = missing

blocks = {}
debug_info = '5=22&18=24&20=26&21=29&24=32&25=35&29=38&30=47&31=49&32=52&33=54&40=57&41=60&45=64&46=66&47=69&52=73&53=75&54=78&55=80&56=83&57=85&58=87&65=93&66=96&70=98&71=104&72=106&73=109'