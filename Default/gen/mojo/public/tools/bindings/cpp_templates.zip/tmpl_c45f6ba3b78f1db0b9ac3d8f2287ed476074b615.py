from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'wrapper_class_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    t_1 = environment.filters['cpp_wrapper_param_type']
    t_2 = environment.filters['cpp_wrapper_param_type_new']
    t_3 = environment.filters['default_value']
    t_4 = environment.filters['is_hashable']
    t_5 = environment.filters['struct_constructors']
    pass
    l_1_loop = missing
    for l_1_constructor, l_1_loop in LoopContext(t_5((undefined(name='struct') if l_0_struct is missing else l_0_struct)), undefined):
        pass
        yield '\n'
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '::'
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '('
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_constructor, 'params'), undefined):
            l_2_type = l_2_name = missing
            pass
            l_2_type = t_2(environment.getattr(l_2_field, 'kind'))
            l_2_name = environment.getattr(l_2_field, 'name')
            yield '\n    '
            yield to_string((undefined(name='type') if l_2_type is missing else l_2_type))
            yield ' '
            yield to_string((undefined(name='name') if l_2_name is missing else l_2_name))
            yield '_in'
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_field = l_2_type = l_2_name = missing
        yield ')'
        l_2_loop = missing
        for (l_2_field, l_2_is_parameter), l_2_loop in LoopContext(environment.getattr(l_1_constructor, 'fields'), undefined):
            l_2_name = missing
            pass
            l_2_name = environment.getattr(l_2_field, 'name')
            yield '\n    '
            if environment.getattr(l_2_loop, 'first'):
                pass
                yield ':'
            else:
                pass
                yield ' '
            yield ' '
            yield to_string((undefined(name='name') if l_2_name is missing else l_2_name))
            yield '('
            if l_2_is_parameter:
                pass
                yield 'std::move('
                yield to_string((undefined(name='name') if l_2_name is missing else l_2_name))
                yield '_in)'
            else:
                pass
                yield to_string(t_3(l_2_field))
            yield ')'
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_field = l_2_is_parameter = l_2_name = missing
        yield ' {}\n'
    l_1_loop = l_1_constructor = missing
    yield '\n'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::~'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '() = default;'
    if t_4((undefined(name='struct') if l_0_struct is missing else l_0_struct)):
        pass
        yield '\nsize_t '
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '::Hash(size_t seed) const {'
        for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
            l_1_for_blink = resolve('for_blink')
            pass
            if (undefined(name='for_blink') if l_1_for_blink is missing else l_1_for_blink):
                pass
                yield '\n  seed = mojo::internal::WTFHash(seed, this->'
                yield to_string(environment.getattr(l_1_field, 'name'))
                yield ');'
            else:
                pass
                yield '\n  seed = mojo::internal::Hash(seed, this->'
                yield to_string(environment.getattr(l_1_field, 'name'))
                yield ');'
        l_1_field = l_1_for_blink = missing
        yield '\n  return seed;\n}'
    yield '\n\nvoid '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::WriteIntoTrace(\n    perfetto::TracedValue traced_context) const {\n  [[maybe_unused]] auto dict = std::move(traced_context).WriteDictionary();'
    for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
        pass
        yield '\n  perfetto::WriteIntoTracedValueWithFallback(\n    dict.AddItem(\n      "'
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield '"), '
        yield to_string(('this->' + environment.getattr(l_1_field, 'name')))
        yield ',\n#if BUILDFLAG(MOJO_TRACE_ENABLED)\n      "<value of type '
        yield to_string(t_1(environment.getattr(l_1_field, 'kind')))
        yield '>"\n#else\n      "<value>"\n#endif  // BUILDFLAG(MOJO_TRACE_ENABLED)\n    );'
    l_1_field = missing
    yield '\n}\n\nbool '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::Validate(\n    const void* data,\n    mojo::internal::ValidationContext* validation_context) {\n  return Data_::Validate(data, validation_context);\n}'

blocks = {}
debug_info = '1=18&2=21&3=26&4=29&5=30&6=32&7=36&9=42&10=45&11=47&12=56&13=59&15=63&17=65&20=72&22=76&23=79&24=81&25=84&26=87&28=92&35=97&38=99&41=102&43=106&51=110'