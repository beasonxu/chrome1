from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'interface_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_module_namespace = resolve('module_namespace')
    l_0_variant = resolve('variant')
    l_0_range = resolve('range')
    l_0_interface_macros = l_0_struct_macros = l_0_class_name = l_0_proxy_name = l_0_namespace_as_string = l_0_namespace_as_string_with_variant = l_0_qualified_class_name = l_0_alloc_params = l_0_pass_params = missing
    t_1 = environment.filters['constant_value']
    t_2 = environment.filters['cpp_pod_type']
    t_3 = environment.filters['cpp_wrapper_call_type']
    t_4 = environment.filters['format']
    t_5 = environment.filters['has_callbacks']
    t_6 = environment.filters['has_packed_method_ordinals']
    t_7 = environment.filters['indent']
    t_8 = environment.filters['is_string_kind']
    t_9 = environment.filters['list']
    t_10 = environment.filters['map']
    t_11 = environment.filters['max']
    t_12 = environment.filters['method_supports_lazy_serialization']
    t_13 = environment.filters['replace']
    t_14 = environment.filters['selectattr']
    pass
    l_0_interface_macros = context.vars['interface_macros'] = environment.get_template('interface_macros.tmpl', 'interface_definition.tmpl')._get_default_module()
    context.exported_vars.discard('interface_macros')
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'interface_definition.tmpl')._get_default_module()
    context.exported_vars.discard('struct_macros')
    l_0_class_name = environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name')
    context.vars['class_name'] = l_0_class_name
    context.exported_vars.add('class_name')
    l_0_proxy_name = unicode_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), 'Proxy', ))
    context.vars['proxy_name'] = l_0_proxy_name
    context.exported_vars.add('proxy_name')
    l_0_namespace_as_string = t_4('%s', t_13(context.eval_ctx, (undefined(name='module_namespace') if l_0_module_namespace is missing else l_0_module_namespace), '.', '::'))
    context.vars['namespace_as_string'] = l_0_namespace_as_string
    context.exported_vars.add('namespace_as_string')
    l_0_namespace_as_string_with_variant = unicode_join(((undefined(name='namespace_as_string') if l_0_namespace_as_string is missing else l_0_namespace_as_string), (unicode_join(('::', (undefined(name='variant') if l_0_variant is missing else l_0_variant), )) if (undefined(name='variant') if l_0_variant is missing else l_0_variant) else cond_expr_undefined("the inline if-expression on line 7 in 'interface_definition.tmpl' evaluated to false and no else section was defined.")), ))
    context.vars['namespace_as_string_with_variant'] = l_0_namespace_as_string_with_variant
    context.exported_vars.add('namespace_as_string_with_variant')
    l_0_qualified_class_name = unicode_join(((unicode_join(('::', (undefined(name='namespace_as_string_with_variant') if l_0_namespace_as_string_with_variant is missing else l_0_namespace_as_string_with_variant), )) if (undefined(name='namespace_as_string_with_variant') if l_0_namespace_as_string_with_variant is missing else l_0_namespace_as_string_with_variant) else cond_expr_undefined("the inline if-expression on line 8 in 'interface_definition.tmpl' evaluated to false and no else section was defined.")), '::', (undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), ))
    context.vars['qualified_class_name'] = l_0_qualified_class_name
    context.exported_vars.add('qualified_class_name')
    def macro(l_1_struct, l_1_params, l_1_message, l_1_method_number, l_1_is_response):
        t_15 = []
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        if l_1_params is missing:
            l_1_params = undefined("parameter 'params' was not provided", name='params')
        if l_1_message is missing:
            l_1_message = undefined("parameter 'message' was not provided", name='message')
        if l_1_method_number is missing:
            l_1_method_number = undefined("parameter 'method_number' was not provided", name='method_number')
        if l_1_is_response is missing:
            l_1_is_response = undefined("parameter 'is_response' was not provided", name='is_response')
        pass
        t_15.append(
            '\n  bool success = true;',
        )
        for l_2_param in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields_in_ordinal_order'):
            pass
            t_15.extend((
                '\n  ',
                to_string(t_3(environment.getattr(environment.getattr(l_2_param, 'field'), 'kind'))),
                ' p_',
                to_string(environment.getattr(environment.getattr(l_2_param, 'field'), 'name')),
                '{};',
            ))
        l_2_param = missing
        t_15.extend((
            '\n  ',
            to_string(environment.getattr(l_1_struct, 'name')),
            'DataView input_data_view(',
            to_string(l_1_params),
            ', ',
            to_string(l_1_message),
            ');\n  ',
            to_string(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'deserialize'), l_1_struct, 'input_data_view', 'p_%s', 'success')),
            '\n  if (!success) {\n    ReportValidationErrorForMessage(\n        ',
            to_string(l_1_message),
            ',\n        mojo::internal::VALIDATION_ERROR_DESERIALIZATION_FAILED,\n        ',
            to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name)),
            '::Name_, ',
            to_string(l_1_method_number),
            ', ',
            to_string(l_1_is_response),
            ');\n    return false;\n  }',
        ))
        return concat(t_15)
    context.exported_vars.add('alloc_params')
    context.vars['alloc_params'] = l_0_alloc_params = Macro(environment, macro, 'alloc_params', ('struct', 'params', 'message', 'method_number', 'is_response'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_parameters):
        t_16 = []
        if l_1_parameters is missing:
            l_1_parameters = undefined("parameter 'parameters' was not provided", name='parameters')
        pass
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(l_1_parameters, undefined):
            pass
            t_16.extend((
                '\nstd::move(p_',
                to_string(environment.getattr(l_2_param, 'name')),
                ')',
            ))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_16.append(
                    ', ',
                )
        l_2_loop = l_2_param = missing
        return concat(t_16)
    context.exported_vars.add('pass_params')
    context.vars['pass_params'] = l_0_pass_params = Macro(environment, macro, 'pass_params', ('parameters',), False, False, False, context.eval_ctx.autoescape)
    yield '\nconst char '
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '::Name_[] = "'
    yield to_string((undefined(name='module_namespace') if l_0_module_namespace is missing else l_0_module_namespace))
    yield '.'
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '";'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'uuid'):
        pass
        yield '\nconstexpr base::Token '
        yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield '::Uuid_;'
    for l_1_constant in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'constants'):
        pass
        if t_8(environment.getattr(l_1_constant, 'kind')):
            pass
            yield '\nconst char '
            yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::'
            yield to_string(environment.getattr(l_1_constant, 'name'))
            yield '[] = '
            yield to_string(t_1(l_1_constant))
            yield ';'
        else:
            pass
            yield '\nconstexpr '
            yield to_string(t_2(environment.getattr(l_1_constant, 'kind')))
            yield ' '
            yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::'
            yield to_string(environment.getattr(l_1_constant, 'name'))
            yield ';'
    l_1_constant = missing
    yield '\n\n'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '::IPCStableHashFunction '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '::MessageToMethodInfo_(mojo::Message& message) {\n#if !BUILDFLAG(IS_FUCHSIA)'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        yield '\n  switch (message.name()) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            pass
            yield '\n    case internal::k'
            yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_Name: {\n      return &'
            yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_Sym::IPCStableHash;\n    }'
        l_1_method = missing
        yield '\n  }'
    yield '\n#endif  // !BUILDFLAG(IS_FUCHSIA)\n  return nullptr;\n}\n\n\nconst char* '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '::MessageToMethodName_(mojo::Message& message) {\n#if BUILDFLAG(MOJO_TRACE_ENABLED)'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        yield '\n  bool is_response = message.has_flag(mojo::Message::kFlagIsResponse);\n  if (!is_response) {\n    switch (message.name()) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            pass
            yield '\n      case internal::k'
            yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_Name:\n            return "Receive '
            yield to_string((undefined(name='namespace_as_string') if l_0_namespace_as_string is missing else l_0_namespace_as_string))
            yield '::'
            yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '";'
        l_1_method = missing
        yield '\n    }\n  } else {\n    switch (message.name()) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            pass
            yield '\n      case internal::k'
            yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_Name:\n            return "Receive reply '
            yield to_string((undefined(name='namespace_as_string') if l_0_namespace_as_string is missing else l_0_namespace_as_string))
            yield '::'
            yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '";'
        l_1_method = missing
        yield '\n    }\n  }'
    yield '\n  return "Receive unknown mojo message";\n#else\n  bool is_response = message.has_flag(mojo::Message::kFlagIsResponse);\n  if (is_response) {\n    return "Receive mojo reply";\n  } else {\n    return "Receive mojo message";\n  }\n#endif // BUILDFLAG(MOJO_TRACE_ENABLED)\n}\n\n#if !BUILDFLAG(IS_FUCHSIA)'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        yield '\nuint32_t '
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield '::'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield '_Sym::IPCStableHash() {\n  // This method\'s address is used for indetifiying the mojo method name after\n  // symbolization. So each IPCStableHash should have a unique address.\n  // We cannot use NO_CODE_FOLDING() here - it relies on the uniqueness of\n  // __LINE__ value, which is not unique accross different mojo modules.\n  // The code below is very similar to NO_CODE_FOLDING, but it uses a unique\n  // hash instead of __LINE__.\n  constexpr uint32_t kHash = base::MD5Hash32Constexpr(\n          "(Impl)'
        yield to_string((undefined(name='namespace_as_string') if l_0_namespace_as_string is missing else l_0_namespace_as_string))
        yield '::'
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield '::'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield '");\n  const uint32_t hash = kHash;\n  base::debug::Alias(&hash);\n  return hash;\n}'
    l_1_method = missing
    yield '\n# endif // !BUILDFLAG(IS_FUCHSIA)'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        if environment.getattr(l_1_method, 'sync'):
            pass
            yield '\nbool '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '('
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_sync_method_params'), '', l_1_method))
            yield ') {\n  NOTREACHED();\n  return false;\n}'
    l_1_method = missing
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            if environment.getattr(l_1_method, 'sync'):
                pass
                yield '\nclass '
                yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '_HandleSyncResponse\n    : public mojo::MessageReceiver {\n public:\n  '
                yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '_HandleSyncResponse(\n      bool* result'
                for l_2_param in environment.getattr(l_1_method, 'response_parameters'):
                    pass
                    yield ', '
                    yield to_string(t_3(environment.getattr(l_2_param, 'kind')))
                    yield '* out_'
                    yield to_string(environment.getattr(l_2_param, 'name'))
                l_2_param = missing
                yield ')\n      : result_(result)'
                for l_2_param in environment.getattr(l_1_method, 'response_parameters'):
                    pass
                    yield ', out_'
                    yield to_string(environment.getattr(l_2_param, 'name'))
                    yield '_(out_'
                    yield to_string(environment.getattr(l_2_param, 'name'))
                    yield ')'
                l_2_param = missing
                yield ' {\n    DCHECK(!*result_);\n  }\n\n  '
                yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '_HandleSyncResponse(const '
                yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '_HandleSyncResponse&) = delete;\n  '
                yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '_HandleSyncResponse& operator=(const '
                yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '_HandleSyncResponse&) = delete;\n\n  bool Accept(mojo::Message* message) override;\n private:\n  bool* result_;'
                for l_2_param in environment.getattr(l_1_method, 'response_parameters'):
                    pass
                    yield '\n  '
                    yield to_string(t_3(environment.getattr(l_2_param, 'kind')))
                    yield '* out_'
                    yield to_string(environment.getattr(l_2_param, 'name'))
                    yield '_;'
                l_2_param = missing
                yield '};'
            yield '\n\nclass '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback\n    : public mojo::MessageReceiver {\n public:\n  '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback(\n      '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield 'Callback callback\n      ) : callback_(std::move(callback)) {\n  }\n\n  '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback(const '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback&) = delete;\n  '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback& operator=(const '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback&) = delete;\n\n  bool Accept(mojo::Message* message) override;\n private:\n  '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield 'Callback callback_;\n};'
    l_1_method = missing
    yield '\n\n'
    yield to_string((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield '::'
    yield to_string((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield '(mojo::MessageReceiverWithResponder* receiver)\n    : receiver_(receiver) {\n}'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_event_name = resolve('event_name')
        l_1_message_name = l_1_params_struct = l_1_params_description = l_1_message_typename = missing
        pass
        l_1_message_name = t_4('internal::k%s_%s_Name', environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), environment.getattr(l_1_method, 'name'))
        l_1_params_struct = environment.getattr(l_1_method, 'param_struct')
        l_1_params_description = t_4('%s.%s request', environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), environment.getattr(l_1_method, 'name'))
        l_1_message_typename = t_4('%s_%s_Message', (undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name), environment.getattr(l_1_method, 'name'))
        if t_12(l_1_method):
            pass
            yield '\n'
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'define_message_type'), (undefined(name='interface') if l_0_interface is missing else l_0_interface), (undefined(name='message_typename') if l_1_message_typename is missing else l_1_message_typename), (undefined(name='message_name') if l_1_message_name is missing else l_1_message_name), False, l_1_method, environment.getattr(l_1_method, 'parameters'), (undefined(name='params_struct') if l_1_params_struct is missing else l_1_params_struct), (undefined(name='params_description') if l_1_params_description is missing else l_1_params_description)))
        if environment.getattr(l_1_method, 'sync'):
            pass
            yield '\nbool '
            yield to_string((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
            yield '::'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '(\n    '
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_sync_method_params'), 'param_', l_1_method))
            yield ') {\n#if BUILDFLAG(MOJO_TRACE_ENABLED)'
            l_1_event_name = ('Call %s::%s::%s (sync)' % ((undefined(name='namespace_as_string') if l_0_namespace_as_string is missing else l_0_namespace_as_string), (undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), environment.getattr(l_1_method, 'name')))
            yield '\n  '
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'trace_event'), prefix='param_', method_parameters=environment.getattr(l_1_method, 'parameters'), method_name=(undefined(name='event_name') if l_1_event_name is missing else l_1_event_name), parameter_group='input_parameters', trace_event_type='_BEGIN'))
            yield '\n#else'
            l_1_event_name = ('%s::%s' % ((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), environment.getattr(l_1_method, 'name')))
            yield '\n  '
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'trace_event'), method_name=(undefined(name='event_name') if l_1_event_name is missing else l_1_event_name)))
            yield '\n#endif\n  const bool kExpectsResponse = true;\n  const bool kIsSync = true;\n  const bool kAllowInterrupt =\n      '
            if environment.getattr(l_1_method, 'allow_interrupt'):
                pass
                yield 'true'
            else:
                pass
                yield 'false'
            yield ';'
            if t_12(l_1_method):
                pass
                yield '\n  const bool kSerialize = receiver_->PrefersSerializedMessages();\n  auto message = '
                yield to_string((undefined(name='message_typename') if l_1_message_typename is missing else l_1_message_typename))
                yield '::Build(\n      kSerialize, kExpectsResponse, kIsSync, kAllowInterrupt'
                for l_2_param in environment.getattr(l_1_method, 'parameters'):
                    pass
                    yield ', std::move(param_'
                    yield to_string(environment.getattr(l_2_param, 'name'))
                    yield ')'
                l_2_param = missing
                yield ');'
            else:
                pass
                yield '\n  '
                yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'build_message_flags'), False, 'kIsSync', 'kAllowInterrupt', 'kExpectsResponse', 'kFlags'))
                yield '\n  '
                yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'build_serialized_message'), (undefined(name='message_name') if l_1_message_name is missing else l_1_message_name), l_1_method, 'param_%s', (undefined(name='params_struct') if l_1_params_struct is missing else l_1_params_struct), (undefined(name='params_description') if l_1_params_description is missing else l_1_params_description), 'kFlags', 'message'))
            yield '\n\n#if defined(ENABLE_IPC_FUZZER)\n  message.set_interface_name('
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::Name_);\n  message.set_method_name("'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '");\n#endif\n\n  bool result = false;\n  std::unique_ptr<mojo::MessageReceiver> responder(\n      new '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_HandleSyncResponse(\n          &result'
            for l_2_param in environment.getattr(l_1_method, 'response_parameters'):
                pass
                yield ', out_param_'
                yield to_string(environment.getattr(l_2_param, 'name'))
            l_2_param = missing
            yield '));\n  ::mojo::internal::SendMojoMessage(*receiver_, message, std::move(responder));\n#if BUILDFLAG(MOJO_TRACE_ENABLED)\n  '
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'trace_event'), prefix='out_param_', method_parameters=environment.getattr(l_1_method, 'response_parameters'), method_name=(undefined(name='event_name') if l_1_event_name is missing else l_1_event_name), parameter_group='sync_response_parameters', trace_event_type='_END', dereference_parameters=True))
            yield '\n#endif\n  return result;\n}'
        yield '\n\nvoid '
        yield to_string((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
        yield '::'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield '(\n    '
        yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_request_params'), 'in_', l_1_method))
        yield ') {\n#if BUILDFLAG(MOJO_TRACE_ENABLED)'
        l_1_event_name = ('Send %s::%s::%s' % ((undefined(name='namespace_as_string') if l_0_namespace_as_string is missing else l_0_namespace_as_string), (undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), environment.getattr(l_1_method, 'name')))
        yield '\n  '
        yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'trace_event'), prefix='in_', method_parameters=environment.getattr(l_1_method, 'parameters'), method_name=(undefined(name='event_name') if l_1_event_name is missing else l_1_event_name), parameter_group='input_parameters'))
        yield '\n#endif'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n  const bool kExpectsResponse = true;'
        else:
            pass
            yield '\n  const bool kExpectsResponse = false;'
        yield '\n  const bool kIsSync = false;\n  const bool kAllowInterrupt = true;'
        if t_12(l_1_method):
            pass
            yield '\n  const bool kSerialize = receiver_->PrefersSerializedMessages();\n  auto message = '
            yield to_string((undefined(name='message_typename') if l_1_message_typename is missing else l_1_message_typename))
            yield '::Build(\n      kSerialize, kExpectsResponse, kIsSync, kAllowInterrupt'
            for l_2_param in environment.getattr(l_1_method, 'parameters'):
                pass
                yield ', std::move(in_'
                yield to_string(environment.getattr(l_2_param, 'name'))
                yield ')'
            l_2_param = missing
            yield ');'
        else:
            pass
            yield '\n  '
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'build_message_flags'), False, 'kIsSync', 'kAllowInterrupt', 'kExpectsResponse', 'kFlags'))
            yield '\n  '
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'build_serialized_message'), (undefined(name='message_name') if l_1_message_name is missing else l_1_message_name), l_1_method, 'in_%s', (undefined(name='params_struct') if l_1_params_struct is missing else l_1_params_struct), (undefined(name='params_description') if l_1_params_description is missing else l_1_params_description), 'kFlags', 'message'))
        yield '\n\n#if defined(ENABLE_IPC_FUZZER)\n  message.set_interface_name('
        yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield '::Name_);\n  message.set_method_name("'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield '");\n#endif'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n  std::unique_ptr<mojo::MessageReceiver> responder(\n      new '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback(\n          std::move(callback)));\n  ::mojo::internal::SendMojoMessage(*receiver_, message, std::move(responder));'
        else:
            pass
            yield '\n  // This return value may be ignored as false implies the Connector has\n  // encountered an error, which will be visible through other means.\n  ::mojo::internal::SendMojoMessage(*receiver_, message);'
        yield '\n}'
    l_1_method = l_1_message_name = l_1_params_struct = l_1_params_description = l_1_message_typename = l_1_event_name = missing
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_message_name = resolve('message_name')
        l_1_response_params_struct = resolve('response_params_struct')
        l_1_params_description = resolve('params_description')
        l_1_response_message_typename = resolve('response_message_typename')
        l_1_desc = resolve('desc')
        l_1_event_name = resolve('event_name')
        l_1_response_params_description = resolve('response_params_description')
        pass
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            l_1_message_name = t_4('internal::k%s_%s_Name', environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), environment.getattr(l_1_method, 'name'))
            l_1_response_params_struct = environment.getattr(l_1_method, 'response_param_struct')
            l_1_params_description = t_4('%s.%s response', environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), environment.getattr(l_1_method, 'name'))
            l_1_response_message_typename = t_4('%s_%s_Response_Message', environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), environment.getattr(l_1_method, 'name'))
            yield '\nclass '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ProxyToResponder : public ::mojo::internal::ProxyToResponder {\n public:\n  static '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield 'Callback CreateCallback(\n      ::mojo::Message& message,\n      std::unique_ptr<mojo::MessageReceiverWithStatus> responder) {\n    std::unique_ptr<'
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ProxyToResponder> proxy(\n        new '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ProxyToResponder(\n            message, std::move(responder)));\n    return base::BindOnce(&'
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ProxyToResponder::Run,\n                          std::move(proxy));\n  }\n\n  ~'
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield "_ProxyToResponder() {\n#if DCHECK_IS_ON()\n    if (responder_) {\n      // If we're being destroyed without being run, we want to ensure the\n      // binding endpoint has been closed. This checks for that asynchronously.\n      // We pass a bound generated callback to handle the response so that any\n      // resulting DCHECK stack will have useful interface type information.\n      responder_->IsConnectedAsync(base::BindOnce(&OnIsConnectedComplete));\n    }\n#endif\n  }\n\n private:\n  "
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ProxyToResponder(\n      ::mojo::Message& message,\n      std::unique_ptr<mojo::MessageReceiverWithStatus> responder)\n      : ::mojo::internal::ProxyToResponder(message, std::move(responder)) {\n  }\n\n#if DCHECK_IS_ON()\n  static void OnIsConnectedComplete(bool connected) {\n    DCHECK(!connected)\n        << "'
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield 'Callback was destroyed without "\n        << "first either being run or its corresponding binding being closed. "\n        << "It is an error to drop response callbacks which still correspond "\n        << "to an open interface pipe.";\n  }\n#endif\n\n  void Run(\n      '
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_params'), 'in_', environment.getattr(l_1_method, 'response_parameters')))
            yield ');\n};'
            if t_12(l_1_method):
                pass
                yield '\n'
                yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'define_message_type'), (undefined(name='interface') if l_0_interface is missing else l_0_interface), (undefined(name='response_message_typename') if l_1_response_message_typename is missing else l_1_response_message_typename), (undefined(name='message_name') if l_1_message_name is missing else l_1_message_name), True, l_1_method, environment.getattr(l_1_method, 'response_parameters'), (undefined(name='response_params_struct') if l_1_response_params_struct is missing else l_1_response_params_struct), (undefined(name='params_description') if l_1_params_description is missing else l_1_params_description)))
            yield '\n\nbool '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback::Accept(\n    mojo::Message* message) {'
            if t_12(l_1_method):
                pass
                yield '\n  if (!message->is_serialized()) {\n    auto context =\n        message->TakeUnserializedContext<'
                yield to_string((undefined(name='response_message_typename') if l_1_response_message_typename is missing else l_1_response_message_typename))
                yield '>();\n    if (!context) {\n      // The Message was not of the expected type. It may be a valid message\n      // which was build using a different variant of these bindings. Force\n      // serialization before dispatch in this case.\n      message->SerializeIfNecessary();\n    } else {\n      if (!callback_.is_null())\n        context->Dispatch(message, &callback_);\n      return true;\n    }\n  }'
            yield '\n\n  DCHECK(message->is_serialized());\n  internal::'
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ResponseParams_Data* params =\n      reinterpret_cast<\n          internal::'
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ResponseParams_Data*>(\n              message->mutable_payload());'
            l_1_desc = unicode_join(((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), '::', environment.getattr(l_1_method, 'name'), ' response', ))
            yield '\n  '
            yield to_string(context.call((undefined(name='alloc_params') if l_0_alloc_params is missing else l_0_alloc_params), environment.getattr(l_1_method, 'response_param_struct'), 'params', 'message', environment.getattr(l_1_method, 'sequential_ordinal'), 'true'))
            yield '\n  if (!callback_.is_null())\n    std::move(callback_).Run('
            yield to_string(context.call((undefined(name='pass_params') if l_0_pass_params is missing else l_0_pass_params), environment.getattr(l_1_method, 'response_parameters')))
            yield ');\n  return true;\n}\n\nvoid '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ProxyToResponder::Run(\n    '
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_params'), 'in_', environment.getattr(l_1_method, 'response_parameters')))
            yield ') {\n#if BUILDFLAG(MOJO_TRACE_ENABLED)'
            l_1_event_name = ('Send reply %s::%s::%s' % ((undefined(name='namespace_as_string') if l_0_namespace_as_string is missing else l_0_namespace_as_string), (undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), environment.getattr(l_1_method, 'name')))
            yield '\n  '
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'trace_event'), prefix='in_', method_parameters=environment.getattr(l_1_method, 'response_parameters'), method_name=(undefined(name='event_name') if l_1_event_name is missing else l_1_event_name), parameter_group='async_response_parameters', dereference_parameters=False))
            yield '\n#endif'
            if t_12(l_1_method):
                pass
                yield '\n  const bool kSerialize = responder_->PrefersSerializedMessages();\n  auto message = '
                yield to_string((undefined(name='response_message_typename') if l_1_response_message_typename is missing else l_1_response_message_typename))
                yield '::Build(kSerialize, is_sync_,\n      true'
                for l_2_param in environment.getattr(l_1_method, 'response_parameters'):
                    pass
                    yield ', std::move(in_'
                    yield to_string(environment.getattr(l_2_param, 'name'))
                    yield ')'
                l_2_param = missing
                yield ');'
            else:
                pass
                yield '\n  '
                yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'build_message_flags'), True, 'is_sync_', 'true', 'false', 'kFlags'))
                yield '\n  '
                yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'build_serialized_message'), (undefined(name='message_name') if l_1_message_name is missing else l_1_message_name), l_1_method, 'in_%s', (undefined(name='response_params_struct') if l_1_response_params_struct is missing else l_1_response_params_struct), (undefined(name='response_params_description') if l_1_response_params_description is missing else l_1_response_params_description), 'kFlags', 'message'))
            yield '\n\n#if defined(ENABLE_IPC_FUZZER)\n  message.set_interface_name('
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::Name_);\n  message.set_method_name("'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '");\n#endif\n\n  message.set_request_id(request_id_);\n  message.set_trace_nonce(trace_nonce_);\n  ::mojo::internal::SendMojoMessage(*responder_, message);\n  // SendMojoMessage() fails silently if the responder connection is closed,\n  // or if the message is malformed.\n  //\n  // TODO(darin): If Accept() returns false due to a malformed message, that\n  // may be good reason to close the connection. However, we don\'t have a\n  // way to do that from here. We should add a way.\n  responder_ = nullptr;\n}'
        if environment.getattr(l_1_method, 'sync'):
            pass
            yield '\nbool '
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_HandleSyncResponse::Accept(\n    mojo::Message* message) {'
            if t_12(l_1_method):
                pass
                yield '\n  if (!message->is_serialized()) {\n    auto context =\n        message->TakeUnserializedContext<'
                yield to_string((undefined(name='response_message_typename') if l_1_response_message_typename is missing else l_1_response_message_typename))
                yield '>();\n    if (!context) {\n      // The Message was not of the expected type. It may be a valid message\n      // which was built using a different variant of these bindings. Force\n      // serialization before dispatch in this case.\n      message->SerializeIfNecessary();\n    } else {\n      context->HandleSyncResponse(\n          message'
                for l_2_param in environment.getattr(l_1_method, 'response_parameters'):
                    pass
                    yield ',\n          out_'
                    yield to_string(environment.getattr(l_2_param, 'name'))
                    yield '_'
                l_2_param = missing
                yield ');\n      *result_ = true;\n      return true;\n    }\n  }'
            yield '\n\n  DCHECK(message->is_serialized());\n  internal::'
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ResponseParams_Data* params =\n      reinterpret_cast<internal::'
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_ResponseParams_Data*>(\n          message->mutable_payload());'
            l_1_desc = unicode_join(((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), '::', environment.getattr(l_1_method, 'name'), ' response', ))
            yield '\n  '
            yield to_string(context.call((undefined(name='alloc_params') if l_0_alloc_params is missing else l_0_alloc_params), environment.getattr(l_1_method, 'response_param_struct'), 'params', 'message', environment.getattr(l_1_method, 'sequential_ordinal'), 'true'))
            for l_2_param in environment.getattr(l_1_method, 'response_parameters'):
                pass
                yield '\n  *out_'
                yield to_string(environment.getattr(l_2_param, 'name'))
                yield '_ = std::move(p_'
                yield to_string(environment.getattr(l_2_param, 'name'))
                yield ');'
            l_2_param = missing
            yield '\n  *result_ = true;\n  return true;\n}'
    l_1_method = l_1_message_name = l_1_response_params_struct = l_1_params_description = l_1_response_message_typename = l_1_desc = l_1_event_name = l_1_response_params_description = missing
    yield '\n\n// static\nbool '
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield 'StubDispatch::Accept(\n    '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '* impl,\n    mojo::Message* message) {'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        yield '\n  switch (message->header()->name) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            l_1_desc = resolve('desc')
            pass
            yield '\n    case internal::k'
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_Name: {'
            if (environment.getattr(l_1_method, 'response_parameters') == None):
                pass
                if t_12(l_1_method):
                    pass
                    yield '\n      if (!message->is_serialized()) {\n        auto context = message->TakeUnserializedContext<\n            '
                    yield to_string((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
                    yield '_'
                    yield to_string(environment.getattr(l_1_method, 'name'))
                    yield '_Message>();\n        if (!context) {\n          // The Message was not of the expected type. It may be a valid message\n          // which was serialized using a different variant of these bindings.\n          // Force serialization before dispatch in this case.\n          message->SerializeIfNecessary();\n        } else {\n          context->Dispatch(message, impl);\n          return true;\n        }\n      }'
                yield '\n\n      DCHECK(message->is_serialized());\n      internal::'
                yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '_Params_Data* params =\n          reinterpret_cast<internal::'
                yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '_Params_Data*>(\n              message->mutable_payload());'
                l_1_desc = unicode_join(((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), '::', environment.getattr(l_1_method, 'name'), ))
                yield '\n      '
                yield to_string(t_7(context.call((undefined(name='alloc_params') if l_0_alloc_params is missing else l_0_alloc_params), environment.getattr(l_1_method, 'param_struct'), 'params', 'message', environment.getattr(l_1_method, 'sequential_ordinal'), 'false'), 4))
                yield '\n      // A null |impl| means no implementation was bound.\n      DCHECK(impl);\n      impl->'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '('
                yield to_string(context.call((undefined(name='pass_params') if l_0_pass_params is missing else l_0_pass_params), environment.getattr(l_1_method, 'parameters')))
                yield ');\n      return true;'
            else:
                pass
                yield '\n      break;'
            yield '\n    }'
        l_1_method = l_1_desc = missing
        yield '\n  }'
    yield '\n  return false;\n}\n\n// static\nbool '
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield 'StubDispatch::AcceptWithResponder(\n    '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '* impl,\n    mojo::Message* message,\n    std::unique_ptr<mojo::MessageReceiverWithStatus> responder) {'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        yield '\n  [[maybe_unused]] const bool message_is_sync =\n      message->has_flag(mojo::Message::kFlagIsSync);\n  [[maybe_unused]] const uint64_t request_id = message->request_id();\n  switch (message->header()->name) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            l_1_desc = resolve('desc')
            pass
            yield '\n    case internal::k'
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_Name: {'
            if (environment.getattr(l_1_method, 'response_parameters') != None):
                pass
                if t_12(l_1_method):
                    pass
                    yield '\n      if (!message->is_serialized()) {\n        auto context = message->TakeUnserializedContext<\n            '
                    yield to_string((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
                    yield '_'
                    yield to_string(environment.getattr(l_1_method, 'name'))
                    yield '_Message>();\n        if (!context) {\n          // The Message was not of the expected type. It may be a valid message\n          // which was built using a different variant of these bindings. Force\n          // serialization before dispatch in this case.\n          message->SerializeIfNecessary();\n        } else {\n          '
                    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                    yield '::'
                    yield to_string(environment.getattr(l_1_method, 'name'))
                    yield 'Callback callback =\n              '
                    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                    yield '_'
                    yield to_string(environment.getattr(l_1_method, 'name'))
                    yield '_ProxyToResponder::CreateCallback(\n                  *message, std::move(responder));\n          context->Dispatch(message, impl, std::move(callback));\n          return true;\n        }\n      }'
                yield '\n\n      internal::'
                yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '_Params_Data* params =\n          reinterpret_cast<\n              internal::'
                yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '_Params_Data*>(\n                  message->mutable_payload());'
                l_1_desc = unicode_join(((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), '::', environment.getattr(l_1_method, 'name'), ))
                yield '\n      '
                yield to_string(t_7(context.call((undefined(name='alloc_params') if l_0_alloc_params is missing else l_0_alloc_params), environment.getattr(l_1_method, 'param_struct'), 'params', 'message', environment.getattr(l_1_method, 'sequential_ordinal'), 'false'), 4))
                yield '\n      '
                yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '::'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield 'Callback callback =\n          '
                yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '_ProxyToResponder::CreateCallback(\n              *message, std::move(responder));\n      // A null |impl| means no implementation was bound.\n      DCHECK(impl);\n      impl->'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '('
                if environment.getattr(l_1_method, 'parameters'):
                    pass
                    yield to_string(context.call((undefined(name='pass_params') if l_0_pass_params is missing else l_0_pass_params), environment.getattr(l_1_method, 'parameters')))
                    yield ', '
                yield 'std::move(callback));\n      return true;'
            else:
                pass
                yield '\n      break;'
            yield '\n    }'
        l_1_method = l_1_desc = missing
        yield '\n  }'
    yield '\n  return false;\n}\n\n'
    if (environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods') and t_6((undefined(name='interface') if l_0_interface is missing else l_0_interface))):
        pass
        yield '\nstatic const mojo::internal::GenericValidationInfo k'
        yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield 'ValidationInfo[] = {'
        for l_1_i in context.call((undefined(name='range') if l_0_range is missing else l_0_range), (t_11(environment, t_10(context, environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), attribute='ordinal')) + 1)):
            l_1_method = missing
            pass
            l_1_method = environment.getitem(t_9(t_14(context, environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), 'ordinal', 'equalto', l_1_i)), 0)
            if (undefined(name='method') if l_1_method is missing else l_1_method):
                pass
                yield '\n    {&internal::'
                yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield to_string(environment.getattr((undefined(name='method') if l_1_method is missing else l_1_method), 'name'))
                yield '_Params_Data::Validate,'
                if (environment.getattr((undefined(name='method') if l_1_method is missing else l_1_method), 'response_parameters') != None):
                    pass
                    yield '\n     &internal::'
                    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                    yield '_'
                    yield to_string(environment.getattr((undefined(name='method') if l_1_method is missing else l_1_method), 'name'))
                    yield '_ResponseParams_Data::Validate},'
                else:
                    pass
                    yield '\n     nullptr /* no response */},'
            else:
                pass
                yield '\n    {nullptr, nullptr},  // nonexistent'
        l_1_i = l_1_method = missing
        yield '\n};'
    elif environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        yield '\nstatic const std::pair<uint32_t, mojo::internal::GenericValidationInfo> k'
        yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield 'ValidationInfo[] = {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            pass
            yield '\n    {internal::k'
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_Name,\n     {&internal::'
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '_Params_Data::Validate,'
            if (environment.getattr(l_1_method, 'response_parameters') != None):
                pass
                yield '\n      &internal::'
                yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '_ResponseParams_Data::Validate}},'
            else:
                pass
                yield '\n      nullptr /* no response */}},'
        l_1_method = missing
        yield '\n};'
    yield '\n\nbool '
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield 'RequestValidator::Accept(mojo::Message* message) {\n  const char* name = '
    yield to_string((undefined(name='qualified_class_name') if l_0_qualified_class_name is missing else l_0_qualified_class_name))
    yield '::Name_;'
    if (not environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods')):
        pass
        yield '\n  return mojo::internal::ValidateRequestGeneric(message, name, {});'
    elif t_6((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield '\n  return mojo::internal::ValidateRequestGenericPacked(message, name, k'
        yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield 'ValidationInfo);'
    else:
        pass
        yield '\n  return mojo::internal::ValidateRequestGeneric(message, name, k'
        yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield 'ValidationInfo);'
    yield '\n}\n'
    if t_5((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield '\nbool '
        yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield 'ResponseValidator::Accept(mojo::Message* message) {\n  const char* name = '
        yield to_string((undefined(name='qualified_class_name') if l_0_qualified_class_name is missing else l_0_qualified_class_name))
        yield '::Name_;'
        if t_6((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
            pass
            yield '\n  return mojo::internal::ValidateResponseGenericPacked(message, name, k'
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield 'ValidationInfo);'
        else:
            pass
            yield '\n  return mojo::internal::ValidateResponseGeneric(message, name, k'
            yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield 'ValidationInfo);\n'
        yield '\n}'

blocks = {}
debug_info = '1=30&2=32&4=34&5=37&6=40&7=43&8=46&10=49&12=65&13=69&15=77&16=83&19=85&21=87&26=97&27=103&28=107&29=110&34=120&35=126&36=129&40=131&41=133&42=136&44=145&48=153&50=157&52=160&53=163&54=167&64=174&66=176&70=179&71=182&72=186&77=194&78=197&79=201&96=210&97=213&105=217&113=225&114=227&115=230&123=237&124=239&125=241&126=244&129=248&131=252&132=255&135=260&136=263&141=269&142=277&147=285&148=288&153=295&156=299&157=303&161=307&162=315&166=323&171=329&177=333&178=337&180=338&181=339&183=340&185=341&186=344&191=345&192=348&193=352&195=354&197=356&204=358&205=360&210=362&211=369&213=372&215=374&216=377&219=384&221=386&227=388&228=390&233=392&235=396&236=399&240=402&251=405&252=409&254=411&256=413&261=415&268=422&270=425&272=427&273=430&276=437&278=439&284=441&285=443&288=445&290=448&302=457&303=466&304=468&306=469&307=470&309=471&311=473&313=477&316=481&317=485&319=489&323=493&336=497&345=501&353=505&356=507&357=510&362=512&364=516&367=519&382=522&384=526&387=530&388=532&390=534&394=536&395=540&397=542&399=544&405=546&407=549&409=551&410=554&413=561&415=563&421=565&422=567&438=569&439=572&441=576&444=579&453=581&454=584&463=589&464=593&467=597&468=599&470=600&471=603&483=611&484=613&486=615&488=618&489=622&490=626&491=628&494=631&508=636&509=640&512=644&514=646&517=648&530=659&531=661&534=663&539=666&540=670&541=674&542=676&545=679&552=683&553=687&561=692&563=696&566=700&568=702&569=704&570=708&574=712&575=714&587=726&588=729&589=731&590=734&591=735&592=738&593=742&594=745&603=757&604=760&605=762&606=765&607=769&608=773&609=776&619=786&621=788&622=790&624=793&625=796&627=801&632=804&633=807&634=809&635=811&636=814&638=819'