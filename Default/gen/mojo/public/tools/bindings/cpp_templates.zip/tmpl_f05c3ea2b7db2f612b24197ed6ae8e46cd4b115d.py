from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'module-import-headers.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_variant = resolve('variant')
    l_0_module = resolve('module')
    l_0_variant_path = resolve('variant_path')
    l_0_imports = resolve('imports')
    l_0_header_guard = missing
    t_1 = environment.filters['format']
    t_2 = environment.filters['replace']
    t_3 = environment.filters['upper']
    pass
    yield '// Copyright 2019 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
        pass
        l_0_variant_path = t_1('%s-%s', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant))
        context.vars['variant_path'] = l_0_variant_path
        context.exported_vars.add('variant_path')
    else:
        pass
        l_0_variant_path = environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path')
        context.vars['variant_path'] = l_0_variant_path
        context.exported_vars.add('variant_path')
    l_0_header_guard = t_1('%s_IMPORT_HEADERS_H_', t_2(context.eval_ctx, t_2(context.eval_ctx, t_2(context.eval_ctx, t_3((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path)), '/', '_'), '.', '_'), '-', '_'))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    yield '\n\n#ifndef '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    for l_1_import in (undefined(name='imports') if l_0_imports is missing else l_0_imports):
        pass
        if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
            pass
            yield '\n#include "'
            yield to_string(t_1('%s-%s.h', environment.getattr(l_1_import, 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
            yield '"\n#include "'
            yield to_string(t_1('%s-%s-import-headers.h', environment.getattr(l_1_import, 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
            yield '"'
        else:
            pass
            yield '\n#include "'
            yield to_string(environment.getattr(l_1_import, 'path'))
            yield '.h"\n#include "'
            yield to_string(environment.getattr(l_1_import, 'path'))
            yield '-import-headers.h"'
    l_1_import = missing
    yield '\n\n#endif  // '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=20&6=22&8=27&11=30&15=34&16=36&18=37&19=39&20=42&21=44&23=49&24=51&28=55'