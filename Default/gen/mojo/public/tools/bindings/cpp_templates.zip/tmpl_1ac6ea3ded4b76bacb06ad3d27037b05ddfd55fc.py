from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'union_traits_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_export_attribute = resolve('export_attribute')
    l_0_mojom_type = missing
    t_1 = environment.filters['contains_handles_or_interfaces']
    t_2 = environment.filters['cpp_union_trait_getter_return_type']
    t_3 = environment.filters['get_qualified_name_for_kind']
    t_4 = environment.filters['is_reference_kind']
    pass
    l_0_mojom_type = t_3((undefined(name='union') if l_0_union is missing else l_0_union))
    context.vars['mojom_type'] = l_0_mojom_type
    context.exported_vars.add('mojom_type')
    yield '\n\ntemplate <>\nstruct '
    yield to_string((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' UnionTraits<'
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView,\n                                        '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr> {\n  static bool IsNull(const '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr& input) { return !input; }\n  static void SetToNull('
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr* output) { output->reset(); }\n\n  static '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::Tag GetTag(const '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr& input) {\n    return input->which();\n  }'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        l_1_maybe_const_in = l_1_maybe_const_out = missing
        pass
        l_1_maybe_const_in = ('' if t_1(environment.getattr(l_1_field, 'kind')) else 'const')
        l_1_maybe_const_out = ('' if (t_1(environment.getattr(l_1_field, 'kind')) or (not t_4(environment.getattr(l_1_field, 'kind')))) else 'const')
        yield '\n\n  static '
        yield to_string((undefined(name='maybe_const_out') if l_1_maybe_const_out is missing else l_1_maybe_const_out))
        yield ' '
        yield to_string(t_2(environment.getattr(l_1_field, 'kind')))
        yield ' '
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield '('
        yield to_string((undefined(name='maybe_const_in') if l_1_maybe_const_in is missing else l_1_maybe_const_in))
        yield ' '
        yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
        yield 'Ptr& input) {\n    return input->get_'
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield '();\n  }'
    l_1_field = l_1_maybe_const_in = l_1_maybe_const_out = missing
    yield '\n\n  static bool Read('
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView input, '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr* output);\n};'

blocks = {}
debug_info = '1=18&4=22&5=26&6=28&7=30&9=32&13=36&14=39&15=40&18=42&19=52&23=56'