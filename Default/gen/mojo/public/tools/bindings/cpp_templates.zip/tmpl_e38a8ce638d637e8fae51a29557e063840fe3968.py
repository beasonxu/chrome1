from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'interface_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct_macros = l_0_declare_params = l_0_declare_callback = l_0_declare_request_params = l_0_trace_event = l_0_declare_sync_method_params = l_0_build_message_flags = l_0_build_serialized_message = l_0_define_message_type = missing
    t_1 = environment.filters['cpp_wrapper_call_type']
    t_2 = environment.filters['cpp_wrapper_param_type']
    t_3 = environment.filters['cpp_wrapper_type']
    t_4 = environment.filters['get_name_for_kind']
    t_5 = environment.filters['get_qualified_name_for_kind']
    t_6 = environment.filters['is_interface_kind']
    t_7 = environment.filters['is_receiver_kind']
    pass
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'interface_macros.tmpl')._get_default_module()
    context.exported_vars.discard('struct_macros')
    def macro(l_1_prefix, l_1_parameters):
        t_8 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_parameters is missing:
            l_1_parameters = undefined("parameter 'parameters' was not provided", name='parameters')
        pass
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(l_1_parameters, undefined):
            pass
            t_8.extend((
                to_string(t_2(environment.getattr(l_2_param, 'kind'))),
                ' ',
                to_string(l_1_prefix),
                to_string(environment.getattr(l_2_param, 'name')),
            ))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_8.append(
                    ', ',
                )
        l_2_loop = l_2_param = missing
        return concat(t_8)
    context.exported_vars.add('declare_params')
    context.vars['declare_params'] = l_0_declare_params = Macro(environment, macro, 'declare_params', ('prefix', 'parameters'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_method, l_1_for_blink):
        t_9 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_for_blink is missing:
            l_1_for_blink = undefined("parameter 'for_blink' was not provided", name='for_blink')
        pass
        t_9.append(
            'base::OnceCallback<void(',
        )
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'response_parameters'), undefined):
            pass
            t_9.append(
                to_string(t_2(environment.getattr(l_2_param, 'kind'))),
            )
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_9.append(
                    ', ',
                )
        l_2_loop = l_2_param = missing
        t_9.append(
            ')>',
        )
        return concat(t_9)
    context.exported_vars.add('declare_callback')
    context.vars['declare_callback'] = l_0_declare_callback = Macro(environment, macro, 'declare_callback', ('method', 'for_blink'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_prefix, l_1_method):
        t_10 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_10.append(
            to_string(context.call((undefined(name='declare_params') if l_0_declare_params is missing else l_0_declare_params), l_1_prefix, environment.getattr(l_1_method, 'parameters'))),
        )
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            if environment.getattr(l_1_method, 'parameters'):
                pass
                t_10.append(
                    ', ',
                )
            t_10.extend((
                to_string(environment.getattr(l_1_method, 'name')),
                'Callback callback',
            ))
        return concat(t_10)
    context.exported_vars.add('declare_request_params')
    context.vars['declare_request_params'] = l_0_declare_request_params = Macro(environment, macro, 'declare_request_params', ('prefix', 'method'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_prefix, l_1_method_parameters, l_1_method_name, l_1_parameter_group, l_1_trace_event_type, l_1_dereference_parameters):
        t_11 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_method_parameters is missing:
            l_1_method_parameters = undefined("parameter 'method_parameters' was not provided", name='method_parameters')
        if l_1_method_name is missing:
            l_1_method_name = undefined("parameter 'method_name' was not provided", name='method_name')
        if l_1_parameter_group is missing:
            l_1_parameter_group = undefined("parameter 'parameter_group' was not provided", name='parameter_group')
        if l_1_trace_event_type is missing:
            l_1_trace_event_type = ''
        if l_1_dereference_parameters is missing:
            l_1_dereference_parameters = False
        pass
        if l_1_method_parameters:
            pass
            t_11.extend((
                'TRACE_EVENT',
                to_string(l_1_trace_event_type),
                '1(\n    "mojom", "',
                to_string(l_1_method_name),
                '", "',
                to_string(l_1_parameter_group),
                '",\n    [&](perfetto::TracedValue context){\n      auto dict = std::move(context).WriteDictionary();',
            ))
            for l_2_param in l_1_method_parameters:
                pass
                t_11.extend((
                    '\n      perfetto::WriteIntoTracedValueWithFallback(\n           dict.AddItem("',
                    to_string(environment.getattr(l_2_param, 'name')),
                    '"), ',
                    to_string((l_1_prefix + environment.getattr(l_2_param, 'name'))),
                    ',\n                        "<value of type ',
                    to_string(t_2(environment.getattr(l_2_param, 'kind'))),
                    '>");',
                ))
            l_2_param = missing
            t_11.append(
                '\n   });',
            )
        else:
            pass
            t_11.extend((
                'TRACE_EVENT',
                to_string(l_1_trace_event_type),
                '0("mojom", "',
                to_string(l_1_method_name),
                '");',
            ))
        return concat(t_11)
    context.exported_vars.add('trace_event')
    context.vars['trace_event'] = l_0_trace_event = Macro(environment, macro, 'trace_event', ('prefix', 'method_parameters', 'method_name', 'parameter_group', 'trace_event_type', 'dereference_parameters'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_prefix, l_1_method):
        t_12 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_12.append(
            to_string(context.call((undefined(name='declare_params') if l_0_declare_params is missing else l_0_declare_params), l_1_prefix, environment.getattr(l_1_method, 'parameters'))),
        )
        if environment.getattr(l_1_method, 'response_parameters'):
            pass
            if environment.getattr(l_1_method, 'parameters'):
                pass
                t_12.append(
                    ', ',
                )
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'response_parameters'), undefined):
                pass
                t_12.extend((
                    to_string(t_1(environment.getattr(l_2_param, 'kind'))),
                    '* out_',
                    to_string(l_1_prefix),
                    to_string(environment.getattr(l_2_param, 'name')),
                ))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    t_12.append(
                        ', ',
                    )
            l_2_loop = l_2_param = missing
        return concat(t_12)
    context.exported_vars.add('declare_sync_method_params')
    context.vars['declare_sync_method_params'] = l_0_declare_sync_method_params = Macro(environment, macro, 'declare_sync_method_params', ('prefix', 'method'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_is_response, l_1_is_sync_text, l_1_allow_interrupt_text, l_1_expects_response_text, l_1_flags_name):
        t_13 = []
        if l_1_is_response is missing:
            l_1_is_response = undefined("parameter 'is_response' was not provided", name='is_response')
        if l_1_is_sync_text is missing:
            l_1_is_sync_text = undefined("parameter 'is_sync_text' was not provided", name='is_sync_text')
        if l_1_allow_interrupt_text is missing:
            l_1_allow_interrupt_text = undefined("parameter 'allow_interrupt_text' was not provided", name='allow_interrupt_text')
        if l_1_expects_response_text is missing:
            l_1_expects_response_text = undefined("parameter 'expects_response_text' was not provided", name='expects_response_text')
        if l_1_flags_name is missing:
            l_1_flags_name = undefined("parameter 'flags_name' was not provided", name='flags_name')
        pass
        if l_1_is_response:
            pass
            t_13.extend((
                '\n  const uint32_t kFlags = mojo::Message::kFlagIsResponse |\n      ((',
                to_string(l_1_is_sync_text),
                ') ? mojo::Message::kFlagIsSync : 0) |\n      ((',
                to_string(l_1_allow_interrupt_text),
                ') ? 0 : mojo::Message::kFlagNoInterrupt);',
            ))
        else:
            pass
            t_13.extend((
                '\n  const uint32_t kFlags =\n      ((',
                to_string(l_1_expects_response_text),
                ') ? mojo::Message::kFlagExpectsResponse : 0) |\n      ((',
                to_string(l_1_is_sync_text),
                ') ? mojo::Message::kFlagIsSync : 0) |\n      ((',
                to_string(l_1_allow_interrupt_text),
                ') ? 0 : mojo::Message::kFlagNoInterrupt);',
            ))
        return concat(t_13)
    context.exported_vars.add('build_message_flags')
    context.vars['build_message_flags'] = l_0_build_message_flags = Macro(environment, macro, 'build_message_flags', ('is_response', 'is_sync_text', 'allow_interrupt_text', 'expects_response_text', 'flags_name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_message_name, l_1_method, l_1_param_name_prefix, l_1_params_struct, l_1_params_description, l_1_flags_text, l_1_message_object_name):
        t_14 = []
        if l_1_message_name is missing:
            l_1_message_name = undefined("parameter 'message_name' was not provided", name='message_name')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_param_name_prefix is missing:
            l_1_param_name_prefix = undefined("parameter 'param_name_prefix' was not provided", name='param_name_prefix')
        if l_1_params_struct is missing:
            l_1_params_struct = undefined("parameter 'params_struct' was not provided", name='params_struct')
        if l_1_params_description is missing:
            l_1_params_description = undefined("parameter 'params_description' was not provided", name='params_description')
        if l_1_flags_text is missing:
            l_1_flags_text = undefined("parameter 'flags_text' was not provided", name='flags_text')
        if l_1_message_object_name is missing:
            l_1_message_object_name = undefined("parameter 'message_object_name' was not provided", name='message_object_name')
        pass
        if environment.getattr(l_1_method, 'unlimited_message_size'):
            pass
            t_14.extend((
                '\n  mojo::Message ',
                to_string(l_1_message_object_name),
                '(\n      ',
                to_string(l_1_message_name),
                ', ',
                to_string(l_1_flags_text),
                ', 0, 0,\n      MOJO_CREATE_MESSAGE_FLAG_UNLIMITED_SIZE, nullptr);',
            ))
        else:
            pass
            t_14.extend((
                '\n  mojo::Message ',
                to_string(l_1_message_object_name),
                '(\n      ',
                to_string(l_1_message_name),
                ', ',
                to_string(l_1_flags_text),
                ', 0, 0, nullptr);',
            ))
        t_14.extend((
            '\n  mojo::internal::MessageFragment<\n      ',
            to_string(t_5(l_1_params_struct, internal=True)),
            '> params(\n          ',
            to_string(l_1_message_object_name),
            ');\n  ',
            to_string(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'serialize'), l_1_params_struct, l_1_params_description, l_1_param_name_prefix, 'params')),
        ))
        return concat(t_14)
    context.exported_vars.add('build_serialized_message')
    context.vars['build_serialized_message'] = l_0_build_serialized_message = Macro(environment, macro, 'build_serialized_message', ('message_name', 'method', 'param_name_prefix', 'params_struct', 'params_description', 'flags_text', 'message_object_name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_interface, l_1_message_typename, l_1_message_name, l_1_is_response, l_1_method, l_1_parameters, l_1_params_struct, l_1_params_description):
        t_15 = []
        if l_1_interface is missing:
            l_1_interface = undefined("parameter 'interface' was not provided", name='interface')
        if l_1_message_typename is missing:
            l_1_message_typename = undefined("parameter 'message_typename' was not provided", name='message_typename')
        if l_1_message_name is missing:
            l_1_message_name = undefined("parameter 'message_name' was not provided", name='message_name')
        if l_1_is_response is missing:
            l_1_is_response = undefined("parameter 'is_response' was not provided", name='is_response')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_parameters is missing:
            l_1_parameters = undefined("parameter 'parameters' was not provided", name='parameters')
        if l_1_params_struct is missing:
            l_1_params_struct = undefined("parameter 'params_struct' was not provided", name='params_struct')
        if l_1_params_description is missing:
            l_1_params_description = undefined("parameter 'params_description' was not provided", name='params_description')
        pass
        t_15.extend((
            'class ',
            to_string(l_1_message_typename),
            '\n    : public mojo::internal::UnserializedMessageContext {\n public:\n  static const mojo::internal::UnserializedMessageContext::Tag kMessageTag;\n\n  explicit ',
            to_string(l_1_message_typename),
            '(\n      uint32_t message_flags',
        ))
        for l_2_param in l_1_parameters:
            pass
            t_15.extend((
                '\n      , ',
                to_string(t_2(environment.getattr(l_2_param, 'kind'))),
                ' param_',
                to_string(environment.getattr(l_2_param, 'name')),
            ))
        l_2_param = missing
        t_15.extend((
            '\n  )\n      : mojo::internal::UnserializedMessageContext(\n          &kMessageTag,\n          ',
            to_string(l_1_message_name),
            ',\n          message_flags)',
        ))
        for l_2_param in l_1_parameters:
            pass
            if t_6(environment.getattr(l_2_param, 'kind')):
                pass
                t_15.extend((
                    '\n      , param_',
                    to_string(environment.getattr(l_2_param, 'name')),
                    '_(param_',
                    to_string(environment.getattr(l_2_param, 'name')),
                    '.PassInterface())',
                ))
            else:
                pass
                t_15.extend((
                    '\n      , param_',
                    to_string(environment.getattr(l_2_param, 'name')),
                    '_(std::move(param_',
                    to_string(environment.getattr(l_2_param, 'name')),
                    '))',
                ))
        l_2_param = missing
        t_15.extend((
            '{}\n\n  ',
            to_string(l_1_message_typename),
            '(const ',
            to_string(l_1_message_typename),
            '&) = delete;\n  ',
            to_string(l_1_message_typename),
            '& operator=(const ',
            to_string(l_1_message_typename),
            '&) = delete;\n\n  ~',
            to_string(l_1_message_typename),
            '() override = default;\n\n  static mojo::Message Build(\n      bool serialize,',
        ))
        if (not l_1_is_response):
            pass
            t_15.append(
                '\n      bool expects_response,',
            )
        t_15.append(
            '\n      bool is_sync,\n      bool allow_interrupt',
        )
        if l_1_parameters:
            pass
            t_15.extend((
                ',\n      ',
                to_string(context.call((undefined(name='declare_params') if l_0_declare_params is missing else l_0_declare_params), 'param_', l_1_parameters)),
            ))
        t_15.extend((
            ') {\n\n    ',
            to_string(context.call((undefined(name='build_message_flags') if l_0_build_message_flags is missing else l_0_build_message_flags), l_1_is_response, 'is_sync', 'allow_interrupt', 'expects_response', 'kFlags')),
            '\n\n    if (!serialize) {\n      return mojo::Message(std::make_unique<',
            to_string(l_1_message_typename),
            '>(\n          kFlags',
        ))
        for l_2_param in l_1_parameters:
            pass
            t_15.extend((
                '\n          , std::move(param_',
                to_string(environment.getattr(l_2_param, 'name')),
                ')',
            ))
        l_2_param = missing
        t_15.append(
            '\n          ),',
        )
        if environment.getattr(l_1_method, 'unlimited_message_size'):
            pass
            t_15.append(
                '\n          MOJO_CREATE_MESSAGE_FLAG_UNLIMITED_SIZE);',
            )
        else:
            pass
            t_15.append(
                '\n          MOJO_CREATE_MESSAGE_FLAG_NONE);',
            )
        t_15.extend((
            '\n    }\n\n    DCHECK(serialize);\n    ',
            to_string(context.call((undefined(name='build_serialized_message') if l_0_build_serialized_message is missing else l_0_build_serialized_message), l_1_message_name, l_1_method, 'param_%s', l_1_params_struct, l_1_params_description, 'kFlags', 'message')),
            '\n    return message;\n  }\n\n',
        ))
        if (not l_1_is_response):
            pass
            t_15.extend((
                '\n  void Dispatch(\n      mojo::Message* message,\n      ',
                to_string(environment.getattr(l_1_interface, 'name')),
                '* impl',
            ))
            if (environment.getattr(l_1_method, 'response_parameters') != None):
                pass
                t_15.extend((
                    ', ',
                    to_string(environment.getattr(l_1_interface, 'name')),
                    '::',
                    to_string(environment.getattr(l_1_method, 'name')),
                    'Callback callback',
                ))
            t_15.append(
                ') {\n    if (message->receiver_connection_group()) {',
            )
            for l_2_param in l_1_parameters:
                pass
                if t_7(environment.getattr(l_2_param, 'kind')):
                    pass
                    t_15.extend((
                        '\n      param_',
                        to_string(environment.getattr(l_2_param, 'name')),
                        '_.set_connection_group(\n          *message->receiver_connection_group());',
                    ))
            l_2_param = missing
            t_15.extend((
                '\n    }\n\n    impl->',
                to_string(environment.getattr(l_1_method, 'name')),
                '(',
            ))
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(l_1_parameters, undefined):
                pass
                if t_6(environment.getattr(l_2_param, 'kind')):
                    pass
                    t_15.extend((
                        '\n        ',
                        to_string(t_4(environment.getattr(l_2_param, 'kind'))),
                        'Ptr(std::move(param_',
                        to_string(environment.getattr(l_2_param, 'name')),
                        '_))',
                    ))
                else:
                    pass
                    t_15.extend((
                        '\n        std::move(param_',
                        to_string(environment.getattr(l_2_param, 'name')),
                        '_)',
                    ))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    t_15.append(
                        ',',
                    )
            l_2_loop = l_2_param = missing
            if (environment.getattr(l_1_method, 'response_parameters') != None):
                pass
                if l_1_parameters:
                    pass
                    t_15.append(
                        ', ',
                    )
                t_15.append(
                    'std::move(callback)',
                )
            t_15.append(
                ');\n  }',
            )
        else:
            pass
            t_15.extend((
                '\n  void Dispatch(mojo::Message* message,\n                ',
                to_string(environment.getattr(l_1_interface, 'name')),
                '::',
                to_string(environment.getattr(l_1_method, 'name')),
                'Callback* callback) {\n    if (message->receiver_connection_group()) {',
            ))
            for l_2_param in l_1_parameters:
                pass
                if t_7(environment.getattr(l_2_param, 'kind')):
                    pass
                    t_15.extend((
                        '\n      param_',
                        to_string(environment.getattr(l_2_param, 'name')),
                        '_.set_connection_group(\n          *message->receiver_connection_group());',
                    ))
            l_2_param = missing
            t_15.append(
                '\n    }\n\n    std::move(*callback).Run(',
            )
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(l_1_parameters, undefined):
                pass
                if t_6(environment.getattr(l_2_param, 'kind')):
                    pass
                    t_15.extend((
                        '\n        ',
                        to_string(t_4(environment.getattr(l_2_param, 'kind'))),
                        'Ptr(std::move(param_',
                        to_string(environment.getattr(l_2_param, 'name')),
                        '_))',
                    ))
                else:
                    pass
                    t_15.extend((
                        '\n        std::move(param_',
                        to_string(environment.getattr(l_2_param, 'name')),
                        '_)',
                    ))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    t_15.append(
                        ', ',
                    )
            l_2_loop = l_2_param = missing
            t_15.append(
                ');\n  }\n\n',
            )
            if environment.getattr(l_1_method, 'sync'):
                pass
                t_15.append(
                    '\n  void HandleSyncResponse(\n      mojo::Message* message\n',
                )
                for l_2_param in l_1_parameters:
                    pass
                    t_15.extend((
                        ',\n      ',
                        to_string(t_1(environment.getattr(l_2_param, 'kind'))),
                        '* out_',
                        to_string(environment.getattr(l_2_param, 'name')),
                    ))
                l_2_param = missing
                t_15.append(
                    ') {\n\n    if (message->receiver_connection_group()) {',
                )
                for l_2_param in l_1_parameters:
                    pass
                    if t_7(environment.getattr(l_2_param, 'kind')):
                        pass
                        t_15.extend((
                            '\n      param_',
                            to_string(environment.getattr(l_2_param, 'name')),
                            '_.set_connection_group(\n          *message->receiver_connection_group());',
                        ))
                l_2_param = missing
                t_15.append(
                    '\n    }\n\n',
                )
                for l_2_param in l_1_parameters:
                    pass
                    if t_6(environment.getattr(l_2_param, 'kind')):
                        pass
                        t_15.extend((
                            '\n    out_',
                            to_string(environment.getattr(l_2_param, 'name')),
                            '->Bind(std::move(param_',
                            to_string(environment.getattr(l_2_param, 'name')),
                            '_));',
                        ))
                    else:
                        pass
                        t_15.extend((
                            '\n    *out_',
                            to_string(environment.getattr(l_2_param, 'name')),
                            ' = std::move(param_',
                            to_string(environment.getattr(l_2_param, 'name')),
                            '_);',
                        ))
                    t_15.append(
                        '\n',
                    )
                l_2_param = missing
                t_15.append(
                    '\n  }',
                )
        t_15.extend((
            '\n\n private:\n  // mojo::internal::UnserializedMessageContext:\n  void Serialize(mojo::Message& message) override {\n    mojo::internal::MessageFragment<\n        ',
            to_string(t_5(l_1_params_struct, internal=True)),
            '> params(\n            message);\n    ',
            to_string(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'serialize'), l_1_params_struct, l_1_params_description, 'param_%s_', 'params')),
            '\n  }',
        ))
        for l_2_param in l_1_parameters:
            pass
            t_15.extend((
                '\n  ',
                to_string(t_3(environment.getattr(l_2_param, 'kind'))),
                ' param_',
                to_string(environment.getattr(l_2_param, 'name')),
                '_;',
            ))
        l_2_param = missing
        t_15.extend((
            '\n};\n\nconst mojo::internal::UnserializedMessageContext::Tag\n',
            to_string(l_1_message_typename),
            '::kMessageTag = {};',
        ))
        return concat(t_15)
    context.exported_vars.add('define_message_type')
    context.vars['define_message_type'] = l_0_define_message_type = Macro(environment, macro, 'define_message_type', ('interface', 'message_typename', 'message_name', 'is_response', 'method', 'parameters', 'params_struct', 'params_description'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=19&3=21&4=29&5=32&6=37&10=46&12=57&13=60&14=62&19=74&20=82&21=84&22=86&23=92&27=98&41=113&42=117&43=119&46=124&48=128&49=132&53=143&57=151&58=159&59=161&60=163&61=169&62=172&63=177&68=186&70=199&72=203&73=205&76=212&77=214&78=216&82=222&85=239&86=243&87=245&90=254&91=256&94=263&95=265&96=267&100=272&103=293&108=295&110=298&111=302&116=309&118=312&119=314&120=318&122=327&126=335&127=339&129=343&133=346&138=354&140=358&143=362&147=364&149=367&150=371&153=378&161=390&166=393&169=397&170=400&171=404&174=412&175=414&176=418&182=424&183=428&184=430&185=434&187=443&189=446&191=452&192=454&197=469&199=474&200=476&201=480&208=488&209=490&210=494&212=503&214=506&218=515&221=520&222=524&226=532&227=534&228=538&234=545&235=547&236=551&238=560&249=574&251=576&255=579&256=583&261=591'