from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'module-shared-internal.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_contains_only_enums = resolve('contains_only_enums')
    l_0_imports = resolve('imports')
    l_0_disallow_native_types = resolve('disallow_native_types')
    l_0_export_header = resolve('export_header')
    l_0_enable_kythe_annotations = resolve('enable_kythe_annotations')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_all_enums = resolve('all_enums')
    l_0_header_guard = l_0_enum_data_decl = missing
    t_1 = environment.filters['format']
    t_2 = environment.filters['get_name_for_kind']
    t_3 = environment.filters['is_native_only_kind']
    t_4 = environment.filters['replace']
    t_5 = environment.filters['reverse']
    t_6 = environment.filters['upper']
    pass
    yield '// Copyright 2016 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    l_0_header_guard = t_1('%s_SHARED_INTERNAL_H_', t_4(context.eval_ctx, t_4(context.eval_ctx, t_4(context.eval_ctx, t_6(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path')), '/', '_'), '.', '_'), '-', '_'))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    yield '\n\n#ifndef '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    if (not (undefined(name='contains_only_enums') if l_0_contains_only_enums is missing else l_0_contains_only_enums)):
        pass
        yield '\n#include "mojo/public/cpp/bindings/lib/array_internal.h"\n#include "mojo/public/cpp/bindings/lib/bindings_internal.h"\n#include "mojo/public/cpp/bindings/lib/map_data_internal.h"\n#include "mojo/public/cpp/bindings/lib/buffer.h"'
    for l_1_import in (undefined(name='imports') if l_0_imports is missing else l_0_imports):
        pass
        yield '\n#include "'
        yield to_string(environment.getattr(l_1_import, 'path'))
        yield '-shared-internal.h"'
    l_1_import = missing
    if (not (undefined(name='disallow_native_types') if l_0_disallow_native_types is missing else l_0_disallow_native_types)):
        pass
        yield '\n#include "mojo/public/cpp/bindings/lib/native_enum_data.h"\n#include "mojo/public/interfaces/bindings/native_struct.mojom-shared-internal.h"'
    if (undefined(name='export_header') if l_0_export_header is missing else l_0_export_header):
        pass
        yield '\n#include "'
        yield to_string((undefined(name='export_header') if l_0_export_header is missing else l_0_export_header))
        yield '"'
    yield '\n\n'
    if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
        pass
        yield '#ifdef KYTHE_IS_RUNNING\n#pragma kythe_inline_metadata "Metadata comment"\n#endif'
    yield '\n\nnamespace mojo {\nnamespace internal {\nclass ValidationContext;\n}\n}'
    for l_1_namespace in (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array):
        pass
        yield '\nnamespace '
        yield to_string(l_1_namespace)
        yield ' {'
    l_1_namespace = missing
    yield '\nnamespace internal {'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        if t_3(l_1_struct):
            pass
            yield '\nusing '
            yield to_string(environment.getattr(l_1_struct, 'name'))
            yield '_Data = mojo::native::internal::NativeStruct_Data;'
        else:
            pass
            yield '\nclass '
            yield to_string(environment.getattr(l_1_struct, 'name'))
            yield '_Data;'
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        yield '\nclass '
        yield to_string(environment.getattr(l_1_union, 'name'))
        yield '_Data;'
    l_1_union = missing
    included_template = environment.get_template('enum_macros.tmpl', 'module-shared-internal.h.tmpl')._get_default_module()
    l_0_enum_data_decl = getattr(included_template, 'enum_data_decl', missing)
    if l_0_enum_data_decl is missing:
        l_0_enum_data_decl = undefined("the template %r (imported on line 63 in 'module-shared-internal.h.tmpl') does not export the requested name 'enum_data_decl'" % included_template.__name__, name='enum_data_decl')
    context.vars['enum_data_decl'] = l_0_enum_data_decl
    context.exported_vars.discard('enum_data_decl')
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        pass
        if t_3(l_1_enum):
            pass
            yield '\nusing '
            yield to_string(t_2(l_1_enum, flatten_nested_kind=True))
            yield '_Data =\n    mojo::internal::NativeEnum_Data;'
        else:
            pass
            yield '\n'
            yield to_string(context.call((undefined(name='enum_data_decl') if l_0_enum_data_decl is missing else l_0_enum_data_decl), l_1_enum))
    l_1_enum = missing
    yield '\n\n#pragma pack(push, 1)'
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        yield '\n'
        template = environment.get_template('union_declaration.tmpl', 'module-shared-internal.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_data_decl': l_0_enum_data_decl, 'header_guard': l_0_header_guard, 'union': l_1_union})):
            yield event
    l_1_union = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        if (not t_3(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('struct_declaration.tmpl', 'module-shared-internal.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_data_decl': l_0_enum_data_decl, 'header_guard': l_0_header_guard, 'struct': l_1_struct})):
                yield event
            yield '\n'
            template = environment.get_template('struct_unserialized_message_context.tmpl', 'module-shared-internal.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_data_decl': l_0_enum_data_decl, 'header_guard': l_0_header_guard, 'struct': l_1_struct})):
                yield event
    l_1_struct = missing
    yield '\n\n#pragma pack(pop)\n\n}  // namespace internal'
    for l_1_namespace in t_5((undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)):
        pass
        yield '\n}  // namespace '
        yield to_string(l_1_namespace)
    l_1_namespace = missing
    yield '\n\n#endif  // '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=29&9=33&10=35&12=36&19=39&20=42&23=45&28=48&29=51&32=54&44=58&45=61&50=65&51=67&52=70&54=75&58=78&59=81&63=84&64=90&65=92&66=95&69=100&77=103&78=106&82=110&83=112&84=115&85=119&92=124&93=127&96=130'