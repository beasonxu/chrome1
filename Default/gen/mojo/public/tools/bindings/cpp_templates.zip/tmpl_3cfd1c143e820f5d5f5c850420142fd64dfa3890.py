from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'wrapper_class_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module_prefix = resolve('module_prefix')
    l_0_struct = resolve('struct')
    l_0_kythe_annotation = resolve('kythe_annotation')
    l_0_export_attribute = resolve('export_attribute')
    l_0_for_blink = resolve('for_blink')
    l_0_struct_prefix = l_0_serialization_result_type = missing
    t_1 = environment.filters['contains_handles_or_interfaces']
    t_2 = environment.filters['contains_move_only_members']
    t_3 = environment.filters['cpp_wrapper_param_type_new']
    t_4 = environment.filters['cpp_wrapper_type']
    t_5 = environment.filters['format']
    t_6 = environment.filters['format_constant_declaration']
    t_7 = environment.filters['get_full_mojom_name_for_kind']
    t_8 = environment.filters['get_name_for_kind']
    t_9 = environment.filters['is_hashable']
    t_10 = environment.filters['length']
    t_11 = environment.filters['struct_constructors']
    pass
    l_0_struct_prefix = t_5('%s.%s', (undefined(name='module_prefix') if l_0_module_prefix is missing else l_0_module_prefix), environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    context.vars['struct_prefix'] = l_0_struct_prefix
    context.exported_vars.add('struct_prefix')
    yield '\n\n'
    yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), (undefined(name='struct_prefix') if l_0_struct_prefix is missing else l_0_struct_prefix)))
    yield '\nclass '
    yield to_string((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield ' {\n public:\n  template <typename T>\n  using EnableIfSame = std::enable_if_t<std::is_same<'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield ', T>::value>;\n  using DataView = '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'DataView;\n  using Data_ = internal::'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '_Data;'
    for l_1_enum in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'enums'):
        pass
        yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_7(l_1_enum)))
        yield '\n  using '
        yield to_string(environment.getattr(l_1_enum, 'name'))
        yield ' = '
        yield to_string(t_8(l_1_enum, flatten_nested_kind=True))
        yield ';'
    l_1_enum = missing
    for l_1_constant in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'constants'):
        pass
        yield '\n  '
        yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_5('%s.%s', (undefined(name='struct_prefix') if l_0_struct_prefix is missing else l_0_struct_prefix), environment.getattr(l_1_constant, 'name'))))
        yield '\n  static '
        yield to_string(t_6(l_1_constant, nested=True))
        yield ';'
    l_1_constant = missing
    yield '\n\n  template <typename... Args>\n  static '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'Ptr New(Args&&... args) {\n    return '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'Ptr(\n        absl::in_place, std::forward<Args>(args)...);\n  }\n\n  template <typename U>\n  static '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'Ptr From(const U& u) {\n    return mojo::TypeConverter<'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'Ptr, U>::Convert(u);\n  }\n\n  template <typename U>\n  U To() const {\n    return mojo::TypeConverter<U, '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '>::Convert(*this);\n  }\n\n'
    l_1_loop = missing
    for l_1_constructor, l_1_loop in LoopContext(t_11((undefined(name='struct') if l_0_struct is missing else l_0_struct)), undefined):
        pass
        yield '\n  '
        if (t_10(environment.getattr(l_1_constructor, 'params')) == 1):
            pass
            yield 'explicit '
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '('
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_constructor, 'params'), undefined):
            l_2_type = l_2_name = missing
            pass
            l_2_type = t_3(environment.getattr(l_2_field, 'kind'))
            l_2_name = environment.getattr(l_2_field, 'name')
            yield '\n      '
            yield to_string((undefined(name='type') if l_2_type is missing else l_2_type))
            yield ' '
            yield to_string((undefined(name='name') if l_2_name is missing else l_2_name))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_field = l_2_type = l_2_name = missing
        yield ');\n'
    l_1_loop = l_1_constructor = missing
    if t_2((undefined(name='struct') if l_0_struct is missing else l_0_struct)):
        pass
        yield '\n'
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '(const '
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '&) = delete;\n'
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '& operator=(const '
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '&) = delete;'
    yield '\n\n  ~'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '();\n\n  // Clone() is a template so it is only instantiated if it is used. Thus, the\n  // bindings generator does not need to know whether Clone() or copy\n  // constructor/assignment are available for members.\n  template <typename StructPtrType = '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'Ptr>\n  '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'Ptr Clone() const;\n\n  // Equals() is a template so it is only instantiated if it is used. Thus, the\n  // bindings generator does not need to know whether Equals() or == operator\n  // are available for members.\n  template <typename T, '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::EnableIfSame<T>* = nullptr>\n  bool Equals(const T& other) const;\n\n  template <typename T, '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::EnableIfSame<T>* = nullptr>\n  bool operator==(const T& rhs) const { return Equals(rhs); }'
    if t_9((undefined(name='struct') if l_0_struct is missing else l_0_struct)):
        pass
        yield '\n  size_t Hash(size_t seed) const;'
    l_0_serialization_result_type = ('WTF::Vector<uint8_t>' if (undefined(name='for_blink') if l_0_for_blink is missing else l_0_for_blink) else 'std::vector<uint8_t>')
    context.vars['serialization_result_type'] = l_0_serialization_result_type
    context.exported_vars.add('serialization_result_type')
    if (not t_1((undefined(name='struct') if l_0_struct is missing else l_0_struct))):
        pass
        yield '\n  template <typename UserType>\n  static '
        yield to_string((undefined(name='serialization_result_type') if l_0_serialization_result_type is missing else l_0_serialization_result_type))
        yield ' Serialize(UserType* input) {\n    return mojo::internal::SerializeImpl<\n        '
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '::DataView, '
        yield to_string((undefined(name='serialization_result_type') if l_0_serialization_result_type is missing else l_0_serialization_result_type))
        yield '>(input);\n  }'
    yield '\n\n  template <typename UserType>\n  static mojo::Message SerializeAsMessage(UserType* input) {\n    return mojo::internal::SerializeAsMessageImpl<\n        '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::DataView>(input);\n  }\n\n  // The returned Message is serialized only if the message is moved\n  // cross-process or cross-language. Otherwise if the message is Deserialized\n  // as the same UserType |input| will just be moved to |output| in\n  // DeserializeFromMessage.\n  template <typename UserType>\n  static mojo::Message WrapAsMessage(UserType input) {\n    return mojo::Message(std::make_unique<\n        internal::'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '_UnserializedMessageContext<\n            UserType, '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::DataView>>(0, 0, std::move(input)),\n        MOJO_CREATE_MESSAGE_FLAG_NONE);\n  }\n\n  template <typename UserType>\n  static bool Deserialize(const void* data,\n                          size_t data_num_bytes,\n                          UserType* output) {\n    mojo::Message message;\n    return mojo::internal::DeserializeImpl<'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::DataView>(\n        message, data, data_num_bytes, output, Validate);\n  }\n\n  template <typename UserType>\n  static bool Deserialize(const '
    yield to_string((undefined(name='serialization_result_type') if l_0_serialization_result_type is missing else l_0_serialization_result_type))
    yield '& input,\n                          UserType* output) {\n    return '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::Deserialize(\n        input.size() == 0 ? nullptr : &input.front(), input.size(), output);\n  }\n\n  template <typename UserType>\n  static bool DeserializeFromMessage(mojo::Message input,\n                                     UserType* output) {\n    auto context = input.TakeUnserializedContext<\n        internal::'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '_UnserializedMessageContext<\n            UserType, '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::DataView>>();\n    if (context) {\n      *output = std::move(context->TakeData());\n      return true;\n    }\n    input.SerializeIfNecessary();\n    return mojo::internal::DeserializeImpl<'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::DataView>(\n        input, input.payload(), input.payload_num_bytes(), output, Validate);\n  }\n'
    for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
        l_1_type = l_1_name = missing
        pass
        l_1_type = t_4(environment.getattr(l_1_field, 'kind'))
        l_1_name = environment.getattr(l_1_field, 'name')
        yield '\n  '
        yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_5('%s.%s', (undefined(name='struct_prefix') if l_0_struct_prefix is missing else l_0_struct_prefix), (undefined(name='name') if l_1_name is missing else l_1_name))))
        yield '\n  '
        yield to_string((undefined(name='type') if l_1_type is missing else l_1_type))
        yield ' '
        yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
        yield ';'
    l_1_field = l_1_type = l_1_name = missing
    yield '\n\n  // Serialise this struct into a trace.\n  void WriteIntoTrace(perfetto::TracedValue traced_context) const;\n\n private:\n  static bool Validate(const void* data,\n                       mojo::internal::ValidationContext* validation_context);\n};\n\n// The comparison operators are templates, so they are only instantiated if they\n// are used. Thus, the bindings generator does not need to know whether\n// comparison operators are available for members.\ntemplate <typename T, '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::EnableIfSame<T>* = nullptr>\nbool operator<(const T& lhs, const T& rhs);\n\ntemplate <typename T, '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::EnableIfSame<T>* = nullptr>\nbool operator<=(const T& lhs, const T& rhs) {\n  return !(rhs < lhs);\n}\n\ntemplate <typename T, '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::EnableIfSame<T>* = nullptr>\nbool operator>(const T& lhs, const T& rhs) {\n  return rhs < lhs;\n}\n\ntemplate <typename T, '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::EnableIfSame<T>* = nullptr>\nbool operator>=(const T& lhs, const T& rhs) {\n  return !(lhs < rhs);\n}'

blocks = {}
debug_info = '1=28&3=32&4=34&7=38&8=40&9=42&12=44&13=46&14=48&18=53&19=56&20=58&24=62&25=64&30=66&31=68&36=70&39=73&40=76&41=82&42=85&43=86&44=88&45=91&49=97&50=100&51=104&54=109&59=111&60=113&65=115&68=117&71=119&75=122&78=125&80=128&82=130&89=135&99=137&100=139&109=141&114=143&116=145&124=147&125=149&131=151&136=153&137=156&138=157&139=159&140=161&154=167&157=169&162=171&167=173'