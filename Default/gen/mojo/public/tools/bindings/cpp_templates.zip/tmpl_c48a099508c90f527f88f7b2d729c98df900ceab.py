from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'union_data_view_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_struct_macros = missing
    t_1 = environment.filters['cpp_data_view_type']
    t_2 = environment.filters['is_any_handle_kind']
    t_3 = environment.filters['is_any_interface_kind']
    t_4 = environment.filters['is_enum_kind']
    t_5 = environment.filters['is_object_kind']
    t_6 = environment.filters['is_typemapped_kind']
    t_7 = environment.filters['requires_context_for_data_view']
    t_8 = environment.filters['under_to_camel']
    t_9 = environment.filters['unmapped_type_for_serializer']
    pass
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'union_data_view_declaration.tmpl')._get_default_module()
    context.exported_vars.discard('struct_macros')
    yield '\n\nclass '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'DataView {\n public:\n  using Tag = internal::'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '_Data::'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '_Tag;\n\n  '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'DataView() = default;\n\n  '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'DataView(\n      internal::'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '_Data* data,\n      mojo::Message* message)'
    if t_7((undefined(name='union') if l_0_union is missing else l_0_union)):
        pass
        yield '\n      : data_(data), message_(message) {}'
    else:
        pass
        yield '\n      : data_(data) {}'
    yield '\n\n  bool is_null() const {\n    // For inlined unions, |data_| is always non-null. In that case we need to\n    // check |data_->is_null()|.\n    return !data_ || data_->is_null();\n  }\n\n  Tag tag() const { return data_->tag; }'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        l_1_kind = l_1_name = missing
        pass
        l_1_kind = environment.getattr(l_1_field, 'kind')
        l_1_name = environment.getattr(l_1_field, 'name')
        yield '\n  bool is_'
        yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
        yield '() const { return data_->tag == Tag::k'
        yield to_string(t_8((undefined(name='name') if l_1_name is missing else l_1_name)))
        yield '; }'
        if t_5((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n  inline void Get'
            yield to_string(t_8((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield 'DataView(\n      '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '* output) const;\n\n  template <typename UserType>\n  [[nodiscard]] bool Read'
            yield to_string(t_8((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '(UserType* output) const {\n    '
            yield to_string(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'assert_nullable_output_type_if_necessary'), (undefined(name='kind') if l_1_kind is missing else l_1_kind), (undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '\n    CHECK(is_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '());\n    return mojo::internal::Deserialize<'
            yield to_string(t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '>(\n        data_->data.f_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '.Get(), output, message_);\n  }'
        elif t_4((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n  template <typename UserType>\n  [[nodiscard]] bool Read'
            yield to_string(t_8((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '(UserType* output) const {\n    CHECK(is_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '());\n    return mojo::internal::Deserialize<'
            yield to_string(t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '>(\n        data_->data.f_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ', output);\n  }'
            if (not t_6((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
                pass
                yield '\n  '
                yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield ' '
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '() const {\n    CHECK(is_'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '());\n    // TODO(dcheng): This seems incorrect, as it bypasses enum traits.\n    return ::mojo::internal::ToKnownEnumValueHelper(\n        static_cast<'
                yield to_string(t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield '>(data_->data.f_'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '));\n  }'
        elif t_2((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n  '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield ' Take'
            yield to_string(t_8((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '() {\n    CHECK(is_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '());\n    '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield ' result;\n    bool ret =\n        mojo::internal::Deserialize<'
            yield to_string(t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '>(\n            &data_->data.f_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ', &result, message_);\n    CHECK(ret);\n    return result;\n  }'
        elif t_3((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n  template <typename UserType>\n  UserType Take'
            yield to_string(t_8((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '() {\n    CHECK(is_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '());\n    UserType result;\n    bool ret =\n        mojo::internal::Deserialize<'
            yield to_string(t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '>(\n            &data_->data.f_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ', &result, message_);\n    CHECK(ret);\n    return result;\n  }'
        else:
            pass
            yield '\n  '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield ' '
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '() const {\n    CHECK(is_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '());\n    return data_->data.f_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ';\n  }'
    l_1_field = l_1_kind = l_1_name = missing
    yield '\n\n private:\n  internal::'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '_Data* data_ = nullptr;'
    if t_7((undefined(name='union') if l_0_union is missing else l_0_union)):
        pass
        yield '\n  mojo::Message* message_ = nullptr;'
    yield '\n};\n'

blocks = {}
debug_info = '1=22&3=25&5=27&7=31&9=33&10=35&12=37&26=44&27=47&28=48&29=50&31=54&32=57&33=59&36=61&37=63&38=65&39=67&40=69&43=71&45=74&46=76&47=78&48=80&51=82&52=85&53=89&56=91&60=95&61=98&62=102&63=104&65=106&66=108&71=110&73=113&74=115&77=117&78=119&84=124&85=128&86=130&93=134&94=136'