from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'wrapper_class_template_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    pass
    yield 'template <typename StructPtrType>\n'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'Ptr '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::Clone() const {\n  return New('
    l_1_loop = missing
    for l_1_field, l_1_loop in LoopContext(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'), undefined):
        pass
        yield '\n      mojo::Clone('
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield ')'
        if (not environment.getattr(l_1_loop, 'last')):
            pass
            yield ','
    l_1_loop = l_1_field = missing
    yield '\n  );\n}\n\ntemplate <typename T, '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::EnableIfSame<T>*>\nbool '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::Equals(const T& other_struct) const {'
    for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
        pass
        yield '\n  if (!mojo::Equals(this->'
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield ', other_struct.'
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield '))\n    return false;'
    l_1_field = missing
    yield '\n  return true;\n}\n\ntemplate <typename T, '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::EnableIfSame<T>*>\nbool operator<(const T& lhs, const T& rhs) {'
    for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
        pass
        yield '\n  if (lhs.'
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield ' < rhs.'
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield ')\n    return true;\n  if (rhs.'
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield ' < lhs.'
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield ')\n    return false;'
    l_1_field = missing
    yield '\n  return false;\n}'

blocks = {}
debug_info = '2=13&4=18&5=21&6=23&11=28&12=30&13=32&14=35&20=41&22=43&23=46&25=50'