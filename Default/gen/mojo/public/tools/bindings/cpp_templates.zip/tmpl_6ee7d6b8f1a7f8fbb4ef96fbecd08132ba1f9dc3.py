from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'union_data_view_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    t_1 = environment.filters['cpp_data_view_type']
    t_2 = environment.filters['is_object_kind']
    t_3 = environment.filters['under_to_camel']
    pass
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        l_1_kind = l_1_name = missing
        pass
        l_1_kind = environment.getattr(l_1_field, 'kind')
        l_1_name = environment.getattr(l_1_field, 'name')
        if t_2((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\ninline void '
            yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
            yield 'DataView::Get'
            yield to_string(t_3((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield 'DataView(\n    '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '* output) const {\n  CHECK(is_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '());\n  *output = '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '(data_->data.f_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '.Get(), message_);\n}'
    l_1_field = l_1_kind = l_1_name = missing

blocks = {}
debug_info = '1=15&2=18&3=19&5=20&6=23&7=27&8=29&9=31'