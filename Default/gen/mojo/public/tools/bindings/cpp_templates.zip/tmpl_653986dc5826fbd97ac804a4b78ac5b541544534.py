from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'wrapper_union_class_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module_prefix = resolve('module_prefix')
    l_0_union = resolve('union')
    l_0_kythe_annotation = resolve('kythe_annotation')
    l_0_export_attribute = resolve('export_attribute')
    l_0_union_prefix = missing
    t_1 = environment.filters['cpp_union_getter_return_type']
    t_2 = environment.filters['cpp_wrapper_param_type_new']
    t_3 = environment.filters['cpp_wrapper_type']
    t_4 = environment.filters['format']
    t_5 = environment.filters['is_any_handle_or_interface_kind']
    t_6 = environment.filters['is_hashable']
    t_7 = environment.filters['is_object_kind']
    t_8 = environment.filters['under_to_camel']
    pass
    l_0_union_prefix = t_4('%s.%s', (undefined(name='module_prefix') if l_0_module_prefix is missing else l_0_module_prefix), environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    context.vars['union_prefix'] = l_0_union_prefix
    context.exported_vars.add('union_prefix')
    yield '\n\n'
    yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), (undefined(name='union_prefix') if l_0_union_prefix is missing else l_0_union_prefix)))
    yield '\nclass '
    yield to_string((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield ' {\n public:\n  using DataView = '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'DataView;\n  using Data_ = internal::'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '_Data;\n  using Tag = Data_::'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '_Tag;\n\n  template <typename... Args>\n  static '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'Ptr New(Args&&... args) {\n    static_assert(\n        sizeof...(args) < 0,\n        "Do not use Union::New(); to create a union of a given subtype, use "\n        "New<SubType>(), not New() followed by set_<sub_type>(). To represent "\n        "an empty union, mark the field or parameter as nullable in the mojom "\n        "definition.");\n  }'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        pass
        yield '\n  // Construct an instance holding |'
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield '|.\n  static '
        yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield 'Ptr\n  New'
        yield to_string(t_8(environment.getattr(l_1_field, 'name')))
        yield '(\n      '
        yield to_string(t_2(environment.getattr(l_1_field, 'kind')))
        yield ' '
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield ') {\n    auto result = '
        yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield 'Ptr(absl::in_place);\n    result->set_'
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield '(std::move('
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield '));\n    return result;\n  }'
    l_1_field = missing
    yield '\n\n  template <typename U>\n  static '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'Ptr From(const U& u) {\n    return mojo::TypeConverter<'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'Ptr, U>::Convert(u);\n  }\n\n  template <typename U>\n  U To() const {\n    return mojo::TypeConverter<U, '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '>::Convert(*this);\n  }\n\n  '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '();\n  ~'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '();\n\n  // Clone() is a template so it is only instantiated if it is used. Thus, the\n  // bindings generator does not need to know whether Clone() or copy\n  // constructor/assignment are available for members.\n  template <typename UnionPtrType = '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'Ptr>\n  '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'Ptr Clone() const;\n\n  // Equals() is a template so it is only instantiated if it is used. Thus, the\n  // bindings generator does not need to know whether Equals() or == operator\n  // are available for members.\n  template <typename T,\n            typename std::enable_if<std::is_same<\n                T, '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '>::value>::type* = nullptr>\n  bool Equals(const T& other) const;\n\n  template <typename T,\n            typename std::enable_if<std::is_same<\n                T, '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '>::value>::type* = nullptr>\n  bool operator==(const T& rhs) const { return Equals(rhs); }'
    if t_6((undefined(name='union') if l_0_union is missing else l_0_union)):
        pass
        yield '\n  size_t Hash(size_t seed) const;'
    yield '\n\n  Tag which() const {\n    return tag_;\n  }\n\n'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        pass
        yield '\n  '
        yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_4('%s.%s', (undefined(name='union_prefix') if l_0_union_prefix is missing else l_0_union_prefix), environment.getattr(l_1_field, 'name'))))
        yield '\n  bool is_'
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield '() const { return tag_ == Tag::k'
        yield to_string(t_8(environment.getattr(l_1_field, 'name')))
        yield '; }\n\n  '
        yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_4('%s.%s', (undefined(name='union_prefix') if l_0_union_prefix is missing else l_0_union_prefix), environment.getattr(l_1_field, 'name'))))
        yield '\n  '
        yield to_string(t_1(environment.getattr(l_1_field, 'kind')))
        yield ' get_'
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield '() const {\n    CHECK(tag_ == Tag::k'
        yield to_string(t_8(environment.getattr(l_1_field, 'name')))
        yield ');'
        if (t_7(environment.getattr(l_1_field, 'kind')) or t_5(environment.getattr(l_1_field, 'kind'))):
            pass
            yield '\n    return *(data_.'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ');'
        else:
            pass
            yield '\n    return data_.'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ';'
        yield '\n  }\n\n  '
        yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_4('%s.%s', (undefined(name='union_prefix') if l_0_union_prefix is missing else l_0_union_prefix), environment.getattr(l_1_field, 'name'))))
        yield '\n  void set_'
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield '(\n      '
        yield to_string(t_2(environment.getattr(l_1_field, 'kind')))
        yield ' '
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield ');'
    l_1_field = missing
    yield '\n\n  template <typename UserType>\n  static mojo::Message SerializeAsMessage(UserType* input) {\n    return mojo::internal::SerializeAsMessageImpl<\n        '
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::DataView>(input);\n  }\n\n  template <typename UserType>\n  static bool DeserializeFromMessage(mojo::Message input,\n                                     UserType* output) {\n    return mojo::internal::DeserializeImpl<'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::DataView>(\n        input, input.payload(), input.payload_num_bytes(), output, Validate);\n  }\n\n private:\n  union Union_ {\n    Union_() = default;\n    ~Union_() = default;'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        pass
        if (t_7(environment.getattr(l_1_field, 'kind')) or t_5(environment.getattr(l_1_field, 'kind'))):
            pass
            yield '\n    '
            yield to_string(t_3(environment.getattr(l_1_field, 'kind')))
            yield '* '
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ';'
        else:
            pass
            yield '\n    '
            yield to_string(t_3(environment.getattr(l_1_field, 'kind')))
            yield ' '
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ';'
    l_1_field = missing
    yield '\n  };\n\n  static bool Validate(const void* data,\n                       mojo::internal::ValidationContext* validation_context);\n\n  void DestroyActive();\n  Tag tag_;\n  Union_ data_;\n};'

blocks = {}
debug_info = '1=24&3=28&4=30&6=34&7=36&8=38&11=40&20=42&21=45&22=47&23=49&24=51&25=55&26=57&32=63&33=65&38=67&41=69&42=71&47=73&48=75&55=77&60=79&63=81&71=85&72=88&73=90&75=94&76=96&77=100&78=102&80=105&82=110&86=113&87=115&88=117&94=123&100=125&109=127&110=129&112=132&114=139'