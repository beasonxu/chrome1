from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'struct_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_export_attribute = resolve('export_attribute')
    l_0_last_field = resolve('last_field')
    l_0_offset = resolve('offset')
    l_0_pad = resolve('pad')
    l_0_class_name = l_0_num_fields = missing
    t_1 = environment.filters['cpp_field_type']
    t_2 = environment.filters['get_pad']
    pass
    l_0_class_name = unicode_join((environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'), '_Data', ))
    context.vars['class_name'] = l_0_class_name
    context.exported_vars.add('class_name')
    yield 'class '
    yield to_string((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' '
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield ' {\n public:\n  static bool Validate(const void* data,\n                       mojo::internal::ValidationContext* validation_context);\n\n  mojo::internal::StructHeader header_;'
    l_1_loop = missing
    for l_1_packed_field, l_1_loop in LoopContext(environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields'), undefined):
        l_1_next_pf = resolve('next_pf')
        l_1_pad = l_0_pad
        l_1_name = l_1_kind = missing
        pass
        l_1_name = environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name')
        l_1_kind = environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')
        if (environment.getattr((undefined(name='kind') if l_1_kind is missing else l_1_kind), 'spec') == 'b'):
            pass
            yield '\n  uint8_t '
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ' : 1;'
        else:
            pass
            yield '\n  '
            yield to_string(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield ' '
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ';'
        if (not environment.getattr(l_1_loop, 'last')):
            pass
            l_1_next_pf = environment.getitem(environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields'), (environment.getattr(l_1_loop, 'index0') + 1))
            l_1_pad = (environment.getattr((undefined(name='next_pf') if l_1_next_pf is missing else l_1_next_pf), 'offset') - (environment.getattr(l_1_packed_field, 'offset') + environment.getattr(l_1_packed_field, 'size')))
            if ((undefined(name='pad') if l_1_pad is missing else l_1_pad) > 0):
                pass
                yield '\n  uint8_t pad'
                yield to_string(environment.getattr(l_1_loop, 'index0'))
                yield '_['
                yield to_string((undefined(name='pad') if l_1_pad is missing else l_1_pad))
                yield '];'
    l_1_loop = l_1_packed_field = l_1_name = l_1_kind = l_1_next_pf = l_1_pad = missing
    l_0_num_fields = environment.getattr(environment.getitem(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'), -1), 'num_fields')
    context.vars['num_fields'] = l_0_num_fields
    context.exported_vars.add('num_fields')
    if ((undefined(name='num_fields') if l_0_num_fields is missing else l_0_num_fields) > 0):
        pass
        l_0_last_field = environment.getitem(environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields'), ((undefined(name='num_fields') if l_0_num_fields is missing else l_0_num_fields) - 1))
        context.vars['last_field'] = l_0_last_field
        context.exported_vars.add('last_field')
        l_0_offset = (environment.getattr((undefined(name='last_field') if l_0_last_field is missing else l_0_last_field), 'offset') + environment.getattr((undefined(name='last_field') if l_0_last_field is missing else l_0_last_field), 'size'))
        context.vars['offset'] = l_0_offset
        context.exported_vars.add('offset')
        l_0_pad = t_2((undefined(name='offset') if l_0_offset is missing else l_0_offset), 8)
        context.vars['pad'] = l_0_pad
        context.exported_vars.add('pad')
        if ((undefined(name='pad') if l_0_pad is missing else l_0_pad) > 0):
            pass
            yield '\n  uint8_t padfinal_['
            yield to_string((undefined(name='pad') if l_0_pad is missing else l_0_pad))
            yield '];'
    yield '\n\n private:\n  friend class mojo::internal::MessageFragment<'
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '>;\n\n  '
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '();\n  ~'
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '() = delete;\n};\nstatic_assert(sizeof('
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield ') == '
    yield to_string(environment.getattr(environment.getitem(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'), -1), 'num_bytes'))
    yield ',\n              "Bad sizeof('
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield ')");'

blocks = {}
debug_info = '1=19&3=23&9=28&10=33&11=34&12=35&13=38&15=43&17=47&18=49&19=50&20=51&21=54&26=59&27=62&28=64&29=67&30=70&31=73&32=76&37=79&39=81&40=83&42=85&43=89'