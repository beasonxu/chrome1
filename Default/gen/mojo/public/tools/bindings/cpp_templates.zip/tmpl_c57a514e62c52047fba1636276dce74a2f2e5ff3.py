from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'interface_proxy_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module_prefix = resolve('module_prefix')
    l_0_interface = resolve('interface')
    l_0_kythe_annotation = resolve('kythe_annotation')
    l_0_export_attribute = resolve('export_attribute')
    l_0_interface_macros = l_0_interface_prefix = missing
    t_1 = environment.filters['format']
    pass
    l_0_interface_macros = context.vars['interface_macros'] = environment.get_template('interface_macros.tmpl', 'interface_proxy_declaration.tmpl')._get_default_module()
    context.exported_vars.discard('interface_macros')
    l_0_interface_prefix = t_1('%s.%s', (undefined(name='module_prefix') if l_0_module_prefix is missing else l_0_module_prefix), environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    context.vars['interface_prefix'] = l_0_interface_prefix
    context.exported_vars.add('interface_prefix')
    yield '\n\n'
    yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), (undefined(name='interface_prefix') if l_0_interface_prefix is missing else l_0_interface_prefix)))
    yield '\nclass '
    yield to_string((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Proxy\n    : public '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield ' {\n public:\n  using InterfaceType = '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield ';\n\n  explicit '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Proxy(mojo::MessageReceiverWithResponder* receiver);'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        if environment.getattr(l_1_method, 'sync'):
            pass
            yield '\n  '
            yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_1('%s.%s', (undefined(name='interface_prefix') if l_0_interface_prefix is missing else l_0_interface_prefix), environment.getattr(l_1_method, 'name'))))
            yield '\n  bool '
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '('
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_sync_method_params'), '', l_1_method))
            yield ') final;'
        yield '\n  '
        yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_1('%s.%s', (undefined(name='interface_prefix') if l_0_interface_prefix is missing else l_0_interface_prefix), environment.getattr(l_1_method, 'name'))))
        yield '\n  void '
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield '('
        yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_request_params'), '', l_1_method))
        yield ') final;'
    l_1_method = missing
    yield '\n\n private:\n  mojo::MessageReceiverWithResponder* receiver_;\n};'

blocks = {}
debug_info = '1=17&3=19&5=23&6=25&7=29&9=31&11=33&13=35&14=37&15=40&16=42&18=47&19=49'