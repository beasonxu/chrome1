from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'enum_serialization_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_enum = resolve('enum')
    l_0_mojom_type = missing
    t_1 = environment.filters['get_qualified_name_for_kind']
    pass
    l_0_mojom_type = t_1((undefined(name='enum') if l_0_enum is missing else l_0_enum), flatten_nested_kind=True)
    context.vars['mojom_type'] = l_0_mojom_type
    context.exported_vars.add('mojom_type')
    yield '\n\nnamespace internal {\n\ntemplate <typename MaybeConstUserType>\nstruct Serializer<'
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield ', MaybeConstUserType> {\n  using UserType = typename std::remove_const<MaybeConstUserType>::type;\n  using Traits = EnumTraits<'
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield ', UserType>;\n\n  static void Serialize(UserType input, int32_t* output) {\n    *output = static_cast<int32_t>(Traits::ToMojom(input));\n  }\n\n  static bool Deserialize(int32_t input, UserType* output) {\n    return Traits::FromMojom(::mojo::internal::ToKnownEnumValueHelper(\n        static_cast<'
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '>(input)), output);\n  }\n};\n\n}  // namespace internal'

blocks = {}
debug_info = '1=14&7=18&9=20&17=22'