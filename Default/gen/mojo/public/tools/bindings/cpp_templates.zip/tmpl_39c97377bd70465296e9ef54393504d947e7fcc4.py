from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'module-forward.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_variant = resolve('variant')
    l_0_module = resolve('module')
    l_0_variant_path = resolve('variant_path')
    l_0_all_enums = resolve('all_enums')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_disallow_interfaces = resolve('disallow_interfaces')
    l_0_interfaces = resolve('interfaces')
    l_0_disallow_native_types = resolve('disallow_native_types')
    l_0_export_header = resolve('export_header')
    l_0_enable_kythe_annotations = resolve('enable_kythe_annotations')
    l_0_uses_native_types = resolve('uses_native_types')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_enum_forward = resolve('enum_forward')
    l_0_enum = resolve('enum')
    l_0_enums = resolve('enums')
    l_0_header_guard = l_0_namespace_begin = l_0_namespace_end = l_0_kythe_annotation = l_0_module_prefix = missing
    t_1 = environment.filters['format']
    t_2 = environment.filters['format_constant_declaration']
    t_3 = environment.filters['get_name_for_kind']
    t_4 = environment.filters['is_enum_kind']
    t_5 = environment.filters['is_native_only_kind']
    t_6 = environment.filters['join']
    t_7 = environment.filters['length']
    t_8 = environment.filters['replace']
    t_9 = environment.filters['reverse']
    t_10 = environment.filters['should_inline']
    t_11 = environment.filters['should_inline_union']
    t_12 = environment.filters['upper']
    pass
    yield '// Copyright 2019 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
        pass
        l_0_variant_path = t_1('%s-%s', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant))
        context.vars['variant_path'] = l_0_variant_path
        context.exported_vars.add('variant_path')
    else:
        pass
        l_0_variant_path = environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path')
        context.vars['variant_path'] = l_0_variant_path
        context.exported_vars.add('variant_path')
    l_0_header_guard = t_1('%s_FORWARD_H_', t_8(context.eval_ctx, t_8(context.eval_ctx, t_8(context.eval_ctx, t_12((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path)), '/', '_'), '.', '_'), '-', '_'))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    def macro():
        t_13 = []
        pass
        for l_2_namespace in (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array):
            pass
            t_13.extend((
                '\nnamespace ',
                to_string(l_2_namespace),
                ' {',
            ))
        l_2_namespace = missing
        if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
            pass
            t_13.extend((
                '\nnamespace ',
                to_string((undefined(name='variant') if l_0_variant is missing else l_0_variant)),
                ' {',
            ))
        return concat(t_13)
    context.exported_vars.add('namespace_begin')
    context.vars['namespace_begin'] = l_0_namespace_begin = Macro(environment, macro, 'namespace_begin', (), False, False, False, context.eval_ctx.autoescape)
    def macro():
        t_14 = []
        pass
        if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
            pass
            t_14.extend((
                '\n}  // namespace ',
                to_string((undefined(name='variant') if l_0_variant is missing else l_0_variant)),
            ))
        for l_2_namespace in t_9((undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)):
            pass
            t_14.extend((
                '\n}  // namespace ',
                to_string(l_2_namespace),
            ))
        l_2_namespace = missing
        return concat(t_14)
    context.exported_vars.add('namespace_end')
    context.vars['namespace_end'] = l_0_namespace_end = Macro(environment, macro, 'namespace_end', (), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_name):
        t_15 = []
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
            pass
            t_15.extend((
                '\n// @generated_from: ',
                to_string(l_1_name),
            ))
        return concat(t_15)
    context.exported_vars.add('kythe_annotation')
    context.vars['kythe_annotation'] = l_0_kythe_annotation = Macro(environment, macro, 'kythe_annotation', ('name',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n#ifndef '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n'
    if t_7((undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums)):
        pass
        yield '#include <stdint.h>'
    yield '\n\n'
    if (t_7((undefined(name='structs') if l_0_structs is missing else l_0_structs)) or t_7((undefined(name='unions') if l_0_unions is missing else l_0_unions))):
        pass
        yield '#include "mojo/public/cpp/bindings/struct_forward.h"'
    yield '\n\n'
    if ((not (undefined(name='disallow_interfaces') if l_0_disallow_interfaces is missing else l_0_disallow_interfaces)) and t_7((undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces))):
        pass
        yield '#include "mojo/public/cpp/bindings/deprecated_interface_types_forward.h"'
    yield '\n\n'
    if ((not (undefined(name='disallow_native_types') if l_0_disallow_native_types is missing else l_0_disallow_native_types)) and t_7((undefined(name='structs') if l_0_structs is missing else l_0_structs))):
        pass
        yield '\n#include "mojo/public/interfaces/bindings/native_struct.mojom-forward.h"'
    if ((undefined(name='export_header') if l_0_export_header is missing else l_0_export_header) and t_7(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'))):
        pass
        yield '\n#include "'
        yield to_string((undefined(name='export_header') if l_0_export_header is missing else l_0_export_header))
        yield '"'
    yield '\n\n'
    if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
        pass
        yield '#ifdef KYTHE_IS_RUNNING\n#pragma kythe_inline_metadata "Metadata comment"\n#endif'
    yield '\n\n'
    if (((not (undefined(name='disallow_native_types') if l_0_disallow_native_types is missing else l_0_disallow_native_types)) and (undefined(name='uses_native_types') if l_0_uses_native_types is missing else l_0_uses_native_types)) and t_7((undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums))):
        pass
        yield 'namespace mojo {\nenum class NativeEnum;\n}  // namespace mojo'
    if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
        pass
        for l_1_namespace in (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array):
            pass
            yield '\nnamespace '
            yield to_string(l_1_namespace)
            yield ' {'
        l_1_namespace = missing
        included_template = environment.get_template('enum_macros.tmpl', 'module-forward.h.tmpl')._get_default_module()
        l_0_enum_forward = getattr(included_template, 'enum_forward', missing)
        if l_0_enum_forward is missing:
            l_0_enum_forward = undefined("the template %r (imported on line 79 in 'module-forward.h.tmpl') does not export the requested name 'enum_forward'" % included_template.__name__, name='enum_forward')
        context.vars['enum_forward'] = l_0_enum_forward
        context.exported_vars.discard('enum_forward')
        for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
            pass
            if t_5(l_1_enum):
                pass
                yield '\nusing '
                yield to_string(t_3(l_1_enum, flatten_nested_kind=True))
                yield ' = mojo::NativeEnum;'
            else:
                pass
                yield '\n'
                yield to_string(context.call((undefined(name='enum_forward') if l_0_enum_forward is missing else l_0_enum_forward), l_1_enum))
        l_1_enum = missing
        for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
            pass
            yield '\nclass '
            yield to_string(environment.getattr(l_1_interface, 'name'))
            yield 'InterfaceBase;'
        l_1_interface = missing
        for l_1_namespace in (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array):
            pass
            yield '\n}  // namespace '
            yield to_string(l_1_namespace)
        l_1_namespace = missing
    yield '\n\n'
    yield to_string(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin)))
    l_0_module_prefix = t_1('%s', t_6(context.eval_ctx, (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), '.'))
    context.vars['module_prefix'] = l_0_module_prefix
    context.exported_vars.add('module_prefix')
    if (not (undefined(name='variant') if l_0_variant is missing else l_0_variant)):
        pass
        for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
            pass
            if t_5(l_1_struct):
                pass
                yield '\nusing '
                yield to_string(environment.getattr(l_1_struct, 'name'))
                yield 'DataView = mojo::native::NativeStructDataView;'
            else:
                pass
                yield '\nclass '
                yield to_string(environment.getattr(l_1_struct, 'name'))
                yield 'DataView;'
            yield '\n'
        l_1_struct = missing
        for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
            pass
            yield '\nclass '
            yield to_string(environment.getattr(l_1_union, 'name'))
            yield 'DataView;'
        l_1_union = missing
        included_template = environment.get_template('enum_macros.tmpl', 'module-forward.h.tmpl')._get_default_module()
        l_0_enum_forward = getattr(included_template, 'enum_forward', missing)
        if l_0_enum_forward is missing:
            l_0_enum_forward = undefined("the template %r (imported on line 119 in 'module-forward.h.tmpl') does not export the requested name 'enum_forward'" % included_template.__name__, name='enum_forward')
        context.vars['enum_forward'] = l_0_enum_forward
        context.exported_vars.discard('enum_forward')
        for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
            pass
            if t_5(l_1_enum):
                pass
                yield '\nusing '
                yield to_string(t_3(l_1_enum, flatten_nested_kind=True))
                yield ' = mojo::NativeEnum;'
            else:
                pass
                yield '\n'
                yield to_string(context.call((undefined(name='enum_forward') if l_0_enum_forward is missing else l_0_enum_forward), l_1_enum))
        l_1_enum = missing
    if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
        pass
        if ((undefined(name='enum') if l_0_enum is missing else l_0_enum) or (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces)):
            pass
            yield '\n// Aliases for definition in the parent namespace.'
        for l_1_enum in (undefined(name='enums') if l_0_enums is missing else l_0_enums):
            pass
            yield '\nusing '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield ' = '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield ';'
        l_1_enum = missing
        for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
            pass
            yield '\nusing '
            yield to_string(environment.getattr(l_1_interface, 'name'))
            yield 'InterfaceBase = '
            yield to_string(environment.getattr(l_1_interface, 'name'))
            yield 'InterfaceBase;'
        l_1_interface = missing
    for l_1_constant in environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'):
        pass
        if (not t_4(environment.getattr(l_1_constant, 'kind'))):
            pass
            yield '\n'
            yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_1('%s.%s', (undefined(name='module_prefix') if l_0_module_prefix is missing else l_0_module_prefix), environment.getattr(l_1_constant, 'name'))))
            yield '\n'
            yield to_string(t_2(l_1_constant))
            yield ';'
    l_1_constant = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        if t_5(l_1_struct):
            pass
            yield '\nusing '
            yield to_string(environment.getattr(l_1_struct, 'name'))
            yield ' = mojo::native::NativeStruct;\nusing '
            yield to_string(environment.getattr(l_1_struct, 'name'))
            yield 'Ptr = mojo::native::NativeStructPtr;'
        else:
            pass
            yield '\nclass '
            yield to_string(environment.getattr(l_1_struct, 'name'))
            yield ';'
            if t_10(l_1_struct):
                pass
                yield '\nusing '
                yield to_string(environment.getattr(l_1_struct, 'name'))
                yield 'Ptr = mojo::InlinedStructPtr<'
                yield to_string(environment.getattr(l_1_struct, 'name'))
                yield '>;'
            else:
                pass
                yield '\nusing '
                yield to_string(environment.getattr(l_1_struct, 'name'))
                yield 'Ptr = mojo::StructPtr<'
                yield to_string(environment.getattr(l_1_struct, 'name'))
                yield '>;'
        yield '\n'
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        yield '\nclass '
        yield to_string(environment.getattr(l_1_union, 'name'))
        yield ';\n'
        if t_11(l_1_union):
            pass
            yield '\nusing '
            yield to_string(environment.getattr(l_1_union, 'name'))
            yield 'Ptr = mojo::InlinedStructPtr<'
            yield to_string(environment.getattr(l_1_union, 'name'))
            yield '>;\n'
        else:
            pass
            yield '\nusing '
            yield to_string(environment.getattr(l_1_union, 'name'))
            yield 'Ptr = mojo::StructPtr<'
            yield to_string(environment.getattr(l_1_union, 'name'))
            yield '>;\n'
    l_1_union = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        yield '\nclass '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield ';\n'
    l_1_interface = missing
    yield '\n\n\n'
    yield to_string(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end)))
    yield '\n\n#endif  // '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=41&6=43&8=48&11=51&15=54&16=57&17=61&19=65&20=69&24=75&25=78&26=82&28=84&29=88&33=94&34=99&35=103&39=109&40=111&42=113&46=117&50=121&54=125&58=128&59=131&62=134&68=138&74=141&75=143&76=146&79=149&80=155&81=157&82=160&84=165&88=167&89=170&92=173&93=176&97=179&99=180&102=183&105=185&106=187&107=190&109=195&114=199&115=202&119=205&120=211&121=213&122=216&124=221&131=223&132=225&135=228&136=231&138=236&139=239&144=244&145=246&146=249&147=251&152=254&153=256&154=259&155=261&157=266&158=268&159=271&161=278&167=284&168=287&169=289&170=292&172=299&178=304&179=307&183=311&187=313'