from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'union_serialization_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_data_view = l_0_data_type = missing
    t_1 = environment.filters['get_container_validate_params_ctor_args']
    t_2 = environment.filters['get_qualified_name_for_kind']
    t_3 = environment.filters['indent']
    t_4 = environment.filters['is_any_handle_or_interface_kind']
    t_5 = environment.filters['is_array_kind']
    t_6 = environment.filters['is_associated_kind']
    t_7 = environment.filters['is_enum_kind']
    t_8 = environment.filters['is_map_kind']
    t_9 = environment.filters['is_nullable_kind']
    t_10 = environment.filters['is_object_kind']
    t_11 = environment.filters['is_union_kind']
    t_12 = environment.filters['under_to_camel']
    t_13 = environment.filters['unmapped_type_for_serializer']
    pass
    l_0_data_view = unicode_join((t_2((undefined(name='union') if l_0_union is missing else l_0_union)), 'DataView', ))
    context.vars['data_view'] = l_0_data_view
    context.exported_vars.add('data_view')
    l_0_data_type = t_2((undefined(name='union') if l_0_union is missing else l_0_union), internal=True)
    context.vars['data_type'] = l_0_data_type
    context.exported_vars.add('data_type')
    yield '\n\nnamespace internal {\n\ntemplate <typename MaybeConstUserType>\nstruct Serializer<'
    yield to_string((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
    yield ', MaybeConstUserType> {\n  using UserType = typename std::remove_const<MaybeConstUserType>::type;\n  using Traits = UnionTraits<'
    yield to_string((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
    yield ', UserType>;\n\n  static void Serialize(MaybeConstUserType& input,\n                        MessageFragment<'
    yield to_string((undefined(name='data_type') if l_0_data_type is missing else l_0_data_type))
    yield '>& fragment,\n                        bool inlined) {\n    if (CallIsNullIfExists<Traits>(input)) {\n       if (inlined)\n        fragment->set_null();\n      return;\n    }\n\n    if (!inlined)\n      fragment.Allocate();\n\n    // TODO(azani): Handle unknown and objects.\n    // Set the not-null flag.\n    fragment->size = kUnionDataSize;\n    fragment->tag = Traits::GetTag(input);\n    switch (fragment->tag) {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        l_1_name = l_1_kind = l_1_serializer_type = missing
        pass
        l_1_name = environment.getattr(l_1_field, 'name')
        l_1_kind = environment.getattr(l_1_field, 'kind')
        l_1_serializer_type = t_13((undefined(name='kind') if l_1_kind is missing else l_1_kind))
        yield '\n      case '
        yield to_string((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
        yield '::Tag::k'
        yield to_string(t_12(environment.getattr(l_1_field, 'name')))
        yield ': {\n        decltype(Traits::'
        yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
        yield '(input))\n            in_'
        yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
        yield ' = Traits::'
        yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
        yield '(input);'
        if t_10((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n        mojo::internal::MessageFragment<\n            typename decltype(fragment->data.f_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ')::BaseType>\n            value_fragment(fragment.message());'
            if t_11((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
                pass
                yield '\n        mojo::internal::Serialize<'
                yield to_string((undefined(name='serializer_type') if l_1_serializer_type is missing else l_1_serializer_type))
                yield '>(\n            in_'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ', value_fragment, false);'
            elif (t_5((undefined(name='kind') if l_1_kind is missing else l_1_kind)) or t_8((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
                pass
                yield '\n        const ContainerValidateParams '
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '_validate_params(\n            '
                yield to_string(t_3(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)), 16))
                yield ');\n        mojo::internal::Serialize<'
                yield to_string((undefined(name='serializer_type') if l_1_serializer_type is missing else l_1_serializer_type))
                yield '>(\n            in_'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ', value_fragment, &'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '_validate_params);'
            else:
                pass
                yield '\n        mojo::internal::Serialize<'
                yield to_string((undefined(name='serializer_type') if l_1_serializer_type is missing else l_1_serializer_type))
                yield '>(\n            in_'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ', value_fragment);'
            if (not t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
                pass
                yield '\n        MOJO_INTERNAL_DLOG_SERIALIZATION_WARNING(\n            value_fragment.is_null(),\n            mojo::internal::VALIDATION_ERROR_UNEXPECTED_NULL_POINTER,\n            "null '
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ' in '
                yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
                yield ' union");'
            yield '\n        fragment->data.f_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '.Set(\n            value_fragment.is_null() ? nullptr : value_fragment.data());'
        elif t_4((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n        mojo::internal::Serialize<'
            yield to_string((undefined(name='serializer_type') if l_1_serializer_type is missing else l_1_serializer_type))
            yield '>(\n            in_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ', &fragment->data.f_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ', &fragment.message());'
            if (not t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
                pass
                yield '\n        MOJO_INTERNAL_DLOG_SERIALIZATION_WARNING(\n            !mojo::internal::IsHandleOrInterfaceValid(fragment->data.f_'
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '),'
                if t_6((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
                    pass
                    yield '\n            mojo::internal::VALIDATION_ERROR_UNEXPECTED_INVALID_INTERFACE_ID,'
                else:
                    pass
                    yield '\n            mojo::internal::VALIDATION_ERROR_UNEXPECTED_INVALID_HANDLE,'
                yield '\n            "invalid '
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ' in '
                yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
                yield ' union");'
        elif t_7((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n        mojo::internal::Serialize<'
            yield to_string((undefined(name='serializer_type') if l_1_serializer_type is missing else l_1_serializer_type))
            yield '>(\n            in_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ', &fragment->data.f_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ');'
        else:
            pass
            yield '\n        fragment->data.f_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ' = in_'
            yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ';'
        yield '\n        break;\n      }'
    l_1_field = l_1_name = l_1_kind = l_1_serializer_type = missing
    yield '\n    }\n  }\n\n  static bool Deserialize('
    yield to_string((undefined(name='data_type') if l_0_data_type is missing else l_0_data_type))
    yield '* input,\n                          UserType* output,\n                          Message* message) {\n    if (!input || input->is_null())\n      return CallSetToNullIfExists<Traits>(output);\n\n    '
    yield to_string((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
    yield ' data_view(input, message);\n    return Traits::Read(data_view, output);\n  }\n};\n\n}  // namespace internal'

blocks = {}
debug_info = '1=26&2=29&7=33&9=35&12=37&28=39&29=42&30=43&31=44&32=46&33=50&34=52&35=56&37=59&39=61&40=64&41=66&42=68&43=71&44=73&45=75&46=77&48=84&49=86&51=88&55=91&57=96&60=98&61=101&62=103&63=107&65=110&66=112&71=119&74=123&75=126&76=128&79=135&87=142&93=144'