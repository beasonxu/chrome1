from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'struct_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_validation_macros = l_0_class_name = l_0_last_checked_version = missing
    t_1 = environment.filters['is_any_handle_or_interface_kind']
    t_2 = environment.filters['is_enum_kind']
    t_3 = environment.filters['is_object_kind']
    t_4 = environment.filters['length']
    pass
    l_0_validation_macros = context.vars['validation_macros'] = environment.get_template('validation_macros.tmpl', 'struct_definition.tmpl')._get_default_module()
    context.exported_vars.discard('validation_macros')
    l_0_class_name = unicode_join((environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'), '_Data', ))
    context.vars['class_name'] = l_0_class_name
    context.exported_vars.add('class_name')
    yield '\n\n// static\nbool '
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '::Validate(\n    const void* data,\n    mojo::internal::ValidationContext* validation_context) {\n  if (!data)\n    return true;'
    if (t_4(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions')) == 1):
        pass
        yield '\n  if (!ValidateUnversionedStructHeaderAndSizeAndClaimMemory(\n          data, '
        yield to_string(environment.getattr(environment.getitem(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'), 0), 'num_bytes'))
        yield ', validation_context)) {\n    return false;\n  }'
    else:
        pass
        yield '\n  static constexpr mojo::internal::StructVersionSize kVersionSizes[] = {'
        for l_1_version in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'):
            pass
            yield '\n    { '
            yield to_string(environment.getattr(l_1_version, 'version'))
            yield ', '
            yield to_string(environment.getattr(l_1_version, 'num_bytes'))
            yield ' },'
        l_1_version = missing
        yield '\n  };\n  if (!ValidateStructHeaderAndVersionSizeAndClaimMemory(\n          data, kVersionSizes, validation_context)) {\n    return false;\n  }'
    yield '\n\n  // NOTE: The memory backing |object| may be smaller than |sizeof(*object)| if\n  // the message comes from an older version.\n  [[maybe_unused]] const '
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '* object =\n      static_cast<const '
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '*>(data);'
    l_0_last_checked_version = 0
    context.vars['last_checked_version'] = l_0_last_checked_version
    context.exported_vars.add('last_checked_version')
    l_1_loop = missing
    for l_1_packed_field, l_1_loop in LoopContext(environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields_in_ordinal_order'), undefined):
        l_1_last_checked_version = l_0_last_checked_version
        l_1_field_expr = resolve('field_expr')
        l_1_kind = missing
        pass
        l_1_kind = environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')
        if ((t_3((undefined(name='kind') if l_1_kind is missing else l_1_kind)) or t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind))) or t_2((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
            pass
            if (environment.getattr(l_1_packed_field, 'min_version') > (undefined(name='last_checked_version') if l_1_last_checked_version is missing else l_1_last_checked_version)):
                pass
                l_1_last_checked_version = environment.getattr(l_1_packed_field, 'min_version')
                yield '\n  if (object->header_.version < '
                yield to_string(environment.getattr(l_1_packed_field, 'min_version'))
                yield ')\n    return true;'
            l_1_field_expr = unicode_join(('object->', environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name'), ))
            yield '\n'
            yield to_string(context.call(environment.getattr((undefined(name='validation_macros') if l_0_validation_macros is missing else l_0_validation_macros), 'validate_field'), environment.getattr(l_1_packed_field, 'field'), environment.getattr(l_1_loop, 'index'), (undefined(name='field_expr') if l_1_field_expr is missing else l_1_field_expr), environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'), True))
    l_1_loop = l_1_packed_field = l_1_kind = l_1_last_checked_version = l_1_field_expr = missing
    yield '\n\n  return true;\n}\n\n'
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '::'
    yield to_string((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '()\n    : header_({sizeof(*this), '
    yield to_string(environment.getattr(environment.getitem(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'), -1), 'version'))
    yield '}) {}'

blocks = {}
debug_info = '1=17&2=19&5=23&11=25&13=28&18=33&19=36&30=43&31=45&37=47&38=51&39=56&40=57&42=59&43=61&44=63&47=65&48=67&55=70&56=74'