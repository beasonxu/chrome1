from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'struct_traits_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_export_attribute = resolve('export_attribute')
    l_0_mojom_type = missing
    t_1 = environment.filters['contains_handles_or_interfaces']
    t_2 = environment.filters['get_qualified_name_for_kind']
    t_3 = environment.filters['is_any_handle_or_interface_kind']
    t_4 = environment.filters['is_object_kind']
    pass
    l_0_mojom_type = t_2((undefined(name='struct') if l_0_struct is missing else l_0_struct))
    context.vars['mojom_type'] = l_0_mojom_type
    context.exported_vars.add('mojom_type')
    yield '\n\ntemplate <>\nstruct '
    yield to_string((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' StructTraits<'
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView,\n                                         '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr> {\n  static bool IsNull(const '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr& input) { return !input; }\n  static void SetToNull('
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr* output) { output->reset(); }'
    for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
        l_1_return_ref = l_1_maybe_const = missing
        pass
        l_1_return_ref = (t_4(environment.getattr(l_1_field, 'kind')) or t_3(environment.getattr(l_1_field, 'kind')))
        yield '\n'
        l_1_maybe_const = ('' if t_1(environment.getattr(l_1_field, 'kind')) else 'const')
        if (undefined(name='return_ref') if l_1_return_ref is missing else l_1_return_ref):
            pass
            yield '\n  static '
            yield to_string((undefined(name='maybe_const') if l_1_maybe_const is missing else l_1_maybe_const))
            yield ' decltype('
            yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
            yield '::'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ')& '
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield '(\n      '
            yield to_string((undefined(name='maybe_const') if l_1_maybe_const is missing else l_1_maybe_const))
            yield ' '
            yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
            yield 'Ptr& input) {\n    return input->'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ';\n  }'
        else:
            pass
            yield '\n  static decltype('
            yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
            yield '::'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ') '
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield '(\n      const '
            yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
            yield 'Ptr& input) {\n    return input->'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ';\n  }'
    l_1_field = l_1_return_ref = l_1_maybe_const = missing
    yield '\n\n  static bool Read('
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView input, '
    yield to_string((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr* output);\n};'

blocks = {}
debug_info = '1=18&4=22&5=26&6=28&7=30&9=32&10=35&17=37&18=38&19=41&20=49&21=53&24=58&25=64&26=66&31=70'