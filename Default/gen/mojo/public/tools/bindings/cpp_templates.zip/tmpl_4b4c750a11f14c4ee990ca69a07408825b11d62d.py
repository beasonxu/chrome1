from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'module.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_variant = resolve('variant')
    l_0_module = resolve('module')
    l_0_variant_path = resolve('variant_path')
    l_0_contains_only_enums = resolve('contains_only_enums')
    l_0_imports = resolve('imports')
    l_0_for_blink = resolve('for_blink')
    l_0_disallow_interfaces = resolve('disallow_interfaces')
    l_0_uses_interfaces = resolve('uses_interfaces')
    l_0_disallow_native_types = resolve('disallow_native_types')
    l_0_uses_native_types = resolve('uses_native_types')
    l_0_extra_public_headers = resolve('extra_public_headers')
    l_0_export_header = resolve('export_header')
    l_0_enable_kythe_annotations = resolve('enable_kythe_annotations')
    l_0_typemap_forward_declarations = resolve('typemap_forward_declarations')
    l_0_all_enums = resolve('all_enums')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_interfaces = resolve('interfaces')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_header_guard = l_0_namespace_begin = l_0_namespace_end = l_0_kythe_annotation = l_0_enum_hash_blink = l_0_module_prefix = missing
    t_1 = environment.filters['format']
    t_2 = environment.filters['format_enum_constant_declaration']
    t_3 = environment.filters['has_callbacks']
    t_4 = environment.filters['is_enum_kind']
    t_5 = environment.filters['is_full_header_required_for_import']
    t_6 = environment.filters['is_native_only_kind']
    t_7 = environment.filters['join']
    t_8 = environment.filters['replace']
    t_9 = environment.filters['reverse']
    t_10 = environment.filters['should_inline']
    t_11 = environment.filters['upper']
    pass
    yield '// Copyright 2013 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
        pass
        l_0_variant_path = t_1('%s-%s', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant))
        context.vars['variant_path'] = l_0_variant_path
        context.exported_vars.add('variant_path')
    else:
        pass
        l_0_variant_path = environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path')
        context.vars['variant_path'] = l_0_variant_path
        context.exported_vars.add('variant_path')
    l_0_header_guard = t_1('%s_H_', t_8(context.eval_ctx, t_8(context.eval_ctx, t_8(context.eval_ctx, t_11((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path)), '/', '_'), '.', '_'), '-', '_'))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    def macro():
        t_12 = []
        pass
        for l_2_namespace in (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array):
            pass
            t_12.extend((
                '\nnamespace ',
                to_string(l_2_namespace),
                ' {',
            ))
        l_2_namespace = missing
        if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
            pass
            t_12.extend((
                '\nnamespace ',
                to_string((undefined(name='variant') if l_0_variant is missing else l_0_variant)),
                ' {',
            ))
        return concat(t_12)
    context.exported_vars.add('namespace_begin')
    context.vars['namespace_begin'] = l_0_namespace_begin = Macro(environment, macro, 'namespace_begin', (), False, False, False, context.eval_ctx.autoescape)
    def macro():
        t_13 = []
        pass
        if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
            pass
            t_13.extend((
                '\n}  // namespace ',
                to_string((undefined(name='variant') if l_0_variant is missing else l_0_variant)),
            ))
        for l_2_namespace in t_9((undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)):
            pass
            t_13.extend((
                '\n}  // namespace ',
                to_string(l_2_namespace),
            ))
        l_2_namespace = missing
        return concat(t_13)
    context.exported_vars.add('namespace_end')
    context.vars['namespace_end'] = l_0_namespace_end = Macro(environment, macro, 'namespace_end', (), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_name):
        t_14 = []
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
            pass
            t_14.extend((
                '\n// @generated_from: ',
                to_string(l_1_name),
            ))
        return concat(t_14)
    context.exported_vars.add('kythe_annotation')
    context.vars['kythe_annotation'] = l_0_kythe_annotation = Macro(environment, macro, 'kythe_annotation', ('name',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n#ifndef '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include <stdint.h>\n\n#include <limits>\n#include <type_traits>\n#include <utility>\n\n#include "third_party/abseil-cpp/absl/types/optional.h"'
    if (undefined(name='contains_only_enums') if l_0_contains_only_enums is missing else l_0_contains_only_enums):
        pass
        yield '\n#include "mojo/public/cpp/bindings/type_converter.h"'
    else:
        pass
        yield '\n#include "mojo/public/cpp/bindings/clone_traits.h"\n#include "mojo/public/cpp/bindings/equals_traits.h"\n#include "mojo/public/cpp/bindings/lib/serialization.h"\n#include "mojo/public/cpp/bindings/struct_ptr.h"\n#include "mojo/public/cpp/bindings/struct_traits.h"\n#include "mojo/public/cpp/bindings/union_traits.h"'
    yield '\n\n#include "third_party/perfetto/include/perfetto/tracing/traced_value_forward.h"\n\n#include "'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-shared.h"\n#include "'
    yield to_string((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path))
    yield '-forward.h"'
    for l_1_import in (undefined(name='imports') if l_0_imports is missing else l_0_imports):
        pass
        if t_5(l_1_import):
            pass
            if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
                pass
                yield '\n#include "'
                yield to_string(t_1('%s-%s.h', environment.getattr(l_1_import, 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
                yield '"'
            else:
                pass
                yield '\n#include "'
                yield to_string(environment.getattr(l_1_import, 'path'))
                yield '.h"'
        else:
            pass
            if (undefined(name='variant') if l_0_variant is missing else l_0_variant):
                pass
                yield '\n#include "'
                yield to_string(t_1('%s-%s-forward.h', environment.getattr(l_1_import, 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
                yield '"'
            else:
                pass
                yield '\n#include "'
                yield to_string(environment.getattr(l_1_import, 'path'))
                yield '-forward.h"'
    l_1_import = missing
    if (not (undefined(name='for_blink') if l_0_for_blink is missing else l_0_for_blink)):
        pass
        yield '\n#include <string>\n#include <vector>'
    else:
        pass
        yield '\n\n#include "mojo/public/cpp/bindings/lib/wtf_clone_equals_util.h"\n#include "mojo/public/cpp/bindings/lib/wtf_hash_util.h"\n#include "third_party/blink/renderer/platform/wtf/hash_functions.h"\n#include "third_party/blink/renderer/platform/wtf/text/wtf_string.h"'
    yield '\n\n'
    if ((not (undefined(name='disallow_interfaces') if l_0_disallow_interfaces is missing else l_0_disallow_interfaces)) and (undefined(name='uses_interfaces') if l_0_uses_interfaces is missing else l_0_uses_interfaces)):
        pass
        yield '#include "mojo/public/cpp/bindings/lib/control_message_handler.h"\n#include "mojo/public/cpp/bindings/raw_ptr_impl_ref_traits.h"'
    yield '\n\n'
    if ((not (undefined(name='disallow_native_types') if l_0_disallow_native_types is missing else l_0_disallow_native_types)) and (undefined(name='uses_native_types') if l_0_uses_native_types is missing else l_0_uses_native_types)):
        pass
        yield '\n#include "mojo/public/cpp/bindings/lib/native_enum_serialization.h"\n#include "mojo/public/cpp/bindings/lib/native_struct_serialization.h"'
    for l_1_header in (undefined(name='extra_public_headers') if l_0_extra_public_headers is missing else l_0_extra_public_headers):
        pass
        yield '\n#include "'
        yield to_string(l_1_header)
        yield '"'
    l_1_header = missing
    if (undefined(name='export_header') if l_0_export_header is missing else l_0_export_header):
        pass
        yield '\n#include "'
        yield to_string((undefined(name='export_header') if l_0_export_header is missing else l_0_export_header))
        yield '"'
    yield '\n\n'
    if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
        pass
        yield '#ifdef KYTHE_IS_RUNNING\n#pragma kythe_inline_metadata "Metadata comment"\n#endif'
    for l_1_forward_declaration in (undefined(name='typemap_forward_declarations') if l_0_typemap_forward_declarations is missing else l_0_typemap_forward_declarations):
        pass
        yield '\n'
        yield to_string(l_1_forward_declaration)
    l_1_forward_declaration = missing
    included_template = environment.get_template('enum_macros.tmpl', 'module.h.tmpl')._get_default_module()
    l_0_enum_hash_blink = getattr(included_template, 'enum_hash_blink', missing)
    if l_0_enum_hash_blink is missing:
        l_0_enum_hash_blink = undefined("the template %r (imported on line 123 in 'module.h.tmpl') does not export the requested name 'enum_hash_blink'" % included_template.__name__, name='enum_hash_blink')
    context.vars['enum_hash_blink'] = l_0_enum_hash_blink
    context.exported_vars.discard('enum_hash_blink')
    if (undefined(name='for_blink') if l_0_for_blink is missing else l_0_for_blink):
        pass
        for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
            pass
            if (not t_6(l_1_enum)):
                pass
                yield '\n'
                yield to_string(context.call((undefined(name='enum_hash_blink') if l_0_enum_hash_blink is missing else l_0_enum_hash_blink), l_1_enum))
        l_1_enum = missing
    for l_1_constant in environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'):
        pass
        if t_4(environment.getattr(l_1_constant, 'kind')):
            pass
            yield '\n'
            yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_1('%s.%s', (undefined(name='module_prefix') if l_0_module_prefix is missing else l_0_module_prefix), environment.getattr(l_1_constant, 'name'))))
            yield '\n'
            yield to_string(t_2(l_1_constant))
            yield ';'
    l_1_constant = missing
    yield '\n\n'
    yield to_string(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin)))
    l_0_module_prefix = t_1('%s', t_7(context.eval_ctx, (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), '.'))
    context.vars['module_prefix'] = l_0_module_prefix
    context.exported_vars.add('module_prefix')
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        yield '\n'
        template = environment.get_template('interface_declaration.tmpl', 'module.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_hash_blink': l_0_enum_hash_blink, 'header_guard': l_0_header_guard, 'interface': l_1_interface, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
            yield event
    l_1_interface = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        yield '\n'
        template = environment.get_template('interface_proxy_declaration.tmpl', 'module.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_hash_blink': l_0_enum_hash_blink, 'header_guard': l_0_header_guard, 'interface': l_1_interface, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
            yield event
    l_1_interface = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        yield '\n'
        template = environment.get_template('interface_stub_declaration.tmpl', 'module.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_hash_blink': l_0_enum_hash_blink, 'header_guard': l_0_header_guard, 'interface': l_1_interface, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
            yield event
    l_1_interface = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        yield '\n'
        template = environment.get_template('interface_request_validator_declaration.tmpl', 'module.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_hash_blink': l_0_enum_hash_blink, 'header_guard': l_0_header_guard, 'interface': l_1_interface, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
            yield event
    l_1_interface = missing
    def t_15(fiter):
        for l_1_interface in fiter:
            if t_3(l_1_interface):
                yield l_1_interface
    for l_1_interface in t_15((undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces)):
        pass
        yield '\n'
        template = environment.get_template('interface_response_validator_declaration.tmpl', 'module.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_hash_blink': l_0_enum_hash_blink, 'header_guard': l_0_header_guard, 'interface': l_1_interface, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
            yield event
    l_1_interface = missing
    yield '\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        yield '\n'
        if (t_10(l_1_struct) and (not t_6(l_1_struct))):
            pass
            yield '\n'
            template = environment.get_template('wrapper_class_declaration.tmpl', 'module.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_hash_blink': l_0_enum_hash_blink, 'header_guard': l_0_header_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'struct': l_1_struct, 'variant_path': l_0_variant_path})):
                yield event
            yield '\n'
    l_1_struct = missing
    yield '\n'
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        yield '\n'
        template = environment.get_template('wrapper_union_class_declaration.tmpl', 'module.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_hash_blink': l_0_enum_hash_blink, 'header_guard': l_0_header_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'union': l_1_union, 'variant_path': l_0_variant_path})):
            yield event
    l_1_union = missing
    yield '\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        yield '\n'
        if ((not t_10(l_1_struct)) and (not t_6(l_1_struct))):
            pass
            yield '\n'
            template = environment.get_template('wrapper_class_declaration.tmpl', 'module.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_hash_blink': l_0_enum_hash_blink, 'header_guard': l_0_header_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'struct': l_1_struct, 'variant_path': l_0_variant_path})):
                yield event
            yield '\n'
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        yield '\n'
        template = environment.get_template('wrapper_union_class_template_definition.tmpl', 'module.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_hash_blink': l_0_enum_hash_blink, 'header_guard': l_0_header_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'union': l_1_union, 'variant_path': l_0_variant_path})):
            yield event
    l_1_union = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        if (not t_6(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('wrapper_class_template_definition.tmpl', 'module.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_hash_blink': l_0_enum_hash_blink, 'header_guard': l_0_header_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'struct': l_1_struct, 'variant_path': l_0_variant_path})):
                yield event
    l_1_struct = missing
    yield '\n\n'
    yield to_string(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end)))
    yield '\n\nnamespace mojo {'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        if (not t_6(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('struct_traits_declaration.tmpl', 'module.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_hash_blink': l_0_enum_hash_blink, 'header_guard': l_0_header_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'struct': l_1_struct, 'variant_path': l_0_variant_path})):
                yield event
    l_1_struct = missing
    if (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
            pass
            yield '\n'
            template = environment.get_template('union_traits_declaration.tmpl', 'module.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_hash_blink': l_0_enum_hash_blink, 'header_guard': l_0_header_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'union': l_1_union, 'variant_path': l_0_variant_path})):
                yield event
        l_1_union = missing
    yield '\n\n}  // namespace mojo\n\n#endif  // '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=43&6=45&8=50&11=53&15=56&16=59&17=63&19=67&20=71&24=77&25=80&26=84&28=86&29=90&33=96&34=101&35=105&39=111&40=113&50=115&63=122&64=124&66=126&67=128&68=130&69=133&71=138&74=142&75=145&77=150&82=153&94=160&99=164&104=167&105=170&108=173&109=176&112=179&118=182&119=185&123=187&124=193&125=195&126=197&127=200&133=202&134=204&135=207&136=209&140=213&142=214&145=217&146=220&150=224&151=227&155=231&156=234&160=238&161=241&165=245&166=252&173=257&174=260&175=263&182=269&183=272&187=277&188=280&189=283&193=288&194=291&197=295&198=297&199=300&203=305&208=307&209=309&210=312&215=316&216=318&217=321&223=326'