from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'interface_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_module_prefix = resolve('module_prefix')
    l_0_kythe_annotation = resolve('kythe_annotation')
    l_0_export_attribute = resolve('export_attribute')
    l_0_sandbox_enum = resolve('sandbox_enum')
    l_0_interface_macros = l_0_interface_prefix = missing
    t_1 = environment.filters['default']
    t_2 = environment.filters['format']
    t_3 = environment.filters['format_constant_declaration']
    t_4 = environment.filters['get_full_mojom_name_for_kind']
    t_5 = environment.filters['get_name_for_kind']
    t_6 = environment.filters['has_callbacks']
    t_7 = environment.filters['has_sync_methods']
    t_8 = environment.filters['has_uninterruptable_methods']
    t_9 = environment.filters['passes_associated_kinds']
    t_10 = environment.filters['replace']
    pass
    l_0_interface_macros = context.vars['interface_macros'] = environment.get_template('interface_macros.tmpl', 'interface_declaration.tmpl')._get_default_module()
    context.exported_vars.discard('interface_macros')
    yield '\nclass '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Proxy;\n\ntemplate <typename ImplRefTraits>\nclass '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub;\n\nclass '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'RequestValidator;'
    if t_6((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield '\nclass '
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'ResponseValidator;'
    l_0_interface_prefix = t_2('%s.%s', (undefined(name='module_prefix') if l_0_module_prefix is missing else l_0_module_prefix), environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    context.vars['interface_prefix'] = l_0_interface_prefix
    context.exported_vars.add('interface_prefix')
    yield '\n\n'
    yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), (undefined(name='interface_prefix') if l_0_interface_prefix is missing else l_0_interface_prefix)))
    yield '\nclass '
    yield to_string((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '\n    : public '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'InterfaceBase {\n public:\n  using IPCStableHashFunction = uint32_t(*)();\n\n  static const char Name_[];\n  static IPCStableHashFunction MessageToMethodInfo_(mojo::Message& message);\n  static const char* MessageToMethodName_(mojo::Message& message);'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'uuid'):
        pass
        yield '\n  static constexpr base::Token Uuid_{ '
        yield to_string(environment.getitem(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'uuid'), 0))
        yield 'ULL,\n                                      '
        yield to_string(environment.getitem(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'uuid'), 1))
        yield 'ULL };'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'service_sandbox'):
        pass
        l_0_sandbox_enum = t_2('%s', t_10(context.eval_ctx, context.call(environment.getattr(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'service_sandbox'), 'GetSpec')), '.', '::'))
        context.vars['sandbox_enum'] = l_0_sandbox_enum
        context.exported_vars.add('sandbox_enum')
        yield '\n  static constexpr auto kServiceSandbox = '
        yield to_string((undefined(name='sandbox_enum') if l_0_sandbox_enum is missing else l_0_sandbox_enum))
        yield ';'
    yield '\n  static constexpr uint32_t Version_ = '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'version'))
    yield ';\n  static constexpr bool PassesAssociatedKinds_ = '
    if t_9((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield 'true'
    else:
        pass
        yield 'false'
    yield ';\n  static constexpr bool HasSyncMethods_ = '
    if t_7((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield 'true'
    else:
        pass
        yield 'false'
    yield ';\n  static constexpr bool HasUninterruptableMethods_ ='
    if t_8((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield ' true'
    else:
        pass
        yield ' false'
    yield ';\n\n  using Base_ = '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'InterfaceBase;\n  using Proxy_ = '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Proxy;\n\n  template <typename ImplRefTraits>\n  using Stub_ = '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub<ImplRefTraits>;\n\n  using RequestValidator_ = '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'RequestValidator;'
    if t_6((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield '\n  using ResponseValidator_ = '
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'ResponseValidator;'
    else:
        pass
        yield '\n  using ResponseValidator_ = mojo::PassThroughFilter;'
    yield '\n  enum MethodMinVersions : uint32_t {'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        yield '\n    k'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield 'MinVersion = '
        yield to_string(t_1(environment.getattr(l_1_method, 'min_version'), 0, True))
        yield ','
    l_1_method = missing
    yield "\n  };\n\n// crbug.com/1340245 - this causes binary size bloat on Fuchsia, and we're OK\n// with not having this data in traces there.\n#if !BUILDFLAG(IS_FUCHSIA)"
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        yield '\n  struct '
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield '_Sym {\n    NOINLINE static uint32_t IPCStableHash();\n  };'
    l_1_method = missing
    yield '\n#endif // !BUILDFLAG(IS_FUCHSIA)'
    for l_1_enum in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'enums'):
        pass
        yield '\n  '
        yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_4(l_1_enum)))
        yield '\n  using '
        yield to_string(environment.getattr(l_1_enum, 'name'))
        yield ' = '
        yield to_string(t_5(l_1_enum, flatten_nested_kind=True))
        yield ';'
    l_1_enum = missing
    for l_1_constant in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'constants'):
        pass
        yield '\n  '
        yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_2('%s.%s', (undefined(name='interface_prefix') if l_0_interface_prefix is missing else l_0_interface_prefix), environment.getattr(l_1_constant, 'name'))))
        yield '\n  static '
        yield to_string(t_3(l_1_constant, nested=True))
        yield ';'
    l_1_constant = missing
    yield '\n  virtual ~'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '() = default;'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_for_blink = resolve('for_blink')
        pass
        yield '\n'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            if environment.getattr(l_1_method, 'sync'):
                pass
                yield '\n  // Sync method. This signature is used by the client side; the service side\n  // should implement the signature with callback below.\n  '
                yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_2('%s.%s', (undefined(name='interface_prefix') if l_0_interface_prefix is missing else l_0_interface_prefix), environment.getattr(l_1_method, 'name'))))
                yield '\n  virtual bool '
                yield to_string(environment.getattr(l_1_method, 'name'))
                yield '('
                yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_sync_method_params'), '', l_1_method))
                yield ');'
            yield '\n\n  using '
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield 'Callback = '
            yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_callback'), l_1_method, (undefined(name='for_blink') if l_1_for_blink is missing else l_1_for_blink)))
            yield ';'
        yield '\n  '
        yield to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_2('%s.%s', (undefined(name='interface_prefix') if l_0_interface_prefix is missing else l_0_interface_prefix), environment.getattr(l_1_method, 'name'))))
        yield '\n  virtual void '
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield '('
        yield to_string(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_request_params'), '', l_1_method))
        yield ') = 0;'
    l_1_method = l_1_for_blink = missing
    yield '\n};'

blocks = {}
debug_info = '1=27&2=30&5=32&7=34&8=36&9=39&12=41&14=45&15=47&16=51&25=53&26=56&27=58&29=60&30=62&31=66&33=69&34=71&35=78&37=85&40=92&41=94&44=96&46=98&47=100&48=103&55=109&56=112&64=118&65=121&72=125&73=128&74=130&78=135&79=138&80=140&84=144&86=146&87=150&88=152&91=155&92=157&95=162&97=167&98=169'