from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'module-params-data.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_interfaces = resolve('interfaces')
    l_0_header_guard = missing
    t_1 = environment.filters['format']
    t_2 = environment.filters['replace']
    t_3 = environment.filters['reverse']
    t_4 = environment.filters['upper']
    pass
    yield '// Copyright 2019 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    l_0_header_guard = t_1('%s_PARAMS_DATA_H_', t_2(context.eval_ctx, t_2(context.eval_ctx, t_2(context.eval_ctx, t_4(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path')), '/', '_'), '.', '_'), '-', '_'))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    yield '\n\n#ifndef '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include "mojo/public/cpp/bindings/lib/bindings_internal.h"\n#include "mojo/public/cpp/bindings/lib/buffer.h"\n\n#if defined(__clang__)\n#pragma clang diagnostic push\n#pragma clang diagnostic ignored "-Wunused-private-field"\n#endif'
    for l_1_namespace in (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array):
        pass
        yield '\nnamespace '
        yield to_string(l_1_namespace)
        yield ' {'
    l_1_namespace = missing
    yield '\nnamespace internal {\n\nclass ValidationContext;'
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_struct = missing
            pass
            l_2_struct = environment.getattr(l_2_method, 'param_struct')
            yield '\n'
            template = environment.get_template('struct_declaration.tmpl', 'module-params-data.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'header_guard': l_0_header_guard, 'interface': l_1_interface, 'method': l_2_method, 'struct': l_2_struct})):
                yield event
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                l_2_struct = environment.getattr(l_2_method, 'response_param_struct')
                yield '\n'
                template = environment.get_template('struct_declaration.tmpl', 'module-params-data.h.tmpl')
                for event in template.root_render_func(template.new_context(context.get_all(), True, {'header_guard': l_0_header_guard, 'interface': l_1_interface, 'method': l_2_method, 'struct': l_2_struct})):
                    yield event
        l_2_method = l_2_struct = missing
    l_1_interface = missing
    yield '\n\n}  // namespace internal'
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_struct = missing
            pass
            l_2_struct = environment.getattr(l_2_method, 'param_struct')
            yield '\n'
            template = environment.get_template('struct_data_view_declaration.tmpl', 'module-params-data.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'header_guard': l_0_header_guard, 'interface': l_1_interface, 'method': l_2_method, 'struct': l_2_struct})):
                yield event
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                l_2_struct = environment.getattr(l_2_method, 'response_param_struct')
                yield '\n'
                template = environment.get_template('struct_data_view_declaration.tmpl', 'module-params-data.h.tmpl')
                for event in template.root_render_func(template.new_context(context.get_all(), True, {'header_guard': l_0_header_guard, 'interface': l_1_interface, 'method': l_2_method, 'struct': l_2_struct})):
                    yield event
        l_2_method = l_2_struct = missing
    l_1_interface = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_struct = missing
            pass
            l_2_struct = environment.getattr(l_2_method, 'param_struct')
            yield '\n'
            template = environment.get_template('struct_data_view_definition.tmpl', 'module-params-data.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'header_guard': l_0_header_guard, 'interface': l_1_interface, 'method': l_2_method, 'struct': l_2_struct})):
                yield event
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                l_2_struct = environment.getattr(l_2_method, 'response_param_struct')
                yield '\n'
                template = environment.get_template('struct_data_view_definition.tmpl', 'module-params-data.h.tmpl')
                for event in template.root_render_func(template.new_context(context.get_all(), True, {'header_guard': l_0_header_guard, 'interface': l_1_interface, 'method': l_2_method, 'struct': l_2_struct})):
                    yield event
        l_2_method = l_2_struct = missing
    l_1_interface = missing
    for l_1_namespace in t_3((undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)):
        pass
        yield '\n}  // namespace '
        yield to_string(l_1_namespace)
    l_1_namespace = missing
    yield '\n\n#if defined(__clang__)\n#pragma clang diagnostic pop\n#endif\n\n#endif  // '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=20&9=24&10=26&20=28&21=31&28=35&29=37&30=40&31=42&32=45&33=47&34=49&42=55&43=57&44=60&45=62&46=65&47=67&48=69&53=74&54=76&55=79&56=81&57=84&58=86&59=88&64=93&65=96&72=99'