from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'enum_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_kythe_annotation = l_0_enum_forward = l_0_enum_decl = l_0_enum_stream = l_0_enum_to_string = l_0_enum_data_decl = l_0_enum_hash = l_0_enum_hash_blink = l_0_enum_trace_format_traits_decl = l_0_enum_trace_format_traits = missing
    t_1 = environment.filters['all_enum_values']
    t_2 = environment.filters['format']
    t_3 = environment.filters['get_full_mojom_name_for_kind']
    t_4 = environment.filters['get_name_for_kind']
    t_5 = environment.filters['get_qualified_name_for_kind']
    t_6 = environment.filters['groupby']
    t_7 = environment.filters['join']
    t_8 = environment.filters['length']
    t_9 = environment.filters['map']
    t_10 = environment.filters['wtf_hash_fn_name_for_enum']
    t_11 = environment.tests['none']
    pass
    def macro(l_1_name):
        t_12 = []
        l_1_enable_kythe_annotations = resolve('enable_kythe_annotations')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (undefined(name='enable_kythe_annotations') if l_1_enable_kythe_annotations is missing else l_1_enable_kythe_annotations):
            pass
            t_12.extend((
                '\n// @generated_from: ',
                to_string(l_1_name),
            ))
        return concat(t_12)
    context.exported_vars.add('kythe_annotation')
    context.vars['kythe_annotation'] = l_0_kythe_annotation = Macro(environment, macro, 'kythe_annotation', ('name',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_13 = []
        l_1_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_enum_name = t_4(l_1_enum, flatten_nested_kind=True)
        t_13.extend((
            '\nenum class ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' : int32_t;',
        ))
        return concat(t_13)
    context.exported_vars.add('enum_forward')
    context.vars['enum_forward'] = l_0_enum_forward = Macro(environment, macro, 'enum_forward', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum, l_1_export_attribute):
        t_14 = []
        l_1_enum_name = l_1_full_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        if l_1_export_attribute is missing:
            l_1_export_attribute = undefined("parameter 'export_attribute' was not provided", name='export_attribute')
        pass
        l_1_enum_name = t_4(l_1_enum, flatten_nested_kind=True)
        l_1_full_enum_name = t_3(l_1_enum)
        t_14.extend((
            '\n',
            to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), (undefined(name='full_enum_name') if l_1_full_enum_name is missing else l_1_full_enum_name))),
            '\nenum class ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' : int32_t {',
        ))
        for l_2_field in environment.getattr(l_1_enum, 'fields'):
            pass
            t_14.extend((
                '\n  ',
                to_string(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_2('%s.%s', (undefined(name='full_enum_name') if l_1_full_enum_name is missing else l_1_full_enum_name), environment.getattr(l_2_field, 'name')))),
                '\n  ',
                to_string(environment.getattr(l_2_field, 'name')),
                ' = ',
                to_string(environment.getattr(l_2_field, 'numeric_value')),
                ',',
            ))
        l_2_field = missing
        if (not t_11(environment.getattr(l_1_enum, 'min_value'))):
            pass
            t_14.extend((
                '\n  kMinValue = ',
                to_string(environment.getattr(l_1_enum, 'min_value')),
                ',',
            ))
        if (not t_11(environment.getattr(l_1_enum, 'max_value'))):
            pass
            t_14.extend((
                '\n  kMaxValue = ',
                to_string(environment.getattr(l_1_enum, 'max_value')),
                ',',
            ))
        if environment.getattr(l_1_enum, 'default_field'):
            pass
            t_14.extend((
                '\n  kDefaultValue = ',
                to_string(environment.getattr(environment.getattr(l_1_enum, 'default_field'), 'numeric_value')),
            ))
        t_14.extend((
            '\n};\n\n',
            to_string(l_1_export_attribute),
            ' std::ostream& operator<<(std::ostream& os, ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value);\ninline bool IsKnownEnumValue(',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value) {\n  return ',
            to_string(t_4(l_1_enum, internal=True, flatten_nested_kind=True)),
            '::IsKnownValue(\n      static_cast<int32_t>(value));\n}',
        ))
        if (environment.getattr(l_1_enum, 'extensible') and environment.getattr(l_1_enum, 'default_field')):
            pass
            t_14.extend((
                '\ninline ',
                to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
                ' ToKnownEnumValue(',
                to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
                ' value) {\n  if (IsKnownEnumValue(value)) {\n    return value;\n  }\n  return ',
                to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
                '::kDefaultValue;\n}',
            ))
        return concat(t_14)
    context.exported_vars.add('enum_decl')
    context.vars['enum_decl'] = l_0_enum_decl = Macro(environment, macro, 'enum_decl', ('enum', 'export_attribute'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_15 = []
        l_1_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_enum_name = t_4(l_1_enum, flatten_nested_kind=True)
        t_15.extend((
            '\nstd::ostream& operator<<(std::ostream& os, ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value) {\n  return os << ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            'ToString(value);\n}',
        ))
        return concat(t_15)
    context.exported_vars.add('enum_stream')
    context.vars['enum_stream'] = l_0_enum_stream = Macro(environment, macro, 'enum_stream', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_16 = []
        l_1_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_enum_name = t_4(l_1_enum, flatten_nested_kind=True)
        t_16.extend((
            '\nstatic NOINLINE const char* ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            'ToStringHelper(',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value) {\n  // Defined in a helper function to ensure that Clang generates a lookup table.',
        ))
        if environment.getattr(l_1_enum, 'fields'):
            pass
            t_16.append(
                '\n  switch(value) {',
            )
            for (l_2__, l_2_values) in t_6(environment, environment.getattr(l_1_enum, 'fields'), 'numeric_value'):
                pass
                t_16.extend((
                    '\n    case ',
                    to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
                    '::',
                    to_string(environment.getattr(environment.getitem(l_2_values, 0), 'name')),
                    ':\n      return "',
                ))
                if (t_8(l_2_values) > 1):
                    pass
                    t_16.append(
                        '{',
                    )
                t_16.append(
                    to_string(t_7(context.eval_ctx, t_9(context, l_2_values, attribute='name'), ', ')),
                )
                if (t_8(l_2_values) > 1):
                    pass
                    t_16.append(
                        '}',
                    )
                t_16.append(
                    '";',
                )
            l_2__ = l_2_values = missing
            t_16.append(
                '\n    default:\n      return nullptr;\n  }',
            )
        else:
            pass
            t_16.append(
                '\n  return nullptr;',
            )
        t_16.extend((
            '\n}\n\nstd::string ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            'ToString(',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value) {\n  const char *str = ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            'ToStringHelper(value);\n  if (!str) {\n    return base::StringPrintf("Unknown ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value: %i", static_cast<int32_t>(value));\n  }\n  return str;\n}',
        ))
        return concat(t_16)
    context.exported_vars.add('enum_to_string')
    context.vars['enum_to_string'] = l_0_enum_to_string = Macro(environment, macro, 'enum_to_string', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_17 = []
        l_1_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_enum_name = t_4(l_1_enum, flatten_nested_kind=True)
        t_17.extend((
            '\nstruct ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '_Data {\n public:\n  static bool constexpr kIsExtensible = ',
        ))
        if environment.getattr(l_1_enum, 'extensible'):
            pass
            t_17.append(
                'true',
            )
        else:
            pass
            t_17.append(
                'false',
            )
        t_17.append(
            ';\n\n  static bool IsKnownValue(int32_t value) {',
        )
        if environment.getattr(l_1_enum, 'fields'):
            pass
            t_17.append(
                '\n    switch (value) {',
            )
            for l_2_enum_field in t_6(environment, environment.getattr(l_1_enum, 'fields'), 'numeric_value'):
                pass
                t_17.extend((
                    '\n      case ',
                    to_string(environment.getitem(l_2_enum_field, 0)),
                    ':',
                ))
            l_2_enum_field = missing
            t_17.append(
                '\n        return true;\n    }',
            )
        t_17.append(
            '\n    return false;\n  }\n\n  static bool Validate(int32_t value,\n                       mojo::internal::ValidationContext* validation_context) {\n    if (kIsExtensible || IsKnownValue(value))\n      return true;\n\n    ReportValidationError(validation_context,\n                          mojo::internal::VALIDATION_ERROR_UNKNOWN_ENUM_VALUE);\n    return false;\n  }\n};',
        )
        return concat(t_17)
    context.exported_vars.add('enum_data_decl')
    context.vars['enum_data_decl'] = l_0_enum_data_decl = Macro(environment, macro, 'enum_data_decl', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_18 = []
        l_1_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_enum_name = t_5(l_1_enum, flatten_nested_kind=True)
        t_18.extend((
            '\ntemplate <>\nstruct hash<',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '>\n    : public mojo::internal::EnumHashImpl<',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '> {};',
        ))
        return concat(t_18)
    context.exported_vars.add('enum_hash')
    context.vars['enum_hash'] = l_0_enum_hash = Macro(environment, macro, 'enum_hash', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_19 = []
        l_1_enum_name = l_1_hash_fn_name = l_1_empty_value = l_1_deleted_value = l_1_empty_value_unused = l_1_deleted_value_unused = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_enum_name = t_5(l_1_enum, flatten_nested_kind=True, include_variant=False)
        l_1_hash_fn_name = t_10(l_1_enum)
        t_19.append(
            '\n',
        )
        l_1_empty_value = -1000000
        l_1_deleted_value = -1000001
        l_1_empty_value_unused = ('false' if ((undefined(name='empty_value') if l_1_empty_value is missing else l_1_empty_value) in t_1(l_1_enum)) else 'true')
        l_1_deleted_value_unused = ('false' if ((undefined(name='empty_value') if l_1_empty_value is missing else l_1_empty_value) in t_1(l_1_enum)) else 'true')
        t_19.extend((
            '\nnamespace WTF {\nstruct ',
            to_string((undefined(name='hash_fn_name') if l_1_hash_fn_name is missing else l_1_hash_fn_name)),
            ' {\n  static unsigned GetHash(const ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '& value) {\n    using utype = std::underlying_type<',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '>::type;\n    return DefaultHash<utype>::Hash().GetHash(static_cast<utype>(value));\n  }\n  static bool Equal(const ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '& left, const ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '& right) {\n    return left == right;\n  }\n  static const bool safe_to_compare_to_empty_or_deleted = true;\n};\n\ntemplate <>\nstruct HashTraits<',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '>\n    : public GenericHashTraits<',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '> {\n  static_assert(',
            to_string((undefined(name='empty_value_unused') if l_1_empty_value_unused is missing else l_1_empty_value_unused)),
            ',\n                "',
            to_string((undefined(name='empty_value') if l_1_empty_value is missing else l_1_empty_value)),
            ' is a reserved enum value");\n  static_assert(',
            to_string((undefined(name='deleted_value_unused') if l_1_deleted_value_unused is missing else l_1_deleted_value_unused)),
            ',\n                "',
            to_string((undefined(name='deleted_value') if l_1_deleted_value is missing else l_1_deleted_value)),
            ' is a reserved enum value");\n  static const bool kEmptyValueIsZero = false;\n  static ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' EmptyValue() { return static_cast<',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '>(',
            to_string((undefined(name='empty_value') if l_1_empty_value is missing else l_1_empty_value)),
            '); }\n  static void ConstructDeletedValue(',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '& slot, bool) {\n    slot = static_cast<',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '>(',
            to_string((undefined(name='deleted_value') if l_1_deleted_value is missing else l_1_deleted_value)),
            ');\n  }\n  static bool IsDeletedValue(const ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '& value) {\n    return value == static_cast<',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '>(',
            to_string((undefined(name='deleted_value') if l_1_deleted_value is missing else l_1_deleted_value)),
            ');\n  }\n};\n}  // namespace WTF',
        ))
        return concat(t_19)
    context.exported_vars.add('enum_hash_blink')
    context.vars['enum_hash_blink'] = l_0_enum_hash_blink = Macro(environment, macro, 'enum_hash_blink', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum, l_1_export_attributes):
        t_20 = []
        l_1_export_attribute = resolve('export_attribute')
        l_1_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        if l_1_export_attributes is missing:
            l_1_export_attributes = undefined("parameter 'export_attributes' was not provided", name='export_attributes')
        pass
        l_1_enum_name = t_5(l_1_enum, flatten_nested_kind=True)
        t_20.extend((
            '\nnamespace perfetto {\n\ntemplate <>\nstruct ',
            to_string((undefined(name='export_attribute') if l_1_export_attribute is missing else l_1_export_attribute)),
            ' TraceFormatTraits<',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '> {\n static void WriteIntoTrace(perfetto::TracedValue context, ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value);\n};\n\n} // namespace perfetto',
        ))
        return concat(t_20)
    context.exported_vars.add('enum_trace_format_traits_decl')
    context.vars['enum_trace_format_traits_decl'] = l_0_enum_trace_format_traits_decl = Macro(environment, macro, 'enum_trace_format_traits_decl', ('enum', 'export_attributes'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_21 = []
        l_1_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_enum_name = t_5(l_1_enum, flatten_nested_kind=True)
        t_21.extend((
            '\nnamespace perfetto {\n\n// static\nvoid TraceFormatTraits<',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '>::WriteIntoTrace(\n   perfetto::TracedValue context, ',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value) {\n  return std::move(context).WriteString(',
            to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            'ToString(value));\n}\n\n} // namespace perfetto',
        ))
        return concat(t_21)
    context.exported_vars.add('enum_trace_format_traits')
    context.vars['enum_trace_format_traits'] = l_0_enum_trace_format_traits = Macro(environment, macro, 'enum_trace_format_traits', ('enum',), False, False, False, context.eval_ctx.autoescape)
    yield 'endmacro '

blocks = {}
debug_info = '5=23&6=29&7=33&11=38&12=44&13=47&16=53&17=61&19=62&20=65&21=67&22=70&23=74&24=76&26=82&27=86&29=89&30=93&32=96&33=100&37=104&40=108&41=110&46=113&47=117&51=121&56=127&57=133&58=136&59=138&63=144&64=150&65=153&67=158&69=163&70=167&72=172&75=178&76=180&89=199&90=203&92=205&98=211&99=217&100=220&102=223&105=236&107=241&108=245&128=258&129=264&132=267&133=269&136=275&137=281&139=282&141=286&142=287&143=288&144=289&146=292&147=294&148=296&151=298&158=302&159=304&160=306&161=308&162=310&163=312&165=314&166=320&167=322&169=326&170=328&176=336&177=345&182=348&183=352&189=358&190=364&195=367&196=369&197=371'