from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'module-shared.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_contains_only_enums = resolve('contains_only_enums')
    l_0_imports = resolve('imports')
    l_0_disallow_interfaces = resolve('disallow_interfaces')
    l_0_uses_interfaces = resolve('uses_interfaces')
    l_0_disallow_native_types = resolve('disallow_native_types')
    l_0_uses_native_types = resolve('uses_native_types')
    l_0_export_header = resolve('export_header')
    l_0_enable_kythe_annotations = resolve('enable_kythe_annotations')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_all_enums = resolve('all_enums')
    l_0_interfaces = resolve('interfaces')
    l_0_header_guard = l_0_mojom_type_traits = l_0_namespace_begin = l_0_namespace_end = l_0_module_prefix = l_0_enum_decl = l_0_enum_hash = l_0_enum_trace_format_traits_decl = missing
    t_1 = environment.filters['format']
    t_2 = environment.filters['get_name_for_kind']
    t_3 = environment.filters['get_qualified_name_for_kind']
    t_4 = environment.filters['is_native_only_kind']
    t_5 = environment.filters['is_union_kind']
    t_6 = environment.filters['join']
    t_7 = environment.filters['replace']
    t_8 = environment.filters['reverse']
    t_9 = environment.filters['upper']
    pass
    yield '// Copyright 2016 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    l_0_header_guard = t_1('%s_SHARED_H_', t_7(context.eval_ctx, t_7(context.eval_ctx, t_7(context.eval_ctx, t_9(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path')), '/', '_'), '.', '_'), '-', '_'))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    def macro(l_1_kind):
        t_10 = []
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        t_10.extend((
            '\ntemplate <>\nstruct MojomTypeTraits<',
            to_string(t_3(l_1_kind)),
            'DataView> {\n  using Data = ',
            to_string(t_3(l_1_kind, internal=True)),
            ';',
        ))
        if t_5(l_1_kind):
            pass
            t_10.append(
                '\n  using DataAsArrayElement = Data;\n  static constexpr MojomTypeCategory category = MojomTypeCategory::kUnion;',
            )
        else:
            pass
            t_10.append(
                '\n  using DataAsArrayElement = Pointer<Data>;\n  static constexpr MojomTypeCategory category = MojomTypeCategory::kStruct;',
            )
        t_10.append(
            '\n};',
        )
        return concat(t_10)
    context.exported_vars.add('mojom_type_traits')
    context.vars['mojom_type_traits'] = l_0_mojom_type_traits = Macro(environment, macro, 'mojom_type_traits', ('kind',), False, False, False, context.eval_ctx.autoescape)
    def macro():
        t_11 = []
        pass
        for l_2_namespace in (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array):
            pass
            t_11.extend((
                '\nnamespace ',
                to_string(l_2_namespace),
                ' {',
            ))
        l_2_namespace = missing
        return concat(t_11)
    context.exported_vars.add('namespace_begin')
    context.vars['namespace_begin'] = l_0_namespace_begin = Macro(environment, macro, 'namespace_begin', (), False, False, False, context.eval_ctx.autoescape)
    def macro():
        t_12 = []
        pass
        for l_2_namespace in t_8((undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)):
            pass
            t_12.extend((
                '\n}  // namespace ',
                to_string(l_2_namespace),
            ))
        l_2_namespace = missing
        return concat(t_12)
    context.exported_vars.add('namespace_end')
    context.vars['namespace_end'] = l_0_namespace_end = Macro(environment, macro, 'namespace_end', (), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n#ifndef '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include <stdint.h>\n\n#include <functional>\n#include <iosfwd>\n#include <type_traits>\n#include <utility>'
    if (not (undefined(name='contains_only_enums') if l_0_contains_only_enums is missing else l_0_contains_only_enums)):
        pass
        yield '\n#include "mojo/public/cpp/bindings/array_data_view.h"\n#include "mojo/public/cpp/bindings/enum_traits.h"\n#include "mojo/public/cpp/bindings/interface_data_view.h"\n#include "mojo/public/cpp/bindings/lib/bindings_internal.h"\n#include "mojo/public/cpp/bindings/lib/serialization.h"\n#include "mojo/public/cpp/bindings/map_data_view.h"\n#include "mojo/public/cpp/bindings/string_data_view.h"'
    yield '\n\n#include "third_party/perfetto/include/perfetto/tracing/traced_value_forward.h"\n\n#include "'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-shared-internal.h"'
    for l_1_import in (undefined(name='imports') if l_0_imports is missing else l_0_imports):
        pass
        yield '\n#include "'
        yield to_string(environment.getattr(l_1_import, 'path'))
        yield '-shared.h"'
    l_1_import = missing
    yield '\n'
    if ((not (undefined(name='disallow_interfaces') if l_0_disallow_interfaces is missing else l_0_disallow_interfaces)) and (undefined(name='uses_interfaces') if l_0_uses_interfaces is missing else l_0_uses_interfaces)):
        pass
        yield '#include "mojo/public/cpp/bindings/lib/interface_serialization.h"'
    yield '\n\n'
    if ((not (undefined(name='disallow_native_types') if l_0_disallow_native_types is missing else l_0_disallow_native_types)) and (undefined(name='uses_native_types') if l_0_uses_native_types is missing else l_0_uses_native_types)):
        pass
        yield '\n#include "mojo/public/cpp/bindings/native_enum.h"\n#include "mojo/public/cpp/bindings/lib/native_struct_serialization.h"'
    if (undefined(name='export_header') if l_0_export_header is missing else l_0_export_header):
        pass
        yield '\n#include "'
        yield to_string((undefined(name='export_header') if l_0_export_header is missing else l_0_export_header))
        yield '"'
    yield '\n\n'
    if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
        pass
        yield '#ifdef KYTHE_IS_RUNNING\n#pragma kythe_inline_metadata "Metadata comment"\n#endif'
    yield '\n\n'
    yield to_string(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin)))
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        if t_4(l_1_struct):
            pass
            yield '\nusing '
            yield to_string(environment.getattr(l_1_struct, 'name'))
            yield 'DataView = mojo::native::NativeStructDataView;'
        else:
            pass
            yield '\nclass '
            yield to_string(environment.getattr(l_1_struct, 'name'))
            yield 'DataView;'
        yield '\n'
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        yield '\nclass '
        yield to_string(environment.getattr(l_1_union, 'name'))
        yield 'DataView;'
    l_1_union = missing
    yield '\n\n'
    yield to_string(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end)))
    yield '\n\nnamespace mojo {\nnamespace internal {'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        if (not t_4(l_1_struct)):
            pass
            yield '\n'
            yield to_string(context.call((undefined(name='mojom_type_traits') if l_0_mojom_type_traits is missing else l_0_mojom_type_traits), l_1_struct))
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        yield '\n'
        yield to_string(context.call((undefined(name='mojom_type_traits') if l_0_mojom_type_traits is missing else l_0_mojom_type_traits), l_1_union))
    l_1_union = missing
    yield '\n\n}  // namespace internal\n}  // namespace mojo\n\n'
    yield to_string(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin)))
    l_0_module_prefix = t_1('%s', t_6(context.eval_ctx, (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), '.'))
    context.vars['module_prefix'] = l_0_module_prefix
    context.exported_vars.add('module_prefix')
    included_template = environment.get_template('enum_macros.tmpl', 'module-shared.h.tmpl').make_module(context.get_all(), True, {'enum_decl': l_0_enum_decl, 'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'module_prefix': l_0_module_prefix, 'mojom_type_traits': l_0_mojom_type_traits, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})
    l_0_enum_decl = getattr(included_template, 'enum_decl', missing)
    if l_0_enum_decl is missing:
        l_0_enum_decl = undefined("the template %r (imported on line 121 in 'module-shared.h.tmpl') does not export the requested name 'enum_decl'" % included_template.__name__, name='enum_decl')
    context.vars['enum_decl'] = l_0_enum_decl
    context.exported_vars.discard('enum_decl')
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        l_1_export_attribute = resolve('export_attribute')
        pass
        if t_4(l_1_enum):
            pass
            yield '\nusing '
            yield to_string(t_2(l_1_enum, flatten_nested_kind=True))
            yield ' = mojo::NativeEnum;'
        else:
            pass
            yield '\n'
            yield to_string(context.call((undefined(name='enum_decl') if l_0_enum_decl is missing else l_0_enum_decl), l_1_enum, (undefined(name='export_attribute') if l_1_export_attribute is missing else l_1_export_attribute)))
    l_1_enum = l_1_export_attribute = missing
    if (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        yield '\n// Interface base classes. They are used for type safety check.'
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        yield '\nclass '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'InterfaceBase {};\n\nusing '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'PtrDataView =\n    mojo::InterfacePtrDataView<'
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'InterfaceBase>;\nusing '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'RequestDataView =\n    mojo::InterfaceRequestDataView<'
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'InterfaceBase>;\nusing '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'AssociatedPtrInfoDataView =\n    mojo::AssociatedInterfacePtrInfoDataView<'
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'InterfaceBase>;\nusing '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'AssociatedRequestDataView =\n    mojo::AssociatedInterfaceRequestDataView<'
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'InterfaceBase>;'
    l_1_interface = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        if (not t_4(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('struct_data_view_declaration.tmpl', 'module-shared.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_decl': l_0_enum_decl, 'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'module_prefix': l_0_module_prefix, 'mojom_type_traits': l_0_mojom_type_traits, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'struct': l_1_struct})):
                yield event
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        yield '\n'
        template = environment.get_template('union_data_view_declaration.tmpl', 'module-shared.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_decl': l_0_enum_decl, 'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'module_prefix': l_0_module_prefix, 'mojom_type_traits': l_0_mojom_type_traits, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'union': l_1_union})):
            yield event
    l_1_union = missing
    yield '\n\n'
    yield to_string(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end)))
    yield '\n\nnamespace std {'
    included_template = environment.get_template('enum_macros.tmpl', 'module-shared.h.tmpl')._get_default_module()
    l_0_enum_hash = getattr(included_template, 'enum_hash', missing)
    if l_0_enum_hash is missing:
        l_0_enum_hash = undefined("the template %r (imported on line 164 in 'module-shared.h.tmpl') does not export the requested name 'enum_hash'" % included_template.__name__, name='enum_hash')
    context.vars['enum_hash'] = l_0_enum_hash
    context.exported_vars.discard('enum_hash')
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        pass
        if (not t_4(l_1_enum)):
            pass
            yield '\n'
            yield to_string(context.call((undefined(name='enum_hash') if l_0_enum_hash is missing else l_0_enum_hash), l_1_enum))
    l_1_enum = missing
    yield '\n\n}  // namespace std\n\nnamespace mojo {'
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        pass
        if (not t_4(l_1_enum)):
            pass
            yield '\n'
            template = environment.get_template('enum_serialization_declaration.tmpl', 'module-shared.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum': l_1_enum, 'enum_decl': l_0_enum_decl, 'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'module_prefix': l_0_module_prefix, 'mojom_type_traits': l_0_mojom_type_traits, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
                yield event
    l_1_enum = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        if (not t_4(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('struct_serialization_declaration.tmpl', 'module-shared.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_decl': l_0_enum_decl, 'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'module_prefix': l_0_module_prefix, 'mojom_type_traits': l_0_mojom_type_traits, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'struct': l_1_struct})):
                yield event
    l_1_struct = missing
    if (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
            pass
            yield '\n'
            template = environment.get_template('union_serialization_declaration.tmpl', 'module-shared.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_decl': l_0_enum_decl, 'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'module_prefix': l_0_module_prefix, 'mojom_type_traits': l_0_mojom_type_traits, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'union': l_1_union})):
                yield event
        l_1_union = missing
    yield '\n\n}  // namespace mojo\n\n'
    yield to_string(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin)))
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        if (not t_4(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('struct_data_view_definition.tmpl', 'module-shared.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_decl': l_0_enum_decl, 'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'module_prefix': l_0_module_prefix, 'mojom_type_traits': l_0_mojom_type_traits, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'struct': l_1_struct})):
                yield event
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        yield '\n'
        template = environment.get_template('union_data_view_definition.tmpl', 'module-shared.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_decl': l_0_enum_decl, 'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'module_prefix': l_0_module_prefix, 'mojom_type_traits': l_0_mojom_type_traits, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'union': l_1_union})):
            yield event
    l_1_union = missing
    yield '\n\n'
    yield to_string(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end)))
    yield '\n\n// Declare TraceFormatTraits for enums, which should be defined in ::perfetto\n// namespace.'
    included_template = environment.get_template('enum_macros.tmpl', 'module-shared.h.tmpl').make_module(context.get_all(), True, {'enum_decl': l_0_enum_decl, 'enum_hash': l_0_enum_hash, 'enum_trace_format_traits_decl': l_0_enum_trace_format_traits_decl, 'header_guard': l_0_header_guard, 'module_prefix': l_0_module_prefix, 'mojom_type_traits': l_0_mojom_type_traits, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})
    l_0_enum_trace_format_traits_decl = getattr(included_template, 'enum_trace_format_traits_decl', missing)
    if l_0_enum_trace_format_traits_decl is missing:
        l_0_enum_trace_format_traits_decl = undefined("the template %r (imported on line 214 in 'module-shared.h.tmpl') does not export the requested name 'enum_trace_format_traits_decl'" % included_template.__name__, name='enum_trace_format_traits_decl')
    context.vars['enum_trace_format_traits_decl'] = l_0_enum_trace_format_traits_decl
    context.exported_vars.discard('enum_trace_format_traits_decl')
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        l_1_export_attribute = resolve('export_attribute')
        pass
        if (not t_4(l_1_enum)):
            pass
            yield '\n'
            yield to_string(context.call((undefined(name='enum_trace_format_traits_decl') if l_0_enum_trace_format_traits_decl is missing else l_0_enum_trace_format_traits_decl), l_1_enum, (undefined(name='export_attribute') if l_1_export_attribute is missing else l_1_export_attribute)))
    l_1_enum = l_1_export_attribute = missing
    yield '\n\n#endif  // '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=36&9=39&11=46&12=48&13=51&23=67&24=70&25=74&29=81&30=84&31=88&35=95&36=97&45=99&57=103&58=105&59=108&63=112&67=116&72=119&73=122&76=125&82=129&85=130&86=132&87=135&89=140&94=144&95=147&98=151&103=153&104=155&105=158&109=160&110=163&116=166&118=167&121=170&122=176&123=179&124=182&126=187&131=189&134=192&135=195&137=197&138=199&139=201&140=203&141=205&142=207&143=209&144=211&149=214&150=216&151=219&156=223&157=226&160=231&164=233&165=239&166=241&167=244&176=247&177=249&178=252&183=256&184=258&185=261&190=265&191=267&192=270&198=275&200=276&201=278&202=281&206=285&207=288&210=293&214=295&215=301&216=304&217=307&221=310'