from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'mojom.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    t_1 = environment.filters['relative_path']
    pass
    yield '// Copyright 2019 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    for l_1_import in environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'imports'):
        l_1_use_es_modules = resolve('use_es_modules')
        pass
        if (undefined(name='use_es_modules') if l_1_use_es_modules is missing else l_1_use_es_modules):
            pass
            yield '\n\nimport * as '
            yield to_string(environment.getattr(l_1_import, 'unique_alias'))
            yield " from '"
            yield to_string(t_1(environment.getattr(l_1_import, 'path')))
            yield "-lite.m.js';\n"
        else:
            pass
            yield '\n/// <reference path="'
            yield to_string(t_1(environment.getattr(l_1_import, 'path')))
            yield '-lite.ts" />\n'
    l_1_import = l_1_use_es_modules = missing
    yield '\n\n'
    template = environment.get_template('module_definition.tmpl', 'mojom.tmpl')
    for event in template.root_render_func(template.new_context(context.get_all(), True, {})):
        yield event

blocks = {}
debug_info = '5=14&6=17&12=20&14=27&18=31'