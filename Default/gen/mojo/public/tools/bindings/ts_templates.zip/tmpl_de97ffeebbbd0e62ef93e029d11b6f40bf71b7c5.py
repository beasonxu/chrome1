from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'module_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_use_es_modules = resolve('use_es_modules')
    l_0_module = resolve('module')
    l_0_enums = resolve('enums')
    l_0_structs = resolve('structs')
    t_1 = environment.filters['constant_value']
    t_2 = environment.filters['typescript_type_with_nullability']
    t_3 = environment.tests['none']
    pass
    if (not (undefined(name='use_es_modules') if l_0_use_es_modules is missing else l_0_use_es_modules)):
        pass
        yield 'namespace '
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield ' {\n'
    for l_1_constant in environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'):
        pass
        yield '\nexport const '
        yield to_string(environment.getattr(l_1_constant, 'name'))
        yield ': '
        yield to_string(t_2(environment.getattr(l_1_constant, 'kind'), (undefined(name='use_es_modules') if l_0_use_es_modules is missing else l_0_use_es_modules)))
        yield ' =\n  '
        yield to_string(t_1(l_1_constant))
        yield ';'
    l_1_constant = missing
    for l_1_enum in (undefined(name='enums') if l_0_enums is missing else l_0_enums):
        pass
        yield '\nexport enum '
        yield to_string(environment.getattr(l_1_enum, 'name'))
        yield ' {'
        for l_2_field in environment.getattr(l_1_enum, 'fields'):
            pass
            yield '\n  '
            yield to_string(environment.getattr(l_2_field, 'name'))
            yield ' = '
            yield to_string(environment.getattr(l_2_field, 'numeric_value'))
            yield ','
        l_2_field = missing
        if (not t_3(environment.getattr(l_1_enum, 'min_value'))):
            pass
            yield '\n  MIN_VALUE = '
            yield to_string(environment.getattr(l_1_enum, 'min_value'))
            yield ','
        if (not t_3(environment.getattr(l_1_enum, 'max_value'))):
            pass
            yield '\n  MAX_VALUE = '
            yield to_string(environment.getattr(l_1_enum, 'max_value'))
            yield ','
        yield '\n}\n'
    l_1_enum = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        yield '\nexport interface '
        yield to_string(environment.getattr(l_1_struct, 'name'))
        yield ' {'
        for l_2_packed_field in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields'):
            pass
            yield '\n    '
            yield to_string(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'))
            yield ': '
            yield to_string(t_2(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'kind'), (undefined(name='use_es_modules') if l_0_use_es_modules is missing else l_0_use_es_modules)))
            yield ';'
        l_2_packed_field = missing
        yield '\n}\n'
    l_1_struct = missing
    if (not (undefined(name='use_es_modules') if l_0_use_es_modules is missing else l_0_use_es_modules)):
        pass
        yield '\n} // namespace '
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '\n'

blocks = {}
debug_info = '1=18&2=21&5=23&6=26&7=30&11=33&12=36&13=38&14=41&16=46&17=49&19=51&20=54&26=58&27=61&28=63&29=66&34=73&35=76'