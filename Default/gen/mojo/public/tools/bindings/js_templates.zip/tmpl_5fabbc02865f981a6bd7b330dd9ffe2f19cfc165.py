from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'lite/interface_definition_for_module.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_mojom_namespace = resolve('mojom_namespace')
    l_0_generateMethodAnnotation = l_0_enum_def = missing
    t_1 = environment.filters['length']
    t_2 = environment.filters['sanitize_identifier']
    t_3 = environment.filters['type_in_js_module_with_nullability']
    pass
    def macro(l_1_method):
        t_4 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_4.append(
            '\n  /**',
        )
        for l_2_param in environment.getattr(l_1_method, 'parameters'):
            pass
            t_4.extend((
                '\n   * @param { ',
                to_string(t_3(environment.getattr(l_2_param, 'kind'))),
                ' } ',
                to_string(t_2(environment.getattr(l_2_param, 'name'))),
            ))
        l_2_param = missing
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            if (t_1(environment.getattr(l_1_method, 'response_parameters')) == 0):
                pass
                t_4.append(
                    '\n   * @return {!Promise}',
                )
            else:
                pass
                t_4.append(
                    '\n   * @return {!Promise<{',
                )
                for l_2_response_parameter in environment.getattr(l_1_method, 'response_parameters'):
                    pass
                    t_4.extend((
                        '\n        ',
                        to_string(environment.getattr(l_2_response_parameter, 'name')),
                        ': ',
                        to_string(t_3(environment.getattr(l_2_response_parameter, 'kind'))),
                        ',',
                    ))
                l_2_response_parameter = missing
                t_4.append(
                    '\n   *  }>}',
                )
        t_4.append(
            '\n   */\n',
        )
        return concat(t_4)
    context.exported_vars.add('generateMethodAnnotation')
    context.vars['generateMethodAnnotation'] = l_0_generateMethodAnnotation = Macro(environment, macro, 'generateMethodAnnotation', ('method',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n/**\n * @implements {mojo.internal.interfaceSupport.PendingReceiver}\n */\nexport class '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield "PendingReceiver {\n  /**\n   * @param {!MojoHandle|!mojo.internal.interfaceSupport.Endpoint} handle\n   */\n  constructor(handle) {\n    /** @public {!mojo.internal.interfaceSupport.Endpoint} */\n    this.handle = mojo.internal.interfaceSupport.getEndpointForReceiver(handle);\n  }\n\n  /** @param {string=} scope */\n  bindInBrowser(scope = 'context') {\n    mojo.internal.interfaceSupport.bind(\n        this.handle, '"
    yield to_string((undefined(name='mojom_namespace') if l_0_mojom_namespace is missing else l_0_mojom_namespace))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield "', scope);\n  }\n}\n\n/** @interface */\nexport class "
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Interface {'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        pass
        yield '\n  '
        yield to_string(context.call((undefined(name='generateMethodAnnotation') if l_0_generateMethodAnnotation is missing else l_0_generateMethodAnnotation), l_1_method))
        yield '\n  '
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield '('
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            pass
            yield to_string(t_2(environment.getattr(l_2_param, 'name')))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ', '
        l_2_loop = l_2_param = missing
        yield ') {}'
    l_1_loop = l_1_method = missing
    yield '\n}\n\n/**\n * @implements { '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Interface }\n */\nexport class '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote {\n  /** @param {MojoHandle|mojo.internal.interfaceSupport.Endpoint=} handle */\n  constructor(handle = undefined) {\n    /**\n     * @private {!mojo.internal.interfaceSupport.InterfaceRemoteBase<!'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>}\n     */\n    this.proxy =\n        new mojo.internal.interfaceSupport.InterfaceRemoteBase(\n          '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver,\n          handle);\n\n    /**\n     * @public {!mojo.internal.interfaceSupport.InterfaceRemoteBaseWrapper<!'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>}\n     */\n    this.$ = new mojo.internal.interfaceSupport.InterfaceRemoteBaseWrapper(this.proxy);\n\n    /** @public {!mojo.internal.interfaceSupport.ConnectionErrorEventRouter} */\n    this.onConnectionError = this.proxy.getConnectionErrorEventRouter();\n  }'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        l_1_interface_message_id = missing
        pass
        l_1_interface_message_id = unicode_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        yield '\n\n  '
        yield to_string(context.call((undefined(name='generateMethodAnnotation') if l_0_generateMethodAnnotation is missing else l_0_generateMethodAnnotation), l_1_method))
        yield '\n  '
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield '('
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            pass
            yield '\n      '
            yield to_string(environment.getattr(l_2_param, 'name'))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_param = missing
        yield ') {'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n    return this.proxy.sendMessage('
        else:
            pass
            yield '\n    this.proxy.sendMessage('
        yield '\n        '
        yield to_string(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield to_string((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n        '
            yield to_string((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,'
        else:
            pass
            yield '\n        null,'
        yield '\n        ['
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            pass
            yield '\n          '
            yield to_string(environment.getattr(l_2_param, 'name'))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_param = missing
        yield '\n        ]);\n  }'
    l_1_loop = l_1_method = l_1_interface_message_id = missing
    yield '\n}\n\n/**\n * An object which receives request messages for the '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '\n * mojom interface. Must be constructed over an object which implements that\n * interface.\n */\nexport class '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Receiver {\n  /**\n   * @param {!'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Interface } impl\n   */\n  constructor(impl) {\n    /** @private {!mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal<!'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote>} */\n    this.helper_internal_ = new mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal(\n        '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote);\n\n    /**\n     * @public {!mojo.internal.interfaceSupport.InterfaceReceiverHelper<!'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote>}\n     */\n    this.$ = new mojo.internal.interfaceSupport.InterfaceReceiverHelper(this.helper_internal_);\n\n'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_interface_message_id = missing
        pass
        l_1_interface_message_id = unicode_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        yield '\n    this.helper_internal_.registerHandler(\n        '
        yield to_string(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield to_string((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n        '
            yield to_string((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,'
        else:
            pass
            yield '\n        null,'
        yield '\n        impl.'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield '.bind(impl));'
    l_1_method = l_1_interface_message_id = missing
    yield '\n    /** @public {!mojo.internal.interfaceSupport.ConnectionErrorEventRouter} */\n    this.onConnectionError = this.helper_internal_.getConnectionErrorEventRouter();\n  }\n}\n\nexport class '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield ' {\n  /**\n   * @return {!string}\n   */\n  static get $interfaceName() {\n    return "'
    yield to_string((undefined(name='mojom_namespace') if l_0_mojom_namespace is missing else l_0_mojom_namespace))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '";\n  }\n\n  /**\n   * Returns a remote for this interface which sends messages to the browser.\n   * The browser must have an interface request binder registered for this\n   * interface and accessible to the calling document\'s frame.\n   *\n   * @return {!'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote}\n   */\n  static getRemote() {\n    let remote = new '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote;\n    remote.$.bindNewPipeAndPassReceiver().bindInBrowser();\n    return remote;\n  }\n}\n'
    included_template = environment.get_template('lite/enum_definition_for_module.tmpl', 'lite/interface_definition_for_module.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def, 'generateMethodAnnotation': l_0_generateMethodAnnotation})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined("the template %r (imported on line 164 in 'lite/interface_definition_for_module.tmpl') does not export the requested name 'enum_def'" % included_template.__name__, name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    for l_1_enum in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'enums'):
        pass
        yield '\n'
        yield to_string(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), l_1_enum))
    l_1_enum = missing
    yield '\n\n/**\n * An object which receives request messages for the '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '\n * mojom interface and dispatches them as callbacks. One callback receiver exists\n * on this object for each message defined in the mojom interface, and each\n * receiver can have any number of listeners added to it.\n */\nexport class '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'CallbackRouter {\n  constructor() {\n    this.helper_internal_ = new mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal(\n      '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote);\n\n    /**\n     * @public {!mojo.internal.interfaceSupport.InterfaceReceiverHelper<!'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote>}\n     */\n    this.$ = new mojo.internal.interfaceSupport.InterfaceReceiverHelper(this.helper_internal_);\n\n    this.router_ = new mojo.internal.interfaceSupport.CallbackRouter;\n'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_interface_message_id = missing
        pass
        l_1_interface_message_id = unicode_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        yield '\n    /**\n     * @public {!mojo.internal.interfaceSupport.InterfaceCallbackReceiver}\n     */\n    this.'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield ' =\n        new mojo.internal.interfaceSupport.InterfaceCallbackReceiver(\n            this.router_);\n\n    this.helper_internal_.registerHandler(\n        '
        yield to_string(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield to_string((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n        '
            yield to_string((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,\n        this.'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '.createReceiverHandler(true /* expectsResponse */));'
        else:
            pass
            yield '\n        null,\n        this.'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '.createReceiverHandler(false /* expectsResponse */));'
    l_1_method = l_1_interface_message_id = missing
    yield '\n    /** @public {!mojo.internal.interfaceSupport.ConnectionErrorEventRouter} */\n    this.onConnectionError = this.helper_internal_.getConnectionErrorEventRouter();\n  }\n\n  /**\n   * @param {number} id An ID returned by a prior call to addListener.\n   * @return {boolean} True iff the identified listener was found and removed.\n   */\n  removeListener(id) {\n    return this.router_.removeListener(id);\n  }\n}'

blocks = {}
debug_info = '1=17&3=25&4=29&6=34&7=36&11=46&12=50&23=66&35=68&40=72&41=75&42=78&43=80&44=83&45=85&52=93&54=95&58=97&62=99&66=101&74=104&75=107&78=109&79=111&80=114&81=117&83=123&88=130&89=132&90=134&91=137&96=144&97=147&105=155&109=157&111=159&114=161&116=163&119=165&123=167&124=170&127=172&128=174&129=176&130=179&134=185&141=189&146=191&154=195&157=197&164=199&165=205&166=208&170=211&175=213&178=215&181=217&186=219&187=222&192=224&197=226&198=228&199=230&200=233&201=235&204=240'