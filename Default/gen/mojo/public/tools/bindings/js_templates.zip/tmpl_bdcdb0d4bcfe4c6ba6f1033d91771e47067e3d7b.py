from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'lite/mojom.html.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_html_imports = resolve('html_imports')
    l_0_mojom_filename = resolve('mojom_filename')
    pass
    yield '<!--\nCopyright 2019 The Chromium Authors. All rights reserved.\nUse of this source code is governed by a BSD-style license that can be\nfound in the LICENSE file.\n-->'
    for l_1_html_import in (undefined(name='html_imports') if l_0_html_imports is missing else l_0_html_imports):
        pass
        yield '\n<link rel="import" href="'
        yield to_string(l_1_html_import)
        yield '.html">\n'
    l_1_html_import = missing
    yield '\n<script src="'
    yield to_string((undefined(name='mojom_filename') if l_0_mojom_filename is missing else l_0_mojom_filename))
    yield '-lite.js"></script>'

blocks = {}
debug_info = '6=14&7=17&9=21'