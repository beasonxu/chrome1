from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'struct_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_generate_fuzzing = resolve('generate_fuzzing')
    l_0_generate_or_mutate = resolve('generate_or_mutate')
    l_0_get_handle_deps = resolve('get_handle_deps')
    l_0_set_handles = resolve('set_handles')
    l_0_enum_def = l_0_validate_struct_field = l_0_last_checked_version = missing
    t_1 = environment.filters['contains_handles_or_interfaces']
    t_2 = environment.filters['decode_snippet']
    t_3 = environment.filters['default_value']
    t_4 = environment.filters['encode_snippet']
    t_5 = environment.filters['expression_to_text']
    t_6 = environment.filters['field_offset']
    t_7 = environment.filters['format']
    t_8 = environment.filters['indent']
    t_9 = environment.filters['is_any_handle_or_interface_kind']
    t_10 = environment.filters['is_bool_kind']
    t_11 = environment.filters['is_enum_kind']
    t_12 = environment.filters['is_object_kind']
    t_13 = environment.filters['length']
    t_14 = environment.filters['payload_size']
    pass
    yield '\n  function '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '(values) {\n    this.initDefaults_();\n    this.initFields_(values);\n  }'
    included_template = environment.get_template('enum_definition.tmpl', 'struct_definition.tmpl')._get_default_module()
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined("the template %r (imported on line 8 in 'struct_definition.tmpl') does not export the requested name 'enum_def'" % included_template.__name__, name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    yield '\n'
    for l_1_enum in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'enums'):
        pass
        yield '\n  '
        yield to_string(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), t_7('%s.%s', environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'), environment.getattr(l_1_enum, 'name')), l_1_enum))
    l_1_enum = missing
    yield '\n'
    for l_1_constant in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'constants'):
        pass
        yield '\n  '
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '.'
        yield to_string(environment.getattr(l_1_constant, 'name'))
        yield ' = '
        yield to_string(t_5(environment.getattr(l_1_constant, 'value')))
        yield ';'
    l_1_constant = missing
    yield '\n  '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '.prototype.initDefaults_ = function() {'
    for l_1_packed_field in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields'):
        pass
        yield '\n    this.'
        yield to_string(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name'))
        yield ' = '
        yield to_string(t_3(environment.getattr(l_1_packed_field, 'field')))
        yield ';'
    l_1_packed_field = missing
    yield '\n  };\n  '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '.prototype.initFields_ = function(fields) {\n    for(var field in fields) {\n        if (this.hasOwnProperty(field))\n          this[field] = fields[field];\n    }\n  };'
    if (undefined(name='generate_fuzzing') if l_0_generate_fuzzing is missing else l_0_generate_fuzzing):
        pass
        included_template = environment.get_template('fuzzing.tmpl', 'struct_definition.tmpl')._get_default_module()
        l_0_generate_or_mutate = getattr(included_template, 'generate_or_mutate', missing)
        if l_0_generate_or_mutate is missing:
            l_0_generate_or_mutate = undefined("the template %r (imported on line 35 in 'struct_definition.tmpl') does not export the requested name 'generate_or_mutate'" % included_template.__name__, name='generate_or_mutate')
        context.vars['generate_or_mutate'] = l_0_generate_or_mutate
        context.exported_vars.discard('generate_or_mutate')
        yield '\n  '
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '.generate = function(generator_) {\n    var generated = new '
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield ';'
        for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
            pass
            yield '\n    generated.'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ' = '
            yield to_string(t_8(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), 'generator_', 'generate', environment.getattr(l_1_field, 'kind')), 4))
            yield ';'
        l_1_field = missing
        yield '\n    return generated;\n  };\n\n  '
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '.prototype.mutate = function(mutator_) {'
        for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
            pass
            yield '\n    if (mutator_.chooseMutateField()) {\n      this.'
            yield to_string(environment.getattr(l_1_field, 'name'))
            yield ' = '
            yield to_string(t_8(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), 'mutator_', 'mutate', environment.getattr(l_1_field, 'kind'), unicode_join(('this.', environment.getattr(l_1_field, 'name'), ))), 6))
            yield ';\n    }'
        l_1_field = missing
        yield '\n    return this;\n  };'
        included_template = environment.get_template('fuzzing.tmpl', 'struct_definition.tmpl')._get_default_module()
        l_0_get_handle_deps = getattr(included_template, 'get_handle_deps', missing)
        if l_0_get_handle_deps is missing:
            l_0_get_handle_deps = undefined("the template %r (imported on line 53 in 'struct_definition.tmpl') does not export the requested name 'get_handle_deps'" % included_template.__name__, name='get_handle_deps')
        context.vars['get_handle_deps'] = l_0_get_handle_deps
        context.exported_vars.discard('get_handle_deps')
        yield '\n  '
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '.prototype.getHandleDeps = function() {\n    var handles = [];'
        for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
            pass
            if t_1(environment.getattr(l_1_field, 'kind')):
                pass
                yield '\n    if (this.'
                yield to_string(environment.getattr(l_1_field, 'name'))
                yield ' !== null) {\n      Array.prototype.push.apply(handles, '
                yield to_string(t_8(context.call((undefined(name='get_handle_deps') if l_0_get_handle_deps is missing else l_0_get_handle_deps), environment.getattr(l_1_field, 'kind'), unicode_join(('this.', environment.getattr(l_1_field, 'name'), ))), 6))
                yield ');\n    }'
        l_1_field = missing
        yield '\n    return handles;\n  };\n\n  '
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '.prototype.setHandles = function() {\n    this.setHandlesInternal_(arguments, 0);\n  };'
        included_template = environment.get_template('fuzzing.tmpl', 'struct_definition.tmpl')._get_default_module()
        l_0_set_handles = getattr(included_template, 'set_handles', missing)
        if l_0_set_handles is missing:
            l_0_set_handles = undefined("the template %r (imported on line 70 in 'struct_definition.tmpl') does not export the requested name 'set_handles'" % included_template.__name__, name='set_handles')
        context.vars['set_handles'] = l_0_set_handles
        context.exported_vars.discard('set_handles')
        yield '\n  '
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '.prototype.setHandlesInternal_ = function(handles, idx) {'
        for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
            pass
            if t_1(environment.getattr(l_1_field, 'kind')):
                pass
                yield '\n    '
                yield to_string(t_8(context.call((undefined(name='set_handles') if l_0_set_handles is missing else l_0_set_handles), environment.getattr(l_1_field, 'kind'), unicode_join(('this.', environment.getattr(l_1_field, 'name'), ))), 4))
                yield ';'
        l_1_field = missing
        yield '\n    return idx;\n  };'
    yield '\n\n  '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '.validate = function(messageValidator, offset) {\n    var err;\n    err = messageValidator.validateStructHeader(offset, codec.kStructHeaderSize);\n    if (err !== validator.validationError.NONE)\n        return err;\n\n    var kVersionSizes = ['
    l_1_loop = missing
    for l_1_version, l_1_loop in LoopContext(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'), undefined):
        pass
        yield '\n      {version: '
        yield to_string(environment.getattr(l_1_version, 'version'))
        yield ', numBytes: '
        yield to_string(environment.getattr(l_1_version, 'num_bytes'))
        yield '}'
        if (not environment.getattr(l_1_loop, 'last')):
            pass
            yield ','
    l_1_loop = l_1_version = missing
    yield '\n    ];\n    err = messageValidator.validateStructVersion(offset, kVersionSizes);\n    if (err !== validator.validationError.NONE)\n        return err;'
    included_template = environment.get_template('validation_macros.tmpl', 'struct_definition.tmpl')._get_default_module()
    l_0_validate_struct_field = getattr(included_template, 'validate_struct_field', missing)
    if l_0_validate_struct_field is missing:
        l_0_validate_struct_field = undefined("the template %r (imported on line 103 in 'struct_definition.tmpl') does not export the requested name 'validate_struct_field'" % included_template.__name__, name='validate_struct_field')
    context.vars['validate_struct_field'] = l_0_validate_struct_field
    context.exported_vars.discard('validate_struct_field')
    l_0_last_checked_version = 0
    context.vars['last_checked_version'] = l_0_last_checked_version
    context.exported_vars.add('last_checked_version')
    for l_1_packed_field in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields_in_ordinal_order'):
        l_1_last_checked_version = l_0_last_checked_version
        l_1_offset = l_1_field = l_1_name = missing
        pass
        l_1_offset = t_6(l_1_packed_field)
        l_1_field = environment.getattr(l_1_packed_field, 'field')
        l_1_name = unicode_join((environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'), '.', environment.getattr((undefined(name='field') if l_1_field is missing else l_1_field), 'name'), ))
        yield '\n'
        if ((t_12(environment.getattr((undefined(name='field') if l_1_field is missing else l_1_field), 'kind')) or t_9(environment.getattr((undefined(name='field') if l_1_field is missing else l_1_field), 'kind'))) or t_11(environment.getattr((undefined(name='field') if l_1_field is missing else l_1_field), 'kind'))):
            pass
            yield '\n'
            if (environment.getattr(l_1_packed_field, 'min_version') > (undefined(name='last_checked_version') if l_1_last_checked_version is missing else l_1_last_checked_version)):
                pass
                yield '\n'
                l_1_last_checked_version = environment.getattr(l_1_packed_field, 'min_version')
                yield '\n    // version check '
                yield to_string((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '\n    if (!messageValidator.isFieldInStructVersion(offset, '
                yield to_string(environment.getattr(l_1_packed_field, 'min_version'))
                yield '))\n      return validator.validationError.NONE;'
            yield to_string(t_8(context.call((undefined(name='validate_struct_field') if l_0_validate_struct_field is missing else l_0_validate_struct_field), (undefined(name='field') if l_1_field is missing else l_1_field), (undefined(name='offset') if l_1_offset is missing else l_1_offset), (undefined(name='name') if l_1_name is missing else l_1_name)), 4))
    l_1_packed_field = l_1_offset = l_1_field = l_1_name = l_1_last_checked_version = missing
    yield '\n\n    return validator.validationError.NONE;\n  };\n\n  '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '.encodedSize = codec.kStructHeaderSize + '
    yield to_string(t_14(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed')))
    yield ';\n\n  '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '.decode = function(decoder) {\n    var packed;\n    var val = new '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '();\n    var numberOfBytes = decoder.readUint32();\n    var version = decoder.readUint32();'
    for l_1_byte in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'bytes'):
        pass
        if ((t_13(environment.getattr(l_1_byte, 'packed_fields')) >= 1) and t_10(environment.getattr(environment.getattr(environment.getitem(environment.getattr(l_1_byte, 'packed_fields'), 0), 'field'), 'kind'))):
            pass
            yield '\n    packed = decoder.readUint8();'
            for l_2_packed_field in environment.getattr(l_1_byte, 'packed_fields'):
                pass
                yield '\n    val.'
                yield to_string(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'))
                yield ' = (packed >> '
                yield to_string(environment.getattr(l_2_packed_field, 'bit'))
                yield ') & 1 ? true : false;'
            l_2_packed_field = missing
        else:
            pass
            for l_2_packed_field in environment.getattr(l_1_byte, 'packed_fields'):
                pass
                if (environment.getattr(l_2_packed_field, 'min_version') > 0):
                    pass
                    yield '\n    if (version >= '
                    yield to_string(environment.getattr(l_2_packed_field, 'min_version'))
                    yield ') {\n      val.'
                    yield to_string(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'))
                    yield ' =\n          decoder.'
                    yield to_string(t_2(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'kind')))
                    yield ';\n    } else {\n      val.'
                    yield to_string(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'))
                    yield ' = null;\n    }'
                else:
                    pass
                    yield '\n    val.'
                    yield to_string(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'))
                    yield ' =\n        decoder.'
                    yield to_string(t_2(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'kind')))
                    yield ';'
            l_2_packed_field = missing
        if environment.getattr(l_1_byte, 'is_padding'):
            pass
            yield '\n    decoder.skip(1);'
    l_1_byte = missing
    yield '\n    return val;\n  };\n\n  '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '.encode = function(encoder, val) {\n    var packed;\n    encoder.writeUint32('
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '.encodedSize);\n    encoder.writeUint32('
    yield to_string(environment.getattr(environment.getitem(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'), -1), 'version'))
    yield ');'
    for l_1_byte in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'bytes'):
        pass
        if ((t_13(environment.getattr(l_1_byte, 'packed_fields')) >= 1) and t_10(environment.getattr(environment.getattr(environment.getitem(environment.getattr(l_1_byte, 'packed_fields'), 0), 'field'), 'kind'))):
            pass
            yield '\n    packed = 0;'
            for l_2_packed_field in environment.getattr(l_1_byte, 'packed_fields'):
                pass
                yield '\n    packed |= (val.'
                yield to_string(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'))
                yield ' & 1) << '
                yield to_string(environment.getattr(l_2_packed_field, 'bit'))
            l_2_packed_field = missing
            yield '\n    encoder.writeUint8(packed);'
        else:
            pass
            for l_2_packed_field in environment.getattr(l_1_byte, 'packed_fields'):
                pass
                yield '\n    encoder.'
                yield to_string(t_4(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'kind')))
                yield 'val.'
                yield to_string(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'))
                yield ');'
            l_2_packed_field = missing
        if environment.getattr(l_1_byte, 'is_padding'):
            pass
            yield '\n    encoder.skip(1);'
    l_1_byte = missing
    yield '\n  };'

blocks = {}
debug_info = '2=32&8=34&9=41&10=44&14=47&15=50&19=58&20=60&21=63&26=69&34=71&35=73&36=80&37=82&38=84&39=87&44=93&45=95&47=98&53=104&54=111&56=113&57=115&58=118&59=120&66=124&70=126&71=133&72=135&73=137&74=140&83=145&90=148&91=151&103=160&104=166&105=169&106=173&107=174&108=175&109=177&112=180&113=183&114=185&115=187&118=189&127=192&129=196&131=198&134=200&135=202&138=205&139=208&142=215&143=217&144=220&145=222&146=224&148=226&151=231&152=233&156=236&163=241&165=243&166=245&168=247&169=249&172=252&173=255&177=262&178=265&181=270'