from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'enum_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_enum_def = missing
    t_1 = environment.filters['groupby']
    t_2 = environment.tests['none']
    pass
    def macro(l_1_enum_name, l_1_enum):
        t_3 = []
        l_1_prev_enum = missing
        if l_1_enum_name is missing:
            l_1_enum_name = undefined("parameter 'enum_name' was not provided", name='enum_name')
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        t_3.extend((
            to_string(l_1_enum_name),
            ' = {};',
        ))
        l_1_prev_enum = 0
        for l_2_field in environment.getattr(l_1_enum, 'fields'):
            pass
            t_3.extend((
                '\n  ',
                to_string(l_1_enum_name),
                '.',
                to_string(environment.getattr(l_2_field, 'name')),
                ' = ',
                to_string(environment.getattr(l_2_field, 'numeric_value')),
                ';',
            ))
        l_2_field = missing
        if (not t_2(environment.getattr(l_1_enum, 'min_value'))):
            pass
            t_3.extend((
                '\n  ',
                to_string(l_1_enum_name),
                '.MIN_VALUE = ',
                to_string(environment.getattr(l_1_enum, 'min_value')),
                ';',
            ))
        if (not t_2(environment.getattr(l_1_enum, 'max_value'))):
            pass
            t_3.extend((
                '\n  ',
                to_string(l_1_enum_name),
                '.MAX_VALUE = ',
                to_string(environment.getattr(l_1_enum, 'max_value')),
                ';',
            ))
        if environment.getattr(l_1_enum, 'default_field'):
            pass
            t_3.extend((
                '\n  ',
                to_string(l_1_enum_name),
                '.DEFAULT_VALUE = ',
                to_string(environment.getattr(environment.getattr(l_1_enum, 'default_field'), 'numeric_value')),
                ';',
            ))
        t_3.extend((
            '\n\n  ',
            to_string(l_1_enum_name),
            '.isKnownEnumValue = function(value) {',
        ))
        if environment.getattr(l_1_enum, 'fields'):
            pass
            t_3.append(
                '\n    switch (value) {',
            )
            for l_2_enum_field in t_1(environment, environment.getattr(l_1_enum, 'fields'), 'numeric_value'):
                pass
                t_3.extend((
                    '\n    case ',
                    to_string(environment.getitem(l_2_enum_field, 0)),
                    ':',
                ))
            l_2_enum_field = missing
            t_3.append(
                '\n      return true;\n    }',
            )
        t_3.extend((
            '\n    return false;\n  };\n\n  ',
            to_string(l_1_enum_name),
            '.toKnownEnumValue = function(value) {',
        ))
        if (environment.getattr(l_1_enum, 'extensible') and environment.getattr(l_1_enum, 'default_field')):
            pass
            t_3.append(
                '\n    if (this.isKnownEnumValue(value))\n      return value;\n    return this.DEFAULT_VALUE;',
            )
        else:
            pass
            t_3.append(
                '\n    return value;',
            )
        t_3.extend((
            '\n  };\n\n  ',
            to_string(l_1_enum_name),
            '.validate = function(enumValue) {\n    const isExtensible = ',
        ))
        if environment.getattr(l_1_enum, 'extensible'):
            pass
            t_3.append(
                'true',
            )
        else:
            pass
            t_3.append(
                'false',
            )
        t_3.append(
            ';\n    if (isExtensible || this.isKnownEnumValue(enumValue))\n      return validator.validationError.NONE;\n\n    return validator.validationError.UNKNOWN_ENUM_VALUE;\n  };',
        )
        return concat(t_3)
    context.exported_vars.add('enum_def')
    context.vars['enum_def'] = l_0_enum_def = Macro(environment, macro, 'enum_def', ('enum_name', 'enum'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=14&2=23&3=26&4=27&5=31&7=39&8=43&10=48&11=52&13=57&14=61&17=68&18=71&20=76&21=80&29=89&30=92&39=104&40=107'