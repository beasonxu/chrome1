from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'lite/union_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_generate_closure_exports = resolve('generate_closure_exports')
    l_0_module = resolve('module')
    l_0_union = resolve('union')
    t_1 = environment.filters['lite_closure_type_with_nullability']
    t_2 = environment.filters['lite_js_type']
    pass
    if (undefined(name='generate_closure_exports') if l_0_generate_closure_exports is missing else l_0_generate_closure_exports):
        pass
        yield "goog.provide('"
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield "');\n"
    yield '\n\nmojo.internal.Union(\n    '
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield "Spec.$, '"
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield "',\n    {"
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        pass
        yield "\n      '"
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield "': {\n        'ordinal': "
        yield to_string(environment.getattr(l_1_field, 'ordinal'))
        yield ",\n        'type': "
        yield to_string(t_2(environment.getattr(l_1_field, 'kind')))
        yield ','
        if environment.getattr(environment.getattr(l_1_field, 'kind'), 'is_nullable'):
            pass
            yield "\n        'nullable': true,"
        yield '\n      },'
    l_1_field = missing
    yield '\n    });\n\n/**\n * @typedef { {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        pass
        yield '\n *   '
        yield to_string(environment.getattr(l_1_field, 'name'))
        yield ': ('
        yield to_string(t_1(environment.getattr(l_1_field, 'kind')))
        yield '|undefined),'
    l_1_field = missing
    yield '\n * } }\n */\n'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield ';'

blocks = {}
debug_info = '1=16&2=19&6=24&8=30&9=33&10=35&11=37&12=39&21=45&22=48&26=54'