from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'lite/enum_definition_for_module.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_enum_def = missing
    t_1 = environment.filters['type_in_js_module']
    t_2 = environment.tests['none']
    pass
    def macro(l_1_enum):
        t_3 = []
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        t_3.extend((
            '/**\n * @const { {$: !mojo.internal.MojomType} }\n */\nexport const ',
            to_string(t_1(l_1_enum)),
            'Spec = { $: mojo.internal.Enum() };\n\n/**\n * @enum {number}\n */\nexport const ',
            to_string(t_1(l_1_enum)),
            ' = {\n  ',
        ))
        for l_2_field in environment.getattr(l_1_enum, 'fields'):
            pass
            t_3.extend((
                '\n  ',
                to_string(environment.getattr(l_2_field, 'name')),
                ': ',
                to_string(environment.getattr(l_2_field, 'numeric_value')),
                ',',
            ))
        l_2_field = missing
        if (not t_2(environment.getattr(l_1_enum, 'min_value'))):
            pass
            t_3.extend((
                '\n  MIN_VALUE: ',
                to_string(environment.getattr(l_1_enum, 'min_value')),
                ',',
            ))
        if (not t_2(environment.getattr(l_1_enum, 'max_value'))):
            pass
            t_3.extend((
                '\n  MAX_VALUE: ',
                to_string(environment.getattr(l_1_enum, 'max_value')),
                ',',
            ))
        t_3.append(
            '\n};',
        )
        return concat(t_3)
    context.exported_vars.add('enum_def')
    context.vars['enum_def'] = l_0_enum_def = Macro(environment, macro, 'enum_def', ('enum',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=14&5=21&10=23&12=26&13=30&15=36&16=40&18=43&19=47'