from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'validation_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0__check_err = l_0__validate_field = l_0_validate_struct_field = l_0_validate_union_field = missing
    t_1 = environment.filters['is_any_handle_kind']
    t_2 = environment.filters['is_array_kind']
    t_3 = environment.filters['is_associated_interface_kind']
    t_4 = environment.filters['is_associated_interface_request_kind']
    t_5 = environment.filters['is_enum_kind']
    t_6 = environment.filters['is_interface_kind']
    t_7 = environment.filters['is_interface_request_kind']
    t_8 = environment.filters['is_map_kind']
    t_9 = environment.filters['is_pending_associated_receiver_kind']
    t_10 = environment.filters['is_pending_associated_remote_kind']
    t_11 = environment.filters['is_pending_receiver_kind']
    t_12 = environment.filters['is_pending_remote_kind']
    t_13 = environment.filters['is_string_kind']
    t_14 = environment.filters['is_struct_kind']
    t_15 = environment.filters['is_union_kind']
    t_16 = environment.filters['validate_array_params']
    t_17 = environment.filters['validate_enum_params']
    t_18 = environment.filters['validate_map_params']
    t_19 = environment.filters['validate_nullable_params']
    t_20 = environment.filters['validate_struct_params']
    t_21 = environment.filters['validate_union_params']
    pass
    def macro():
        t_22 = []
        pass
        t_22.append(
            'if (err !== validator.validationError.NONE)\n    return err;',
        )
        return concat(t_22)
    context.vars['_check_err'] = l_0__check_err = Macro(environment, macro, '_check_err', (), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_field, l_1_offset, l_1_name):
        t_23 = []
        if l_1_field is missing:
            l_1_field = undefined("parameter 'field' was not provided", name='field')
        if l_1_offset is missing:
            l_1_offset = undefined("parameter 'offset' was not provided", name='offset')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_13(environment.getattr(l_1_field, 'kind')):
            pass
            t_23.extend((
                '\n// validate ',
                to_string(l_1_name),
                '\nerr = messageValidator.validateStringPointer(',
                to_string(l_1_offset),
                ', ',
                to_string(t_19(l_1_field)),
                ')\n',
                to_string(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif t_2(environment.getattr(l_1_field, 'kind')):
            pass
            t_23.extend((
                '\n// validate ',
                to_string(l_1_name),
                '\nerr = messageValidator.validateArrayPointer(',
                to_string(l_1_offset),
                ', ',
                to_string(t_16(l_1_field)),
                ');\n',
                to_string(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif t_14(environment.getattr(l_1_field, 'kind')):
            pass
            t_23.extend((
                '\n// validate ',
                to_string(l_1_name),
                '\nerr = messageValidator.validateStructPointer(',
                to_string(l_1_offset),
                ', ',
                to_string(t_20(l_1_field)),
                ');\n',
                to_string(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif t_8(environment.getattr(l_1_field, 'kind')):
            pass
            t_23.extend((
                '\n// validate ',
                to_string(l_1_name),
                '\nerr = messageValidator.validateMapPointer(',
                to_string(l_1_offset),
                ', ',
                to_string(t_18(l_1_field)),
                ');\n',
                to_string(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif (t_6(environment.getattr(l_1_field, 'kind')) or t_12(environment.getattr(l_1_field, 'kind'))):
            pass
            t_23.extend((
                '\n// validate ',
                to_string(l_1_name),
                '\nerr = messageValidator.validateInterface(',
                to_string(l_1_offset),
                ', ',
                to_string(t_19(l_1_field)),
                ');\n',
                to_string(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif (t_7(environment.getattr(l_1_field, 'kind')) or t_11(environment.getattr(l_1_field, 'kind'))):
            pass
            t_23.extend((
                '\n// validate ',
                to_string(l_1_name),
                '\nerr = messageValidator.validateInterfaceRequest(',
                to_string(l_1_offset),
                ', ',
                to_string(t_19(l_1_field)),
                ')\n',
                to_string(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif (t_3(environment.getattr(l_1_field, 'kind')) or t_10(environment.getattr(l_1_field, 'kind'))):
            pass
            t_23.extend((
                '\n// validate ',
                to_string(l_1_name),
                '\nerr = messageValidator.validateAssociatedInterface(',
                to_string(l_1_offset),
                ', ',
                to_string(t_19(l_1_field)),
                ');\n',
                to_string(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif (t_4(environment.getattr(l_1_field, 'kind')) or t_9(environment.getattr(l_1_field, 'kind'))):
            pass
            t_23.extend((
                '\n// validate ',
                to_string(l_1_name),
                '\nerr = messageValidator.validateAssociatedInterfaceRequest(',
                to_string(l_1_offset),
                ', ',
                to_string(t_19(l_1_field)),
                ')\n',
                to_string(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif t_1(environment.getattr(l_1_field, 'kind')):
            pass
            t_23.extend((
                '\n// validate ',
                to_string(l_1_name),
                '\nerr = messageValidator.validateHandle(',
                to_string(l_1_offset),
                ', ',
                to_string(t_19(l_1_field)),
                ')\n',
                to_string(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif t_5(environment.getattr(l_1_field, 'kind')):
            pass
            t_23.extend((
                '\n// validate ',
                to_string(l_1_name),
                '\nerr = messageValidator.validateEnum(',
                to_string(l_1_offset),
                ', ',
                to_string(t_17(l_1_field)),
                ');\n',
                to_string(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        return concat(t_23)
    context.vars['_validate_field'] = l_0__validate_field = Macro(environment, macro, '_validate_field', ('field', 'offset', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_field, l_1_offset, l_1_name):
        t_24 = []
        if l_1_field is missing:
            l_1_field = undefined("parameter 'field' was not provided", name='field')
        if l_1_offset is missing:
            l_1_offset = undefined("parameter 'offset' was not provided", name='offset')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_15(environment.getattr(l_1_field, 'kind')):
            pass
            t_24.extend((
                '\n// validate ',
                to_string(l_1_name),
                '\nerr = messageValidator.validateUnion(',
                to_string(l_1_offset),
                ', ',
                to_string(t_21(l_1_field)),
                ');\n',
                to_string(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        else:
            pass
            t_24.append(
                to_string(context.call((undefined(name='_validate_field') if l_0__validate_field is missing else l_0__validate_field), l_1_field, l_1_offset, l_1_name)),
            )
        return concat(t_24)
    context.exported_vars.add('validate_struct_field')
    context.vars['validate_struct_field'] = l_0_validate_struct_field = Macro(environment, macro, 'validate_struct_field', ('field', 'offset', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_field, l_1_offset, l_1_name):
        t_25 = []
        if l_1_field is missing:
            l_1_field = undefined("parameter 'field' was not provided", name='field')
        if l_1_offset is missing:
            l_1_offset = undefined("parameter 'offset' was not provided", name='offset')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_15(environment.getattr(l_1_field, 'kind')):
            pass
            t_25.extend((
                '\n// validate ',
                to_string(l_1_name),
                '\nerr = messageValidator.validateNestedUnion(',
                to_string(l_1_offset),
                ', ',
                to_string(t_21(l_1_field)),
                ');\n',
                to_string(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        else:
            pass
            t_25.extend((
                '\n',
                to_string(context.call((undefined(name='_validate_field') if l_0__validate_field is missing else l_0__validate_field), l_1_field, l_1_offset, l_1_name)),
            ))
        return concat(t_25)
    context.exported_vars.add('validate_union_field')
    context.vars['validate_union_field'] = l_0_validate_union_field = Macro(environment, macro, 'validate_union_field', ('field', 'offset', 'name'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=33&6=41&7=50&8=54&9=56&10=60&11=62&12=66&13=68&14=72&15=74&16=78&17=80&18=84&19=86&20=90&21=92&22=96&23=98&24=102&25=104&26=108&27=110&29=114&30=116&31=120&32=122&34=126&35=128&36=132&37=134&39=138&40=140&41=144&42=146&43=150&44=152&45=156&46=158&47=162&48=164&49=168&53=172&54=181&55=185&56=187&57=191&59=196&63=201&64=210&65=214&66=216&67=220&69=226'