from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'fuzzing.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_get_handle_deps = l_0_set_handles = l_0_build_call = l_0_generate_or_mutate_enum = l_0_generate_or_mutate_array = l_0_generate_or_mutate_map = l_0_generate_or_mutate_primitive = l_0_generate_or_mutate_interface = l_0_generate_or_mutate = missing
    t_1 = environment.filters['fuzz_handle_name']
    t_2 = environment.filters['indent']
    t_3 = environment.filters['is_any_handle_or_interface_kind']
    t_4 = environment.filters['is_any_interface_kind']
    t_5 = environment.filters['is_array_kind']
    t_6 = environment.filters['is_associated_interface_kind']
    t_7 = environment.filters['is_associated_interface_request_kind']
    t_8 = environment.filters['is_enum_kind']
    t_9 = environment.filters['is_interface_kind']
    t_10 = environment.filters['is_interface_request_kind']
    t_11 = environment.filters['is_map_kind']
    t_12 = environment.filters['is_pending_associated_receiver_kind']
    t_13 = environment.filters['is_pending_associated_remote_kind']
    t_14 = environment.filters['is_pending_receiver_kind']
    t_15 = environment.filters['is_pending_remote_kind']
    t_16 = environment.filters['is_primitive_kind']
    t_17 = environment.filters['is_reference_kind']
    t_18 = environment.filters['is_struct_kind']
    t_19 = environment.filters['is_union_kind']
    t_20 = environment.filters['join']
    t_21 = environment.filters['primitive_to_fuzz_type']
    t_22 = environment.filters['to_js_boolean']
    t_23 = environment.tests['none']
    pass
    def macro(l_1_kind, l_1_name):
        t_24 = []
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (t_18(l_1_kind) or t_19(l_1_kind)):
            pass
            t_24.extend((
                to_string(l_1_name),
                '.getHandleDeps()',
            ))
        elif t_5(l_1_kind):
            pass
            t_24.extend((
                '[].concat.apply([], ',
                to_string(l_1_name),
                '.map(function(val) {\n  if (val) {\n    return ',
                to_string(t_2(context.call((undefined(name='get_handle_deps') if l_0_get_handle_deps is missing else l_0_get_handle_deps), environment.getattr(l_1_kind, 'kind'), 'val'), 4)),
                ';\n  }\n  return [];\n}))',
            ))
        elif t_11(l_1_kind):
            pass
            t_24.extend((
                '[].concat.apply([], Array.from(',
                to_string(l_1_name),
                '.values()).map(function(val) {\n  if (val) {\n    return ',
                to_string(t_2(context.call((undefined(name='get_handle_deps') if l_0_get_handle_deps is missing else l_0_get_handle_deps), environment.getattr(l_1_kind, 'value_kind'), 'val'), 4)),
                ';\n  }\n  return [];\n}))',
            ))
        elif t_3(l_1_kind):
            pass
            t_24.extend((
                '["',
                to_string(t_1(l_1_kind)),
                '"]',
            ))
        else:
            pass
            t_24.append(
                '[]',
            )
        return concat(t_24)
    context.exported_vars.add('get_handle_deps')
    context.vars['get_handle_deps'] = l_0_get_handle_deps = Macro(environment, macro, 'get_handle_deps', ('kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_kind, l_1_name):
        t_25 = []
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (t_18(l_1_kind) or t_19(l_1_kind)):
            pass
            t_25.extend((
                'idx = ',
                to_string(l_1_name),
                '.setHandlesInternal_(handles, idx)',
            ))
        elif t_5(l_1_kind):
            pass
            t_25.extend((
                to_string(l_1_name),
                '.forEach(function(val) {\n  ',
                to_string(t_2(context.call((undefined(name='set_handles') if l_0_set_handles is missing else l_0_set_handles), environment.getattr(l_1_kind, 'kind'), 'val'), 2)),
                ';\n})',
            ))
        elif t_11(l_1_kind):
            pass
            t_25.extend((
                to_string(l_1_name),
                '.forEach(function(val) {\n  ',
                to_string(t_2(context.call((undefined(name='set_handles') if l_0_set_handles is missing else l_0_set_handles), environment.getattr(l_1_kind, 'value_kind'), 'val'), 2)),
                ';\n})',
            ))
        elif t_3(l_1_kind):
            pass
            t_25.extend((
                to_string(l_1_name),
                ' = handles[idx++];',
            ))
        return concat(t_25)
    context.exported_vars.add('set_handles')
    context.vars['set_handles'] = l_0_set_handles = Macro(environment, macro, 'set_handles', ('kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_obj, l_1_operation, l_1_type, l_1_name, l_1_varargs):
        t_26 = []
        if l_1_obj is missing:
            l_1_obj = undefined("parameter 'obj' was not provided", name='obj')
        if l_1_operation is missing:
            l_1_operation = undefined("parameter 'operation' was not provided", name='operation')
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if l_1_name:
            pass
            t_26.extend((
                to_string(l_1_obj),
                '.',
                to_string(l_1_operation),
                to_string(l_1_type),
                '(',
                to_string(t_20(context.eval_ctx, ((l_1_name,) + l_1_varargs), ', ')),
                ')',
            ))
        else:
            pass
            t_26.extend((
                to_string(l_1_obj),
                '.',
                to_string(l_1_operation),
                to_string(l_1_type),
                '(',
                to_string(t_20(context.eval_ctx, l_1_varargs, ', ')),
                ')',
            ))
        return concat(t_26)
    context.exported_vars.add('build_call')
    context.vars['build_call'] = l_0_build_call = Macro(environment, macro, 'build_call', ('obj', 'operation', 'type', 'name'), False, True, False, context.eval_ctx.autoescape)
    def macro(l_1_obj, l_1_operation, l_1_kind, l_1_name):
        t_27 = []
        if l_1_obj is missing:
            l_1_obj = undefined("parameter 'obj' was not provided", name='obj')
        if l_1_operation is missing:
            l_1_operation = undefined("parameter 'operation' was not provided", name='operation')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (not t_23(environment.getattr(l_1_kind, 'max_value'))):
            pass
            t_27.append(
                to_string(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'Enum', l_1_name, '0', environment.getattr(l_1_kind, 'max_value'))),
            )
        else:
            pass
            t_27.append(
                to_string(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'Enum', l_1_name)),
            )
        return concat(t_27)
    context.exported_vars.add('generate_or_mutate_enum')
    context.vars['generate_or_mutate_enum'] = l_0_generate_or_mutate_enum = Macro(environment, macro, 'generate_or_mutate_enum', ('obj', 'operation', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_obj, l_1_operation, l_1_kind, l_1_name):
        t_28 = []
        if l_1_obj is missing:
            l_1_obj = undefined("parameter 'obj' was not provided", name='obj')
        if l_1_operation is missing:
            l_1_operation = undefined("parameter 'operation' was not provided", name='operation')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (l_1_operation == 'mutate'):
            pass
            t_28.extend((
                to_string(l_1_obj),
                '.',
                to_string(l_1_operation),
                'Array(',
                to_string(l_1_name),
                ', function(val) {\n  return ',
                to_string(t_2(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), l_1_obj, l_1_operation, environment.getattr(l_1_kind, 'kind'), 'val'), 2)),
                ';\n})',
            ))
        else:
            pass
            t_28.extend((
                to_string(l_1_obj),
                '.',
                to_string(l_1_operation),
                'Array(function() {\n  return ',
                to_string(t_2(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), l_1_obj, l_1_operation, environment.getattr(l_1_kind, 'kind')), 2)),
                ';\n})',
            ))
        return concat(t_28)
    context.exported_vars.add('generate_or_mutate_array')
    context.vars['generate_or_mutate_array'] = l_0_generate_or_mutate_array = Macro(environment, macro, 'generate_or_mutate_array', ('obj', 'operation', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_obj, l_1_operation, l_1_kind, l_1_name):
        t_29 = []
        if l_1_obj is missing:
            l_1_obj = undefined("parameter 'obj' was not provided", name='obj')
        if l_1_operation is missing:
            l_1_operation = undefined("parameter 'operation' was not provided", name='operation')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (l_1_operation == 'mutate'):
            pass
            t_29.extend((
                to_string(l_1_obj),
                '.',
                to_string(l_1_operation),
                'Map(',
                to_string(l_1_name),
                ',\n  function(val) {\n    return ',
                to_string(t_2(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), l_1_obj, l_1_operation, environment.getattr(l_1_kind, 'key_kind'), 'val'), 4)),
                ';\n  },\n  function(val) {\n    return ',
                to_string(t_2(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), l_1_obj, l_1_operation, environment.getattr(l_1_kind, 'value_kind'), 'val'), 4)),
                ';\n  })',
            ))
        else:
            pass
            t_29.extend((
                to_string(l_1_obj),
                '.',
                to_string(l_1_operation),
                'Map(\n  function() {\n    return ',
                to_string(t_2(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), l_1_obj, l_1_operation, environment.getattr(l_1_kind, 'key_kind')), 4)),
                ';\n  },\n  function() {\n    return ',
                to_string(t_2(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), l_1_obj, l_1_operation, environment.getattr(l_1_kind, 'value_kind')), 4)),
                ';\n  })',
            ))
        return concat(t_29)
    context.exported_vars.add('generate_or_mutate_map')
    context.vars['generate_or_mutate_map'] = l_0_generate_or_mutate_map = Macro(environment, macro, 'generate_or_mutate_map', ('obj', 'operation', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_obj, l_1_operation, l_1_kind, l_1_name):
        t_30 = []
        if l_1_obj is missing:
            l_1_obj = undefined("parameter 'obj' was not provided", name='obj')
        if l_1_operation is missing:
            l_1_operation = undefined("parameter 'operation' was not provided", name='operation')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_17(l_1_kind):
            pass
            t_30.append(
                to_string(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, t_21(l_1_kind), l_1_name, t_22(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        else:
            pass
            t_30.append(
                to_string(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, t_21(l_1_kind), l_1_name)),
            )
        return concat(t_30)
    context.exported_vars.add('generate_or_mutate_primitive')
    context.vars['generate_or_mutate_primitive'] = l_0_generate_or_mutate_primitive = Macro(environment, macro, 'generate_or_mutate_primitive', ('obj', 'operation', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_obj, l_1_operation, l_1_kind, l_1_name):
        t_31 = []
        if l_1_obj is missing:
            l_1_obj = undefined("parameter 'obj' was not provided", name='obj')
        if l_1_operation is missing:
            l_1_operation = undefined("parameter 'operation' was not provided", name='operation')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (t_10(l_1_kind) or t_14(l_1_kind)):
            pass
            t_31.append(
                to_string(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'InterfaceRequest', l_1_name, unicode_join(('"', environment.getattr(environment.getattr(environment.getattr(l_1_kind, 'kind'), 'module'), 'namespace'), '.', environment.getattr(environment.getattr(l_1_kind, 'kind'), 'name'), '"', )), t_22(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        elif t_9(l_1_kind):
            pass
            t_31.append(
                to_string(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'Interface', l_1_name, unicode_join(('"', environment.getattr(environment.getattr(l_1_kind, 'module'), 'namespace'), '.', environment.getattr(l_1_kind, 'name'), '"', )), t_22(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        elif t_15(l_1_kind):
            pass
            t_31.append(
                to_string(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'Interface', l_1_name, unicode_join(('"', environment.getattr(environment.getattr(environment.getattr(l_1_kind, 'kind'), 'module'), 'namespace'), '.', environment.getattr(environment.getattr(l_1_kind, 'kind'), 'name'), '"', )), t_22(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        elif (t_7(l_1_kind) or t_12(l_1_kind)):
            pass
            t_31.append(
                to_string(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'AssociatedInterfaceRequest', l_1_name, unicode_join(('"', environment.getattr(environment.getattr(environment.getattr(l_1_kind, 'kind'), 'module'), 'namespace'), '.', environment.getattr(environment.getattr(l_1_kind, 'kind'), 'name'), '"', )), t_22(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        elif (t_6(l_1_kind) or t_13(l_1_kind)):
            pass
            t_31.append(
                to_string(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'AssociatedInterface', l_1_name, unicode_join(('"', environment.getattr(environment.getattr(environment.getattr(l_1_kind, 'kind'), 'module'), 'namespace'), '.', environment.getattr(environment.getattr(l_1_kind, 'kind'), 'name'), '"', )), t_22(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        return concat(t_31)
    context.exported_vars.add('generate_or_mutate_interface')
    context.vars['generate_or_mutate_interface'] = l_0_generate_or_mutate_interface = Macro(environment, macro, 'generate_or_mutate_interface', ('obj', 'operation', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_obj, l_1_operation, l_1_kind, l_1_name):
        t_32 = []
        if l_1_obj is missing:
            l_1_obj = undefined("parameter 'obj' was not provided", name='obj')
        if l_1_operation is missing:
            l_1_operation = undefined("parameter 'operation' was not provided", name='operation')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = ''
        pass
        if t_16(l_1_kind):
            pass
            t_32.append(
                to_string(context.call((undefined(name='generate_or_mutate_primitive') if l_0_generate_or_mutate_primitive is missing else l_0_generate_or_mutate_primitive), l_1_obj, l_1_operation, l_1_kind, l_1_name)),
            )
        elif t_4(l_1_kind):
            pass
            t_32.append(
                to_string(context.call((undefined(name='generate_or_mutate_interface') if l_0_generate_or_mutate_interface is missing else l_0_generate_or_mutate_interface), l_1_obj, l_1_operation, l_1_kind, l_1_name)),
            )
        elif t_8(l_1_kind):
            pass
            t_32.append(
                to_string(context.call((undefined(name='generate_or_mutate_enum') if l_0_generate_or_mutate_enum is missing else l_0_generate_or_mutate_enum), l_1_obj, l_1_operation, l_1_kind, l_1_name)),
            )
        elif t_18(l_1_kind):
            pass
            t_32.append(
                to_string(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'Struct', l_1_name, unicode_join((environment.getattr(environment.getattr(l_1_kind, 'module'), 'namespace'), '.', environment.getattr(l_1_kind, 'name'), )), t_22(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        elif t_19(l_1_kind):
            pass
            t_32.append(
                to_string(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'Union', l_1_name, unicode_join((environment.getattr(environment.getattr(l_1_kind, 'module'), 'namespace'), '.', environment.getattr(l_1_kind, 'name'), )), t_22(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        elif t_5(l_1_kind):
            pass
            t_32.append(
                to_string(context.call((undefined(name='generate_or_mutate_array') if l_0_generate_or_mutate_array is missing else l_0_generate_or_mutate_array), l_1_obj, l_1_operation, l_1_kind, l_1_name)),
            )
        elif t_11(l_1_kind):
            pass
            t_32.append(
                to_string(context.call((undefined(name='generate_or_mutate_map') if l_0_generate_or_mutate_map is missing else l_0_generate_or_mutate_map), l_1_obj, l_1_operation, l_1_kind, l_1_name)),
            )
        return concat(t_32)
    context.exported_vars.add('generate_or_mutate')
    context.vars['generate_or_mutate'] = l_0_generate_or_mutate = Macro(environment, macro, 'generate_or_mutate', ('obj', 'operation', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=35&2=42&3=45&4=48&5=52&7=54&11=57&12=61&14=63&18=66&19=70&25=81&26=88&27=92&28=95&29=98&30=100&32=103&33=106&34=108&36=111&37=114&41=120&42=131&43=134&45=145&49=156&50=167&51=170&53=175&57=180&58=191&59=194&60=200&63=206&64=210&69=216&70=227&71=230&73=236&76=238&79=244&81=248&84=250&89=256&90=267&91=270&93=275&97=280&98=291&99=294&100=296&101=299&102=301&103=304&104=306&105=309&106=311&107=314&111=319&112=330&113=333&114=335&115=338&116=340&117=343&118=345&119=348&120=350&121=353&122=355&123=358&124=360&125=363'