from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'lite/mojom.m.js.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_for_bindings_internals = resolve('for_bindings_internals')
    l_0_bindings_library_path = resolve('bindings_library_path')
    l_0_js_module_imports = resolve('js_module_imports')
    l_0_module = resolve('module')
    l_0_enums = resolve('enums')
    l_0_interfaces = resolve('interfaces')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_enum_def = missing
    t_1 = environment.filters['constant_value_in_js_module']
    t_2 = environment.filters['imports_for_kind']
    t_3 = environment.filters['sort']
    t_4 = environment.filters['type_in_js_module_with_nullability']
    pass
    yield '// Copyright 2020 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.\n\n'
    if (not (undefined(name='for_bindings_internals') if l_0_for_bindings_internals is missing else l_0_for_bindings_internals)):
        pass
        yield "import {mojo} from '"
        yield to_string((undefined(name='bindings_library_path') if l_0_bindings_library_path is missing else l_0_bindings_library_path))
        yield "';"
    yield '\n\n'
    l_1_loop = missing
    for (l_1_path, l_1_kinds), l_1_loop in LoopContext(t_3(environment, context.call(environment.getattr((undefined(name='js_module_imports') if l_0_js_module_imports is missing else l_0_js_module_imports), 'items'))), undefined):
        pass
        yield 'import {'
        l_2_loop = missing
        for l_2_kind, l_2_loop in LoopContext(t_3(environment, l_1_kinds), undefined):
            pass
            l_3_loop = missing
            for l_3_item, l_3_loop in LoopContext(t_2(l_2_kind), undefined):
                pass
                yield '\n  '
                yield to_string(environment.getattr(l_3_item, 'name'))
                yield ' as '
                yield to_string(environment.getattr(l_3_item, 'alias'))
                if (not environment.getattr(l_3_loop, 'last')):
                    pass
                    yield ','
            l_3_loop = l_3_item = missing
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_kind = missing
        yield "\n} from '"
        yield to_string(l_1_path)
        yield "';\n\n"
    l_1_loop = l_1_path = l_1_kinds = missing
    for l_1_constant in environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'):
        pass
        yield '\n/**\n * @const { '
        yield to_string(t_4(environment.getattr(l_1_constant, 'kind')))
        yield ' }\n */\nexport const '
        yield to_string(environment.getattr(l_1_constant, 'name'))
        yield ' = '
        yield to_string(t_1(l_1_constant))
        yield ';\n\n'
    l_1_constant = missing
    included_template = environment.get_template('lite/enum_definition_for_module.tmpl', 'lite/mojom.m.js.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined("the template %r (imported on line 32 in 'lite/mojom.m.js.tmpl') does not export the requested name 'enum_def'" % included_template.__name__, name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    for l_1_enum in (undefined(name='enums') if l_0_enums is missing else l_0_enums):
        pass
        yield '\n'
        yield to_string(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), l_1_enum))
        yield '\n'
    l_1_enum = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        yield '\n'
        template = environment.get_template('lite/interface_definition_for_module.tmpl', 'lite/mojom.m.js.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_def': l_0_enum_def, 'interface': l_1_interface})):
            yield event
    l_1_interface = missing
    yield '\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        yield '\n/**\n * @const { {$:!mojo.internal.MojomType}}\n */\nexport const '
        yield to_string(environment.getattr(l_1_struct, 'name'))
        yield 'Spec =\n    { $: /** @type {!mojo.internal.MojomType} */ ({}) };\n'
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        yield '\n/**\n * @const { {$:!mojo.internal.MojomType} }\n */\nexport const '
        yield to_string(environment.getattr(l_1_union, 'name'))
        yield 'Spec =\n    { $: /** @type {!mojo.internal.MojomType} */ ({}) };\n'
    l_1_union = missing
    yield '\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        template = environment.get_template('lite/struct_definition_for_module.tmpl', 'lite/mojom.m.js.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_def': l_0_enum_def, 'struct': l_1_struct})):
            yield event
        yield '\n'
    l_1_struct = missing
    yield '\n'
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        template = environment.get_template('lite/union_definition_for_module.tmpl', 'lite/mojom.m.js.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_def': l_0_enum_def, 'union': l_1_union})):
            yield event
        yield '\n'
    l_1_union = missing

blocks = {}
debug_info = '5=25&6=28&9=32&11=36&12=39&13=42&14=45&16=49&18=54&23=57&25=60&27=62&32=67&33=73&34=76&38=79&39=82&43=87&47=90&50=93&54=96&59=100&60=102&64=108&65=110'