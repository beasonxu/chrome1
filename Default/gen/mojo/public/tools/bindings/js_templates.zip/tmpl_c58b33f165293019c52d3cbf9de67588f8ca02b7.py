from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'lite/struct_definition_for_module.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_generate_struct_deserializers = resolve('generate_struct_deserializers')
    l_0_enum_def = missing
    t_1 = environment.filters['constant_value_in_js_module']
    t_2 = environment.filters['default_value_in_js_module']
    t_3 = environment.filters['field_type_in_js_module']
    t_4 = environment.filters['is_bool_kind']
    t_5 = environment.filters['spec_type_in_js_module']
    t_6 = environment.filters['type_in_js_module_with_nullability']
    pass
    for l_1_constant in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'constants'):
        pass
        yield '\n/**\n * @const { '
        yield to_string(t_6(environment.getattr(l_1_constant, 'kind')))
        yield ' }\n */\nexport const '
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '_'
        yield to_string(environment.getattr(l_1_constant, 'name'))
        yield ' =\n    '
        yield to_string(t_1(l_1_constant))
        yield ';\n'
    l_1_constant = missing
    included_template = environment.get_template('lite/enum_definition_for_module.tmpl', 'lite/struct_definition_for_module.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined("the template %r (imported on line 9 in 'lite/struct_definition_for_module.tmpl') does not export the requested name 'enum_def'" % included_template.__name__, name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    yield '\n'
    for l_1_enum in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'enums'):
        pass
        yield '\n'
        yield to_string(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), l_1_enum))
        yield '\n'
    l_1_enum = missing
    yield '\n\nmojo.internal.Struct(\n    '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield "Spec.$,\n    '"
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield "',\n    ["
    for l_1_packed_field in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields_in_ordinal_order'):
        pass
        yield "\n      mojo.internal.StructField(\n        '"
        yield to_string(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name'))
        yield "', "
        yield to_string(environment.getattr(l_1_packed_field, 'offset'))
        yield ',\n        '
        if t_4(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')):
            pass
            yield to_string(environment.getattr(l_1_packed_field, 'bit'))
        else:
            pass
            yield '0'
        yield ',\n        '
        yield to_string(t_5(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')))
        yield ',\n        '
        yield to_string(t_2(environment.getattr(l_1_packed_field, 'field')))
        yield ','
        if environment.getattr(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind'), 'is_nullable'):
            pass
            yield '\n        true /* nullable */,'
        else:
            pass
            yield '\n        false /* nullable */,'
        yield '\n        '
        yield to_string((environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'min_version') or 0))
        yield '),'
    l_1_packed_field = missing
    yield '\n    ],\n    ['
    for l_1_info in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'):
        pass
        yield '['
        yield to_string(environment.getattr(l_1_info, 'version'))
        yield ', '
        yield to_string(environment.getattr(l_1_info, 'num_bytes'))
        yield '],'
    l_1_info = missing
    yield ']);\n\n'
    if (undefined(name='generate_struct_deserializers') if l_0_generate_struct_deserializers is missing else l_0_generate_struct_deserializers):
        pass
        yield '\nexport const '
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '_Deserialize =\n    mojo.internal.createStructDeserializer('
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield 'Spec.$);\n'
    yield '\n\n/**\n * @record\n */\nexport class '
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield ' {\n  constructor() {'
    for l_1_packed_field in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields'):
        pass
        yield '\n    /** @type { '
        yield to_string(t_3(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')))
        yield ' } */\n    this.'
        yield to_string(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name'))
        yield ';'
    l_1_packed_field = missing
    yield '\n  }\n}'

blocks = {}
debug_info = '1=20&3=23&5=25&6=29&9=32&10=39&11=42&15=46&16=48&18=50&20=53&21=57&23=64&24=66&25=68&30=75&34=79&35=82&39=88&40=91&41=93&47=96&49=98&50=101&51=103'