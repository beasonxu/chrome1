from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'lite/module_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_enums = resolve('enums')
    l_0_interfaces = resolve('interfaces')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_enum_def = missing
    t_1 = environment.filters['constant_value']
    t_2 = environment.filters['lite_closure_type_with_nullability']
    pass
    for l_1_constant in environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'):
        l_1_generate_closure_exports = resolve('generate_closure_exports')
        pass
        yield '\n'
        if (undefined(name='generate_closure_exports') if l_1_generate_closure_exports is missing else l_1_generate_closure_exports):
            pass
            yield "goog.provide('"
            yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
            yield '.'
            yield to_string(environment.getattr(l_1_constant, 'name'))
            yield "');"
        yield '\n/**\n * @const { '
        yield to_string(t_2(environment.getattr(l_1_constant, 'kind')))
        yield ' }\n * @export\n */\n'
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr(l_1_constant, 'name'))
        yield ' = '
        yield to_string(t_1(l_1_constant))
        yield ';'
    l_1_constant = l_1_generate_closure_exports = missing
    yield '\n'
    included_template = environment.get_template('lite/enum_definition.tmpl', 'lite/module_definition.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined("the template %r (imported on line 15 in 'lite/module_definition.tmpl') does not export the requested name 'enum_def'" % included_template.__name__, name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    for l_1_enum in (undefined(name='enums') if l_0_enums is missing else l_0_enums):
        pass
        yield '\n'
        yield to_string(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'), environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'), l_1_enum))
        yield '\n'
    l_1_enum = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        pass
        yield '\n'
        template = environment.get_template('lite/interface_definition.tmpl', 'lite/module_definition.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_def': l_0_enum_def, 'interface': l_1_interface})):
            yield event
    l_1_interface = missing
    yield '\n\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        l_1_generate_closure_exports = resolve('generate_closure_exports')
        pass
        yield '\n'
        if (undefined(name='generate_closure_exports') if l_1_generate_closure_exports is missing else l_1_generate_closure_exports):
            pass
            yield "goog.provide('"
            yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
            yield '.'
            yield to_string(environment.getattr(l_1_struct, 'name'))
            yield "Spec');"
        yield '\n/**\n * @const { {$:!mojo.internal.MojomType}}\n * @export\n */\n'
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr(l_1_struct, 'name'))
        yield 'Spec =\n    { $: /** @type {!mojo.internal.MojomType} */ ({}) };\n'
    l_1_struct = l_1_generate_closure_exports = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        l_1_generate_closure_exports = resolve('generate_closure_exports')
        pass
        yield '\n'
        if (undefined(name='generate_closure_exports') if l_1_generate_closure_exports is missing else l_1_generate_closure_exports):
            pass
            yield "goog.provide('"
            yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
            yield '.'
            yield to_string(environment.getattr(l_1_union, 'name'))
            yield "Spec');"
        yield '\n/**\n * @const { {$:!mojo.internal.MojomType} }\n * @export\n */\n'
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr(l_1_union, 'name'))
        yield 'Spec =\n    { $: /** @type {!mojo.internal.MojomType} */ ({}) };\n'
    l_1_union = l_1_generate_closure_exports = missing
    yield '\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        template = environment.get_template('lite/struct_definition.tmpl', 'lite/module_definition.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_def': l_0_enum_def, 'struct': l_1_struct})):
            yield event
        yield '\n'
    l_1_struct = missing
    yield '\n'
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        template = environment.get_template('lite/union_definition.tmpl', 'lite/module_definition.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'enum_def': l_0_enum_def, 'union': l_1_union})):
            yield event
        yield '\n'
    l_1_union = missing

blocks = {}
debug_info = '2=19&3=23&4=26&8=31&11=33&15=41&16=47&17=50&21=53&22=56&29=61&30=65&31=68&37=73&40=78&41=82&42=85&48=90&53=96&54=98&58=104&59=106'