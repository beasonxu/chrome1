from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'interface_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_module = resolve('module')
    l_0_generate_fuzzing = resolve('generate_fuzzing')
    l_0_enum_def = missing
    t_1 = environment.filters['expression_to_text']
    t_2 = environment.filters['format']
    t_3 = environment.filters['has_callbacks']
    t_4 = environment.filters['join']
    t_5 = environment.filters['map']
    t_6 = environment.filters['method_passes_associated_kinds']
    t_7 = environment.filters['sanitize_identifier']
    pass
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_interface_method_id = missing
        pass
        l_1_interface_method_id = unicode_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        yield '\n  var k'
        yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
        yield '_Name = '
        yield to_string(environment.getattr(l_1_method, 'ordinal'))
        yield ';'
    l_1_method = l_1_interface_method_id = missing
    yield '\n\n  function '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Ptr(handleOrPtrInfo) {\n    this.ptr = new bindings.InterfacePtrController('
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield ',\n                                                   handleOrPtrInfo);\n  }\n\n  function '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'AssociatedPtr(associatedInterfacePtrInfo) {\n    this.ptr = new associatedBindings.AssociatedInterfacePtrController(\n        '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield ', associatedInterfacePtrInfo);\n  }\n\n  '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'AssociatedPtr.prototype =\n      Object.create('
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Ptr.prototype);\n  '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'AssociatedPtr.prototype.constructor =\n      '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'AssociatedPtr;\n\n  function '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Proxy(receiver) {\n    this.receiver_ = receiver;\n  }'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        l_1_interface_method_id = missing
        pass
        l_1_interface_method_id = unicode_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        yield '\n  '
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Ptr.prototype.'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield ' = function() {\n    return '
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Proxy.prototype.'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield '\n        .apply(this.ptr.getProxy(), arguments);\n  };\n\n  '
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Proxy.prototype.'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield ' = function('
        l_2_loop = missing
        for l_2_parameter, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            pass
            yield to_string(t_7(environment.getattr(l_2_parameter, 'name')))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ', '
        l_2_loop = l_2_parameter = missing
        yield ') {\n    var params_ = new '
        yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
        yield '_Params();'
        for l_2_parameter in environment.getattr(l_1_method, 'parameters'):
            pass
            yield '\n    params_.'
            yield to_string(environment.getattr(l_2_parameter, 'name'))
            yield ' = '
            yield to_string(t_7(environment.getattr(l_2_parameter, 'name')))
            yield ';'
        l_2_parameter = missing
        if (environment.getattr(l_1_method, 'response_parameters') == None):
            pass
            if t_6(l_1_method):
                pass
                yield '\n    var builder = new codec.MessageV2Builder(\n        k'
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Name,\n        codec.align('
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params.encodedSize));\n    builder.setPayload('
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params, params_);'
            else:
                pass
                yield '\n    var builder = new codec.MessageV0Builder(\n        k'
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Name,\n        codec.align('
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params.encodedSize));\n    builder.encodeStruct('
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params, params_);'
            yield '\n    var message = builder.finish();\n    this.receiver_.accept(message);'
        else:
            pass
            yield '\n    return new Promise(function(resolve, reject) {'
            if t_6(l_1_method):
                pass
                yield '\n      var builder = new codec.MessageV2Builder(\n          k'
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Name,\n          codec.align('
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params.encodedSize),\n          codec.kMessageExpectsResponse, 0);\n      builder.setPayload('
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params, params_);'
            else:
                pass
                yield '\n      var builder = new codec.MessageV1Builder(\n          k'
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Name,\n          codec.align('
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params.encodedSize),\n          codec.kMessageExpectsResponse, 0);\n      builder.encodeStruct('
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params, params_);'
            yield '\n      var message = builder.finish();\n      this.receiver_.acceptAndExpectResponse(message).then(function(message) {\n        var reader = new codec.MessageReader(message);\n        var responseParams =\n            reader.decodeStruct('
            yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_ResponseParams);\n        resolve(responseParams);\n      }).catch(function(result) {\n        reject(Error("Connection error: " + result));\n      });\n    }.bind(this));'
        yield '\n  };'
    l_1_loop = l_1_method = l_1_interface_method_id = missing
    yield '\n\n  function '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub(delegate) {\n    this.delegate_ = delegate;\n  }'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        yield '\n  '
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Stub.prototype.'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield ' = function('
        yield to_string(t_4(context.eval_ctx, t_5(context, t_5(context, environment.getattr(l_1_method, 'parameters'), attribute='name'), 'sanitize_identifier'), ', '))
        yield ') {\n    return this.delegate_ && this.delegate_.'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield ' && this.delegate_.'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield '('
        yield to_string(t_4(context.eval_ctx, t_5(context, t_5(context, environment.getattr(l_1_method, 'parameters'), attribute='name'), 'sanitize_identifier'), ', '))
        yield ');\n  }'
    l_1_method = missing
    yield '\n\n  '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub.prototype.accept = function(message) {\n    var reader = new codec.MessageReader(message);\n    switch (reader.messageName) {'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        l_1_interface_method_id = missing
        pass
        l_1_interface_method_id = unicode_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        if (environment.getattr(l_1_method, 'response_parameters') == None):
            pass
            yield '\n    case k'
            yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_Name:\n      var params = reader.decodeStruct('
            yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_Params);\n      this.'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '('
            l_2_loop = missing
            for l_2_parameter, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
                pass
                yield 'params.'
                yield to_string(environment.getattr(l_2_parameter, 'name'))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    yield ', '
            l_2_loop = l_2_parameter = missing
            yield ');\n      return true;'
    l_1_loop = l_1_method = l_1_interface_method_id = missing
    yield '\n    default:\n      return false;\n    }\n  };\n\n  '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub.prototype.acceptWithResponder =\n      function(message, responder) {\n    var reader = new codec.MessageReader(message);\n    switch (reader.messageName) {'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        l_1_interface_method_id = missing
        pass
        l_1_interface_method_id = unicode_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n    case k'
            yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_Name:\n      var params = reader.decodeStruct('
            yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_Params);\n      this.'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '('
            l_2_loop = missing
            for l_2_parameter, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
                pass
                yield 'params.'
                yield to_string(environment.getattr(l_2_parameter, 'name'))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    yield ', '
            l_2_loop = l_2_parameter = missing
            yield ').then(function(response) {\n        var responseParams =\n            new '
            yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_ResponseParams();'
            for l_2_parameter in environment.getattr(l_1_method, 'response_parameters'):
                pass
                yield '\n        responseParams.'
                yield to_string(environment.getattr(l_2_parameter, 'name'))
                yield ' = response.'
                yield to_string(environment.getattr(l_2_parameter, 'name'))
                yield ';'
            l_2_parameter = missing
            if t_6(l_1_method):
                pass
                yield '\n        var builder = new codec.MessageV2Builder(\n            k'
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Name,\n            codec.align('
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_ResponseParams\n                .encodedSize),\n            codec.kMessageIsResponse, reader.requestID);\n        builder.setPayload('
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_ResponseParams,\n                             responseParams);'
            else:
                pass
                yield '\n        var builder = new codec.MessageV1Builder(\n            k'
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Name,\n            codec.align('
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_ResponseParams.encodedSize),\n            codec.kMessageIsResponse, reader.requestID);\n        builder.encodeStruct('
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_ResponseParams,\n                             responseParams);'
            yield '\n        var message = builder.finish();\n        responder.accept(message);\n      });\n      return true;'
    l_1_loop = l_1_method = l_1_interface_method_id = missing
    yield '\n    default:\n      return false;\n    }\n  };\n\n  function validate'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Request(messageValidator) {'
    if (not environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods')):
        pass
        yield '\n    return validator.validationError.NONE;'
    else:
        pass
        yield '\n    var message = messageValidator.message;\n    var paramsClass = null;\n    switch (message.getName()) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            l_1_interface_method_id = missing
            pass
            l_1_interface_method_id = unicode_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
            yield '\n      case k'
            yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_Name:'
            if (environment.getattr(l_1_method, 'response_parameters') == None):
                pass
                yield '\n        if (!message.expectsResponse() && !message.isResponse())\n          paramsClass = '
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params;'
            else:
                pass
                yield '\n        if (message.expectsResponse())\n          paramsClass = '
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params;'
            yield '\n      break;'
        l_1_method = l_1_interface_method_id = missing
        yield '\n    }\n    if (paramsClass === null)\n      return validator.validationError.NONE;\n    return paramsClass.validate(messageValidator, messageValidator.message.getHeaderNumBytes());'
    yield '\n  }\n\n  function validate'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Response(messageValidator) {'
    if (not t_3((undefined(name='interface') if l_0_interface is missing else l_0_interface))):
        pass
        yield '\n    return validator.validationError.NONE;'
    else:
        pass
        yield '\n   var message = messageValidator.message;\n   var paramsClass = null;\n   switch (message.getName()) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            l_1_interface_method_id = missing
            pass
            l_1_interface_method_id = unicode_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
            if (environment.getattr(l_1_method, 'response_parameters') != None):
                pass
                yield '\n      case k'
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Name:\n        if (message.isResponse())\n          paramsClass = '
                yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_ResponseParams;\n        break;'
        l_1_method = l_1_interface_method_id = missing
        yield '\n    }\n    if (paramsClass === null)\n      return validator.validationError.NONE;\n    return paramsClass.validate(messageValidator, messageValidator.message.getHeaderNumBytes());'
    yield '\n  }\n\n  var '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield " = {\n    name: '"
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'mojom_namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'))
    yield "',\n    kVersion: "
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'version'))
    yield ',\n    ptrClass: '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Ptr,\n    proxyClass: '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Proxy,\n    stubClass: '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub,\n    validateRequest: validate'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Request,'
    if t_3((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield '\n    validateResponse: validate'
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Response,'
    else:
        pass
        yield '\n    validateResponse: null,'
    if (undefined(name='generate_fuzzing') if l_0_generate_fuzzing is missing else l_0_generate_fuzzing):
        pass
        yield "\n    mojomId: '"
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
        yield "',\n    fuzzMethods: {"
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            l_1_interface_method_id = missing
            pass
            l_1_interface_method_id = unicode_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
            yield '\n      '
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield ': {\n        params: '
            yield to_string((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_Params,\n      },'
        l_1_method = l_1_interface_method_id = missing
        yield '\n    },'
    yield '\n  };'
    for l_1_constant in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'constants'):
        pass
        yield '\n  '
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield '.'
        yield to_string(environment.getattr(l_1_constant, 'name'))
        yield ' = '
        yield to_string(t_1(environment.getattr(l_1_constant, 'value')))
        yield ','
    l_1_constant = missing
    included_template = environment.get_template('enum_definition.tmpl', 'interface_definition.tmpl')._get_default_module()
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined("the template %r (imported on line 247 in 'interface_definition.tmpl') does not export the requested name 'enum_def'" % included_template.__name__, name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    for l_1_enum in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'enums'):
        pass
        yield '\n  '
        yield to_string(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), t_2('%s.%s', environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), environment.getattr(l_1_enum, 'name')), l_1_enum))
    l_1_enum = missing
    yield '\n  '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub.prototype.validator = validate'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Request;'
    if t_3((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield '\n  '
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Proxy.prototype.validator = validate'
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Response;'
    else:
        pass
        yield '\n  '
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Proxy.prototype.validator = null;'

blocks = {}
debug_info = '1=22&2=25&4=27&7=33&8=35&12=37&14=39&17=41&18=43&19=45&20=47&22=49&26=52&27=55&29=57&30=61&34=65&35=70&36=72&39=78&40=80&41=83&44=88&45=90&47=93&48=95&49=97&52=102&53=104&54=106&60=112&62=115&63=117&65=119&68=124&69=126&71=128&77=131&87=136&91=138&92=141&93=147&97=155&100=158&101=161&103=162&104=165&105=167&106=169&107=172&108=175&118=183&122=186&123=189&125=190&126=193&127=195&128=197&129=200&130=203&133=209&134=211&135=214&137=219&139=222&140=224&143=226&147=231&148=233&150=235&166=240&167=242&173=248&174=251&176=253&177=255&179=258&182=263&193=269&194=271&200=277&201=280&203=281&204=284&206=286&217=291&218=293&219=297&220=299&221=301&222=303&223=305&224=307&225=310&229=315&230=318&232=320&233=323&235=325&236=327&243=332&244=335&247=342&248=348&249=351&251=354&252=358&253=361&255=368'