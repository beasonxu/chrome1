from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'lite/struct_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_module = resolve('module')
    l_0_generate_struct_deserializers = resolve('generate_struct_deserializers')
    l_0_generate_closure_exports = resolve('generate_closure_exports')
    l_0_enum_def = missing
    t_1 = environment.filters['constant_value']
    t_2 = environment.filters['format']
    t_3 = environment.filters['is_bool_kind']
    t_4 = environment.filters['lite_closure_field_type']
    t_5 = environment.filters['lite_closure_type_with_nullability']
    t_6 = environment.filters['lite_default_value']
    t_7 = environment.filters['lite_js_type']
    pass
    for l_1_constant in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'constants'):
        pass
        yield '\n/**\n * @const { '
        yield to_string(t_5(environment.getattr(l_1_constant, 'kind')))
        yield ' }\n * @export\n */\n'
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '_'
        yield to_string(environment.getattr(l_1_constant, 'name'))
        yield ' =\n    '
        yield to_string(t_1(l_1_constant))
        yield ';\n'
    l_1_constant = missing
    included_template = environment.get_template('lite/enum_definition.tmpl', 'lite/struct_definition.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined("the template %r (imported on line 10 in 'lite/struct_definition.tmpl') does not export the requested name 'enum_def'" % included_template.__name__, name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    yield '\n'
    for l_1_enum in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'enums'):
        pass
        yield '\n'
        yield to_string(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), t_2('%s.%sSpec', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'), environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name')), t_2('%s.%s', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'), environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name')), l_1_enum))
        yield '\n'
    l_1_enum = missing
    yield '\n\nmojo.internal.Struct(\n    '
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield "Spec.$,\n    '"
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield "',\n    ["
    for l_1_packed_field in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields_in_ordinal_order'):
        pass
        yield "\n      mojo.internal.StructField(\n        '"
        yield to_string(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name'))
        yield "', "
        yield to_string(environment.getattr(l_1_packed_field, 'offset'))
        yield ',\n        '
        if t_3(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')):
            pass
            yield to_string(environment.getattr(l_1_packed_field, 'bit'))
        else:
            pass
            yield '0'
        yield ',\n        '
        yield to_string(t_7(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')))
        yield ',\n        '
        yield to_string(t_6(environment.getattr(l_1_packed_field, 'field')))
        yield ','
        if environment.getattr(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind'), 'is_nullable'):
            pass
            yield '\n        true /* nullable */),'
        else:
            pass
            yield '\n        false /* nullable */),'
    l_1_packed_field = missing
    yield '\n    ],\n    ['
    for l_1_info in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'):
        pass
        yield '['
        yield to_string(environment.getattr(l_1_info, 'version'))
        yield ', '
        yield to_string(environment.getattr(l_1_info, 'num_bytes'))
        yield '],'
    l_1_info = missing
    yield ']);\n\n'
    if (undefined(name='generate_struct_deserializers') if l_0_generate_struct_deserializers is missing else l_0_generate_struct_deserializers):
        pass
        yield '\n'
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '_Deserialize =\n    mojo.internal.createStructDeserializer('
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield 'Spec.$);\n'
    yield '\n\n'
    if (undefined(name='generate_closure_exports') if l_0_generate_closure_exports is missing else l_0_generate_closure_exports):
        pass
        yield "goog.provide('"
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield "');"
    yield '\n\n/** @record */\n'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield ' = class {\n  constructor() {'
    for l_1_packed_field in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields'):
        pass
        yield '\n    /** @export { '
        yield to_string(t_4(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')))
        yield ' } */\n    this.'
        yield to_string(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name'))
        yield ';'
    l_1_packed_field = missing
    yield '\n  }\n};\n'

blocks = {}
debug_info = '1=23&3=26&6=28&7=34&10=37&11=44&12=47&17=51&18=55&20=57&22=60&23=64&25=71&26=73&27=75&35=83&36=86&40=92&41=95&42=99&45=104&46=107&50=112&52=116&53=119&54=121'