from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'lite/interface_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_generate_closure_exports = resolve('generate_closure_exports')
    l_0_module = resolve('module')
    l_0_interface = resolve('interface')
    l_0_mojom_namespace = resolve('mojom_namespace')
    l_0_generateMethodAnnotation = l_0_enum_def = missing
    t_1 = environment.filters['format']
    t_2 = environment.filters['length']
    t_3 = environment.filters['lite_closure_type_with_nullability']
    t_4 = environment.filters['sanitize_identifier']
    pass
    def macro(l_1_method):
        t_5 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_5.append(
            '\n  /**',
        )
        for l_2_param in environment.getattr(l_1_method, 'parameters'):
            pass
            t_5.extend((
                '\n   * @param { ',
                to_string(t_3(environment.getattr(l_2_param, 'kind'))),
                ' } ',
                to_string(t_4(environment.getattr(l_2_param, 'name'))),
            ))
        l_2_param = missing
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            if (t_2(environment.getattr(l_1_method, 'response_parameters')) == 0):
                pass
                t_5.append(
                    '\n   * @return {!Promise}',
                )
            else:
                pass
                t_5.append(
                    '\n   * @return {!Promise<{',
                )
                for l_2_response_parameter in environment.getattr(l_1_method, 'response_parameters'):
                    pass
                    t_5.extend((
                        '\n        ',
                        to_string(environment.getattr(l_2_response_parameter, 'name')),
                        ': ',
                        to_string(t_3(environment.getattr(l_2_response_parameter, 'kind'))),
                        ',',
                    ))
                l_2_response_parameter = missing
                t_5.append(
                    '\n   *  }>}',
                )
        t_5.append(
            '\n   */\n',
        )
        return concat(t_5)
    context.exported_vars.add('generateMethodAnnotation')
    context.vars['generateMethodAnnotation'] = l_0_generateMethodAnnotation = Macro(environment, macro, 'generateMethodAnnotation', ('method',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n'
    if (undefined(name='generate_closure_exports') if l_0_generate_closure_exports is missing else l_0_generate_closure_exports):
        pass
        yield "goog.provide('"
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield "');\ngoog.provide('"
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield "Receiver');\ngoog.provide('"
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield "CallbackRouter');\ngoog.provide('"
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield "Interface');\ngoog.provide('"
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield "Remote');\ngoog.provide('"
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield "PendingReceiver');\n"
    yield '\n\n/**\n * @implements {mojo.internal.interfaceSupport.PendingReceiver}\n * @export\n */\n'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield "PendingReceiver = class {\n  /**\n   * @param {!MojoHandle|!mojo.internal.interfaceSupport.Endpoint} handle\n   */\n  constructor(handle) {\n    /** @public {!mojo.internal.interfaceSupport.Endpoint} */\n    this.handle = mojo.internal.interfaceSupport.getEndpointForReceiver(handle);\n  }\n\n  /** @param {string=} scope */\n  bindInBrowser(scope = 'context') {\n    mojo.internal.interfaceSupport.bind(\n        this.handle,\n        "
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '.$interfaceName,\n        scope);\n  }\n};\n\n'
    if (undefined(name='generate_closure_exports') if l_0_generate_closure_exports is missing else l_0_generate_closure_exports):
        pass
        yield '/** @interface */\n'
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Interface = class {'
        l_1_loop = missing
        for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
            pass
            yield '\n  '
            yield to_string(context.call((undefined(name='generateMethodAnnotation') if l_0_generateMethodAnnotation is missing else l_0_generateMethodAnnotation), l_1_method))
            yield '\n  '
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '('
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
                pass
                yield to_string(t_4(environment.getattr(l_2_param, 'name')))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    yield ', '
            l_2_loop = l_2_param = missing
            yield ') {}'
        l_1_loop = l_1_method = missing
        yield '\n};'
    yield '\n\n/**\n * @export\n * @implements { '
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Interface }\n */\n'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote = class {\n  /** @param {MojoHandle|mojo.internal.interfaceSupport.Endpoint=} handle */\n  constructor(handle = undefined) {\n    /**\n     * @private {!mojo.internal.interfaceSupport.InterfaceRemoteBase<!'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>}\n     */\n    this.proxy =\n        new mojo.internal.interfaceSupport.InterfaceRemoteBase(\n          '
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver,\n          handle);\n\n    /**\n     * @public {!mojo.internal.interfaceSupport.InterfaceRemoteBaseWrapper<!'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>}\n     */\n    this.$ = new mojo.internal.interfaceSupport.InterfaceRemoteBaseWrapper(this.proxy);\n\n    /** @public {!mojo.internal.interfaceSupport.ConnectionErrorEventRouter} */\n    this.onConnectionError = this.proxy.getConnectionErrorEventRouter();\n  }'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        l_1_interface_message_id = missing
        pass
        l_1_interface_message_id = unicode_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        yield '\n\n  '
        yield to_string(context.call((undefined(name='generateMethodAnnotation') if l_0_generateMethodAnnotation is missing else l_0_generateMethodAnnotation), l_1_method))
        yield '\n  '
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield '('
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            pass
            yield '\n      '
            yield to_string(environment.getattr(l_2_param, 'name'))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_param = missing
        yield ') {'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n    return this.proxy.sendMessage('
        else:
            pass
            yield '\n    this.proxy.sendMessage('
        yield '\n        '
        yield to_string(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n        '
            yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
            yield '.'
            yield to_string((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,'
        else:
            pass
            yield '\n        null,'
        yield '\n        ['
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            pass
            yield '\n          '
            yield to_string(environment.getattr(l_2_param, 'name'))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_param = missing
        yield '\n        ]);\n  }'
    l_1_loop = l_1_method = l_1_interface_message_id = missing
    yield '\n};\n\n/**\n * An object which receives request messages for the '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '\n * mojom interface. Must be constructed over an object which implements that\n * interface.\n *\n * @export\n */\n'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Receiver = class {\n  /**\n   * @param {!'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Interface } impl\n   */\n  constructor(impl) {\n    /** @private {!mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal<!'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote>} */\n    this.helper_internal_ = new mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal(\n        '
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote);\n\n    /**\n     * @public {!mojo.internal.interfaceSupport.InterfaceReceiverHelper<!'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote>}\n     */\n    this.$ = new mojo.internal.interfaceSupport.InterfaceReceiverHelper(this.helper_internal_);\n\n'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_interface_message_id = missing
        pass
        l_1_interface_message_id = unicode_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        yield '\n    this.helper_internal_.registerHandler(\n        '
        yield to_string(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n        '
            yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
            yield '.'
            yield to_string((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,'
        else:
            pass
            yield '\n        null,'
        yield '\n        impl.'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield '.bind(impl));'
    l_1_method = l_1_interface_message_id = missing
    yield '\n    /** @public {!mojo.internal.interfaceSupport.ConnectionErrorEventRouter} */\n    this.onConnectionError = this.helper_internal_.getConnectionErrorEventRouter();\n  }\n};\n\n/**\n *  @export\n */\n'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield ' = class {\n  /**\n   * @return {!string}\n   */\n  static get $interfaceName() {\n    return "'
    yield to_string((undefined(name='mojom_namespace') if l_0_mojom_namespace is missing else l_0_mojom_namespace))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '";\n  }\n\n  /**\n   * Returns a remote for this interface which sends messages to the browser.\n   * The browser must have an interface request binder registered for this\n   * interface and accessible to the calling document\'s frame.\n   *\n   * @return {!'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote}\n   * @export\n   */\n  static getRemote() {\n    let remote = new '
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote;\n    remote.$.bindNewPipeAndPassReceiver().bindInBrowser();\n    return remote;\n  }\n};\n'
    included_template = environment.get_template('lite/enum_definition.tmpl', 'lite/interface_definition.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def, 'generateMethodAnnotation': l_0_generateMethodAnnotation})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined("the template %r (imported on line 185 in 'lite/interface_definition.tmpl') does not export the requested name 'enum_def'" % included_template.__name__, name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    for l_1_enum in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'enums'):
        pass
        yield '\n'
        yield to_string(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), t_1('%s.%s', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'), environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name')), t_1('%s.%s', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'), environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name')), l_1_enum))
    l_1_enum = missing
    yield '\n\n/**\n * An object which receives request messages for the '
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '\n * mojom interface and dispatches them as callbacks. One callback receiver exists\n * on this object for each message defined in the mojom interface, and each\n * receiver can have any number of listeners added to it.\n *\n * @export\n */\n'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'CallbackRouter = class {\n  constructor() {\n    this.helper_internal_ = new mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal(\n      '
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote);\n\n    /**\n     * @public {!mojo.internal.interfaceSupport.InterfaceReceiverHelper<!'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
    yield '.'
    yield to_string(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote>}\n     */\n    this.$ = new mojo.internal.interfaceSupport.InterfaceReceiverHelper(this.helper_internal_);\n\n    this.router_ = new mojo.internal.interfaceSupport.CallbackRouter;\n'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_interface_message_id = missing
        pass
        l_1_interface_message_id = unicode_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        yield '\n    /**\n     * @public {!mojo.internal.interfaceSupport.InterfaceCallbackReceiver}\n     */\n    this.'
        yield to_string(environment.getattr(l_1_method, 'name'))
        yield ' =\n        new mojo.internal.interfaceSupport.InterfaceCallbackReceiver(\n            this.router_);\n\n    this.helper_internal_.registerHandler(\n        '
        yield to_string(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield to_string((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n        '
            yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
            yield '.'
            yield to_string((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,\n        this.'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '.createReceiverHandler(true /* expectsResponse */));'
        else:
            pass
            yield '\n        null,\n        this.'
            yield to_string(environment.getattr(l_1_method, 'name'))
            yield '.createReceiverHandler(false /* expectsResponse */));'
    l_1_method = l_1_interface_message_id = missing
    yield '\n    /** @public {!mojo.internal.interfaceSupport.ConnectionErrorEventRouter} */\n    this.onConnectionError = this.helper_internal_.getConnectionErrorEventRouter();\n  }\n\n  /**\n   * @param {number} id An ID returned by a prior call to addListener.\n   * @return {boolean} True iff the identified listener was found and removed.\n   * @export\n   */\n  removeListener(id) {\n    return this.router_.removeListener(id);\n  }\n};'

blocks = {}
debug_info = '1=20&3=28&4=32&6=37&7=39&11=49&12=53&20=69&21=72&22=76&23=80&24=84&25=88&26=92&33=97&46=101&51=105&53=108&54=113&55=116&56=118&57=121&58=123&67=132&69=136&73=140&77=144&81=148&89=153&90=156&93=158&94=160&95=163&96=166&98=172&103=179&104=181&105=185&106=188&111=197&112=200&120=208&126=210&128=214&131=218&133=222&136=226&140=230&141=233&144=235&145=237&146=241&147=244&151=252&161=256&166=260&174=264&178=268&185=272&186=278&187=281&193=284&200=286&203=290&206=294&211=298&212=301&217=303&222=305&223=307&224=311&225=314&226=318&229=323'