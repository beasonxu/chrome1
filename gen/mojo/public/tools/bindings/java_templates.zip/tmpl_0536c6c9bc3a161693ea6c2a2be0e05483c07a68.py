from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'constants.java.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_main_entity = resolve('main_entity')
    l_0_constants = resolve('constants')
    l_0_constant_def = missing
    t_1 = environment.filters['indent']
    pass
    included_template = environment.get_template('constant_definition.tmpl', 'constants.java.tmpl')._get_default_module()
    l_0_constant_def = getattr(included_template, 'constant_def', missing)
    if l_0_constant_def is missing:
        l_0_constant_def = undefined("the template %r (imported on line 1 in 'constants.java.tmpl') does not export the requested name 'constant_def'" % included_template.__name__, name='constant_def')
    context.vars['constant_def'] = l_0_constant_def
    context.exported_vars.discard('constant_def')
    yield '\n'
    template = environment.get_template('header.java.tmpl', 'constants.java.tmpl')
    for event in template.root_render_func(template.new_context(context.get_all(), True, {'constant_def': l_0_constant_def})):
        yield event
    yield '\n\npublic final class '
    yield to_string((undefined(name='main_entity') if l_0_main_entity is missing else l_0_main_entity))
    yield ' {\n'
    for l_1_constant in (undefined(name='constants') if l_0_constants is missing else l_0_constants):
        pass
        yield '\n\n    '
        yield to_string(t_1(context.call((undefined(name='constant_def') if l_0_constant_def is missing else l_0_constant_def), l_1_constant), 4))
        yield '\n'
    l_1_constant = missing
    yield '\n\n    private '
    yield to_string((undefined(name='main_entity') if l_0_main_entity is missing else l_0_main_entity))
    yield '() {}\n\n}'

blocks = {}
debug_info = '1=15&2=22&4=26&5=28&7=31&10=35'