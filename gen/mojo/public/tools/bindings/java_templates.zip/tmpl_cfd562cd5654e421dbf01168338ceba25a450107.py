from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'constant_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_constant_def = missing
    t_1 = environment.filters['constant_value']
    t_2 = environment.filters['java_type']
    t_3 = environment.filters['name']
    pass
    def macro(l_1_constant):
        t_4 = []
        if l_1_constant is missing:
            l_1_constant = undefined("parameter 'constant' was not provided", name='constant')
        pass
        t_4.extend((
            '\npublic static final ',
            to_string(t_2(context, environment.getattr(l_1_constant, 'kind'))),
            ' ',
            to_string(t_3(l_1_constant)),
            ' = ',
            to_string(t_1(context, l_1_constant)),
            ';\n',
        ))
        return concat(t_4)
    context.exported_vars.add('constant_def')
    context.vars['constant_def'] = l_0_constant_def = Macro(environment, macro, 'constant_def', ('constant',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=15&2=22'