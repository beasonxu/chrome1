from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'enum_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_enum_def = missing
    t_1 = environment.filters['covers_continuous_range']
    t_2 = environment.filters['groupby']
    t_3 = environment.filters['name']
    t_4 = environment.tests['none']
    pass
    def macro(l_1_enum, l_1_top_level):
        t_5 = []
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        if l_1_top_level is missing:
            l_1_top_level = undefined("parameter 'top_level' was not provided", name='top_level')
        pass
        t_5.extend((
            'public ',
            to_string(('static ' if (not l_1_top_level) else cond_expr_undefined("the inline if-expression on line 2 in 'enum_definition.tmpl' evaluated to false and no else section was defined."))),
            'final class ',
            to_string(t_3(l_1_enum)),
            ' {\n    private static final boolean IS_EXTENSIBLE = ',
        ))
        if environment.getattr(l_1_enum, 'extensible'):
            pass
            t_5.append(
                'true',
            )
        else:
            pass
            t_5.append(
                'false',
            )
        t_5.append(
            ';\n    @IntDef({\n',
        )
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_enum, 'fields'), undefined):
            pass
            t_5.extend((
                '\n        ',
                to_string(t_3(l_1_enum)),
                '.',
                to_string(t_3(l_2_field)),
            ))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_5.append(
                    ',',
                )
        l_2_loop = l_2_field = missing
        t_5.append(
            '})\n    public @interface EnumType {}\n',
        )
        for l_2_field in environment.getattr(l_1_enum, 'fields'):
            pass
            t_5.extend((
                '\n    public static final int ',
                to_string(t_3(l_2_field)),
                ' = ',
                to_string(environment.getattr(l_2_field, 'numeric_value')),
                ';',
            ))
        l_2_field = missing
        if (not t_4(environment.getattr(l_1_enum, 'min_value'))):
            pass
            t_5.extend((
                '\n    public static final int MIN_VALUE = ',
                to_string(environment.getattr(l_1_enum, 'min_value')),
                ';',
            ))
        if (not t_4(environment.getattr(l_1_enum, 'max_value'))):
            pass
            t_5.extend((
                '\n    public static final int MAX_VALUE = ',
                to_string(environment.getattr(l_1_enum, 'max_value')),
                ';',
            ))
        if environment.getattr(l_1_enum, 'default_field'):
            pass
            t_5.extend((
                '\n    public static final int DEFAULT_VALUE = ',
                to_string(environment.getattr(environment.getattr(l_1_enum, 'default_field'), 'numeric_value')),
                ';',
            ))
        if t_1(l_1_enum):
            pass
            t_5.extend((
                '\n\n    public static boolean isKnownValue(int value) {\n        return value >= ',
                to_string(environment.getattr(l_1_enum, 'min_value')),
                ' && value <= ',
                to_string(environment.getattr(l_1_enum, 'max_value')),
                ';\n    }',
            ))
        else:
            pass
            t_5.append(
                '\n\n    public static boolean isKnownValue(int value) {',
            )
            if environment.getattr(l_1_enum, 'fields'):
                pass
                t_5.append(
                    '\n        switch (value) {',
                )
                for l_2_enum_field in t_2(environment, environment.getattr(l_1_enum, 'fields'), 'numeric_value'):
                    pass
                    t_5.extend((
                        '\n            case ',
                        to_string(environment.getitem(l_2_enum_field, 0)),
                        ':',
                    ))
                l_2_enum_field = missing
                t_5.append(
                    '\n                return true;\n        }',
                )
            t_5.append(
                '\n        return false;\n    }',
            )
        t_5.append(
            '\n\n    public static void validate(int value) {\n        if (IS_EXTENSIBLE || isKnownValue(value)) return;\n        throw new org.chromium.mojo.bindings.DeserializationException("Invalid enum value.");\n    }\n\n    public static int toKnownValue(int value) {',
        )
        if (environment.getattr(l_1_enum, 'extensible') and environment.getattr(l_1_enum, 'default_field')):
            pass
            t_5.append(
                '\n      if (isKnownValue(value)) {\n        return value;\n      }\n      return DEFAULT_VALUE;',
            )
        else:
            pass
            t_5.append(
                '\n      return value;',
            )
        t_5.extend((
            '\n    }\n\n    private ',
            to_string(t_3(l_1_enum)),
            '() {}\n}',
        ))
        return concat(t_5)
    context.exported_vars.add('enum_def')
    context.vars['enum_def'] = l_0_enum_def = Macro(environment, macro, 'enum_def', ('enum', 'top_level'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=16&2=25&3=30&5=44&6=48&7=52&11=61&12=65&14=71&15=75&17=78&18=82&20=85&21=89&24=92&27=96&32=106&34=111&35=115&50=128&60=140'