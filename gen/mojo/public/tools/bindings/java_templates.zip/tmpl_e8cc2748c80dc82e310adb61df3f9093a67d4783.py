from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'interface.java.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_interface_def = missing
    pass
    included_template = environment.get_template('interface_definition.tmpl', 'interface.java.tmpl')._get_default_module()
    l_0_interface_def = getattr(included_template, 'interface_def', missing)
    if l_0_interface_def is missing:
        l_0_interface_def = undefined("the template %r (imported on line 1 in 'interface.java.tmpl') does not export the requested name 'interface_def'" % included_template.__name__, name='interface_def')
    context.vars['interface_def'] = l_0_interface_def
    context.exported_vars.discard('interface_def')
    yield '\n'
    template = environment.get_template('header.java.tmpl', 'interface.java.tmpl')
    for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface_def': l_0_interface_def})):
        yield event
    yield '\n\n'
    yield to_string(context.call((undefined(name='interface_def') if l_0_interface_def is missing else l_0_interface_def), (undefined(name='interface') if l_0_interface is missing else l_0_interface)))

blocks = {}
debug_info = '1=13&2=20&4=24'