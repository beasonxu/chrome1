from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'union.java.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_union_def = missing
    pass
    included_template = environment.get_template('data_types_definition.tmpl', 'union.java.tmpl')._get_default_module()
    l_0_union_def = getattr(included_template, 'union_def', missing)
    if l_0_union_def is missing:
        l_0_union_def = undefined("the template %r (imported on line 1 in 'union.java.tmpl') does not export the requested name 'union_def'" % included_template.__name__, name='union_def')
    context.vars['union_def'] = l_0_union_def
    context.exported_vars.discard('union_def')
    yield '\n'
    template = environment.get_template('header.java.tmpl', 'union.java.tmpl')
    for event in template.root_render_func(template.new_context(context.get_all(), True, {'union_def': l_0_union_def})):
        yield event
    yield '\n\n'
    yield to_string(context.call((undefined(name='union_def') if l_0_union_def is missing else l_0_union_def), (undefined(name='union') if l_0_union is missing else l_0_union)))

blocks = {}
debug_info = '1=13&2=20&4=24'