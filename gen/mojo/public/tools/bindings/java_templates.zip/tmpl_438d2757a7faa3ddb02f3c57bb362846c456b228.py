from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'data_types_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_constant_def = l_0_enum_def = l_0_array_element_size = l_0_encode = l_0_decode = l_0_struct_def = l_0_union_def = missing
    t_1 = environment.filters['array']
    t_2 = environment.filters['array_expected_length']
    t_3 = environment.filters['decode_method']
    t_4 = environment.filters['default_value']
    t_5 = environment.filters['encode_method']
    t_6 = environment.filters['indent']
    t_7 = environment.filters['is_any_handle_kind']
    t_8 = environment.filters['is_array_kind']
    t_9 = environment.filters['is_enum_kind']
    t_10 = environment.filters['is_map_kind']
    t_11 = environment.filters['is_nullable_kind']
    t_12 = environment.filters['is_pointer_array_kind']
    t_13 = environment.filters['is_struct_kind']
    t_14 = environment.filters['is_union_array_kind']
    t_15 = environment.filters['is_union_kind']
    t_16 = environment.filters['java_class_for_enum']
    t_17 = environment.filters['java_true_false']
    t_18 = environment.filters['java_type']
    t_19 = environment.filters['length']
    t_20 = environment.filters['name']
    t_21 = environment.filters['new_array']
    t_22 = environment.filters['ucc']
    pass
    included_template = environment.get_template('constant_definition.tmpl', 'data_types_definition.tmpl')._get_default_module()
    l_0_constant_def = getattr(included_template, 'constant_def', missing)
    if l_0_constant_def is missing:
        l_0_constant_def = undefined("the template %r (imported on line 1 in 'data_types_definition.tmpl') does not export the requested name 'constant_def'" % included_template.__name__, name='constant_def')
    context.vars['constant_def'] = l_0_constant_def
    context.exported_vars.discard('constant_def')
    included_template = environment.get_template('enum_definition.tmpl', 'data_types_definition.tmpl')._get_default_module()
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined("the template %r (imported on line 2 in 'data_types_definition.tmpl') does not export the requested name 'enum_def'" % included_template.__name__, name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    def macro(l_1_kind):
        t_23 = []
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        if t_15(l_1_kind):
            pass
            t_23.append(
                '\norg.chromium.mojo.bindings.BindingsHelper.UNION_SIZE',
            )
        else:
            pass
            t_23.append(
                'org.chromium.mojo.bindings.BindingsHelper.POINTER_SIZE',
            )
        return concat(t_23)
    context.exported_vars.add('array_element_size')
    context.vars['array_element_size'] = l_0_array_element_size = Macro(environment, macro, 'array_element_size', ('kind',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_variable, l_1_kind, l_1_offset, l_1_bit, l_1_level, l_1_check_for_null):
        t_24 = []
        l_1_sub_kind = resolve('sub_kind')
        l_1_encodePointer = resolve('encodePointer')
        if l_1_variable is missing:
            l_1_variable = undefined("parameter 'variable' was not provided", name='variable')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_offset is missing:
            l_1_offset = undefined("parameter 'offset' was not provided", name='offset')
        if l_1_bit is missing:
            l_1_bit = undefined("parameter 'bit' was not provided", name='bit')
        if l_1_level is missing:
            l_1_level = 0
        if l_1_check_for_null is missing:
            l_1_check_for_null = True
        pass
        if (t_12(l_1_kind) or t_14(l_1_kind)):
            pass
            l_1_sub_kind = environment.getattr(l_1_kind, 'kind')
            if l_1_check_for_null:
                pass
                t_24.extend((
                    '\nif (',
                    to_string(l_1_variable),
                    ' == null) {\n    encoder',
                    to_string(l_1_level),
                    '.encodeNullPointer(',
                    to_string(l_1_offset),
                    ', ',
                    to_string(t_17(t_11(l_1_kind))),
                    ');\n} else {',
                ))
            else:
                pass
                t_24.append(
                    '\n{',
                )
            if t_12(l_1_kind):
                pass
                l_1_encodePointer = 'encodePointerArray'
            else:
                pass
                l_1_encodePointer = 'encodeUnionArray'
            t_24.extend((
                '\n    org.chromium.mojo.bindings.Encoder encoder',
                to_string((l_1_level + 1)),
                ' = encoder',
                to_string(l_1_level),
                '.',
                to_string((undefined(name='encodePointer') if l_1_encodePointer is missing else l_1_encodePointer)),
                '(',
                to_string(l_1_variable),
                '.length, ',
                to_string(l_1_offset),
                ', ',
                to_string(t_2(l_1_kind)),
                ');\n    for (int i',
                to_string(l_1_level),
                ' = 0; i',
                to_string(l_1_level),
                ' < ',
                to_string(l_1_variable),
                '.length; ++i',
                to_string(l_1_level),
                ') {\n        ',
                to_string(t_6(context.call((undefined(name='encode') if l_0_encode is missing else l_0_encode), unicode_join((l_1_variable, '[i', l_1_level, ']', )), (undefined(name='sub_kind') if l_1_sub_kind is missing else l_1_sub_kind), unicode_join(('org.chromium.mojo.bindings.DataHeader.HEADER_SIZE + ', context.call((undefined(name='array_element_size') if l_0_array_element_size is missing else l_0_array_element_size), (undefined(name='sub_kind') if l_1_sub_kind is missing else l_1_sub_kind)), ' * i', l_1_level, )), 0, (l_1_level + 1)), 8)),
                '\n    }\n}',
            ))
        elif t_10(l_1_kind):
            pass
            t_24.extend((
                '\nif (',
                to_string(l_1_variable),
                ' == null) {\n    encoder',
                to_string(l_1_level),
                '.encodeNullPointer(',
                to_string(l_1_offset),
                ', ',
                to_string(t_17(t_11(l_1_kind))),
                ');\n} else {\n    org.chromium.mojo.bindings.Encoder encoder',
                to_string((l_1_level + 1)),
                ' = encoder',
                to_string(l_1_level),
                '.encoderForMap(',
                to_string(l_1_offset),
                ');\n    int size',
                to_string(l_1_level),
                ' = ',
                to_string(l_1_variable),
                '.size();\n    ',
                to_string(t_18(context, environment.getattr(l_1_kind, 'key_kind'))),
                '[] keys',
                to_string(l_1_level),
                ' = ',
                to_string(t_21(context, t_1(environment.getattr(l_1_kind, 'key_kind')), unicode_join(('size', l_1_level, )))),
                ';\n    ',
                to_string(t_18(context, environment.getattr(l_1_kind, 'value_kind'))),
                '[] values',
                to_string(l_1_level),
                ' = ',
                to_string(t_21(context, t_1(environment.getattr(l_1_kind, 'value_kind')), unicode_join(('size', l_1_level, )))),
                ';\n    int index',
                to_string(l_1_level),
                ' = 0;\n    for (java.util.Map.Entry<',
                to_string(t_18(context, environment.getattr(l_1_kind, 'key_kind'), True)),
                ', ',
                to_string(t_18(context, environment.getattr(l_1_kind, 'value_kind'), True)),
                '> entry',
                to_string(l_1_level),
                ' : ',
                to_string(l_1_variable),
                '.entrySet()) {\n        keys',
                to_string(l_1_level),
                '[index',
                to_string(l_1_level),
                '] = entry',
                to_string(l_1_level),
                '.getKey();\n        values',
                to_string(l_1_level),
                '[index',
                to_string(l_1_level),
                '] = entry',
                to_string(l_1_level),
                '.getValue();\n        ++index',
                to_string(l_1_level),
                ';\n    }\n    ',
                to_string(t_6(context.call((undefined(name='encode') if l_0_encode is missing else l_0_encode), unicode_join(('keys', l_1_level, )), t_1(environment.getattr(l_1_kind, 'key_kind')), 'org.chromium.mojo.bindings.DataHeader.HEADER_SIZE', 0, (l_1_level + 1), False), 4)),
                '\n    ',
                to_string(t_6(context.call((undefined(name='encode') if l_0_encode is missing else l_0_encode), unicode_join(('values', l_1_level, )), t_1(environment.getattr(l_1_kind, 'value_kind')), 'org.chromium.mojo.bindings.DataHeader.HEADER_SIZE + org.chromium.mojo.bindings.BindingsHelper.POINTER_SIZE', 0, (l_1_level + 1), False), 4)),
                '\n}',
            ))
        else:
            pass
            t_24.extend((
                '\nencoder',
                to_string(l_1_level),
                '.',
                to_string(t_5(context, l_1_kind, l_1_variable, l_1_offset, l_1_bit)),
                ';',
            ))
        return concat(t_24)
    context.exported_vars.add('encode')
    context.vars['encode'] = l_0_encode = Macro(environment, macro, 'encode', ('variable', 'kind', 'offset', 'bit', 'level', 'check_for_null'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_variable, l_1_kind, l_1_offset, l_1_bit, l_1_level):
        t_25 = []
        if l_1_variable is missing:
            l_1_variable = undefined("parameter 'variable' was not provided", name='variable')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_offset is missing:
            l_1_offset = undefined("parameter 'offset' was not provided", name='offset')
        if l_1_bit is missing:
            l_1_bit = undefined("parameter 'bit' was not provided", name='bit')
        if l_1_level is missing:
            l_1_level = 0
        pass
        if (((t_13(l_1_kind) or t_12(l_1_kind)) or t_14(l_1_kind)) or t_10(l_1_kind)):
            pass
            t_25.extend((
                '\norg.chromium.mojo.bindings.Decoder decoder',
                to_string((l_1_level + 1)),
                ' = decoder',
                to_string(l_1_level),
                '.readPointer(',
                to_string(l_1_offset),
                ', ',
                to_string(t_17(t_11(l_1_kind))),
                ');',
            ))
            if t_13(l_1_kind):
                pass
                t_25.extend((
                    '\n',
                    to_string(l_1_variable),
                    ' = ',
                    to_string(t_18(context, l_1_kind)),
                    '.decode(decoder',
                    to_string((l_1_level + 1)),
                    ');',
                ))
            else:
                pass
                if t_11(l_1_kind):
                    pass
                    t_25.extend((
                        '\nif (decoder',
                        to_string((l_1_level + 1)),
                        ' == null) {\n    ',
                        to_string(l_1_variable),
                        ' = null;\n} else {',
                    ))
                else:
                    pass
                    t_25.append(
                        '\n{',
                    )
                if t_10(l_1_kind):
                    pass
                    t_25.extend((
                        '\n    decoder',
                        to_string((l_1_level + 1)),
                        '.readDataHeaderForMap();\n    ',
                        to_string(t_18(context, environment.getattr(l_1_kind, 'key_kind'))),
                        '[] keys',
                        to_string(l_1_level),
                        ';\n    ',
                        to_string(t_18(context, environment.getattr(l_1_kind, 'value_kind'))),
                        '[] values',
                        to_string(l_1_level),
                        ';\n    {\n        ',
                        to_string(t_6(context.call((undefined(name='decode') if l_0_decode is missing else l_0_decode), unicode_join(('keys', l_1_level, )), t_1(environment.getattr(l_1_kind, 'key_kind')), 'org.chromium.mojo.bindings.DataHeader.HEADER_SIZE', 0, (l_1_level + 1)), 8)),
                        '\n    }\n    {\n        ',
                        to_string(t_6(context.call((undefined(name='decode') if l_0_decode is missing else l_0_decode), unicode_join(('values', l_1_level, )), t_1(environment.getattr(l_1_kind, 'value_kind'), unicode_join(('keys', l_1_level, '.length', ))), 'org.chromium.mojo.bindings.DataHeader.HEADER_SIZE + org.chromium.mojo.bindings.BindingsHelper.POINTER_SIZE', 0, (l_1_level + 1)), 8)),
                        '\n    }\n    ',
                        to_string(l_1_variable),
                        ' = new java.util.HashMap<',
                        to_string(t_18(context, environment.getattr(l_1_kind, 'key_kind'), True)),
                        ', ',
                        to_string(t_18(context, environment.getattr(l_1_kind, 'value_kind'), True)),
                        '>();\n    for (int index',
                        to_string(l_1_level),
                        ' = 0; index',
                        to_string(l_1_level),
                        ' < keys',
                        to_string(l_1_level),
                        '.length; ++index',
                        to_string(l_1_level),
                        ') {\n        ',
                        to_string(l_1_variable),
                        '.put(keys',
                        to_string(l_1_level),
                        '[index',
                        to_string(l_1_level),
                        '],  values',
                        to_string(l_1_level),
                        '[index',
                        to_string(l_1_level),
                        ']);\n    }',
                    ))
                else:
                    pass
                    t_25.extend((
                        '\n    org.chromium.mojo.bindings.DataHeader si',
                        to_string((l_1_level + 1)),
                        ' = decoder',
                        to_string((l_1_level + 1)),
                        '.readDataHeaderForPointerArray(',
                        to_string(t_2(l_1_kind)),
                        ');\n    ',
                        to_string(l_1_variable),
                        ' = ',
                        to_string(t_21(context, l_1_kind, unicode_join(('si', (l_1_level + 1), '.elementsOrVersion', )))),
                        ';\n    for (int i',
                        to_string((l_1_level + 1)),
                        ' = 0; i',
                        to_string((l_1_level + 1)),
                        ' < si',
                        to_string((l_1_level + 1)),
                        '.elementsOrVersion; ++i',
                        to_string((l_1_level + 1)),
                        ') {\n        ',
                        to_string(t_6(context.call((undefined(name='decode') if l_0_decode is missing else l_0_decode), unicode_join((l_1_variable, '[i', (l_1_level + 1), ']', )), environment.getattr(l_1_kind, 'kind'), unicode_join(('org.chromium.mojo.bindings.DataHeader.HEADER_SIZE + ', context.call((undefined(name='array_element_size') if l_0_array_element_size is missing else l_0_array_element_size), environment.getattr(l_1_kind, 'kind')), ' * i', (l_1_level + 1), )), 0, (l_1_level + 1)), 8)),
                        '\n    }',
                    ))
                t_25.append(
                    '\n}',
                )
        elif t_15(l_1_kind):
            pass
            t_25.extend((
                '\n',
                to_string(l_1_variable),
                ' = ',
                to_string(t_18(context, l_1_kind)),
                '.decode(decoder',
                to_string(l_1_level),
                ', ',
                to_string(l_1_offset),
                ');',
            ))
        else:
            pass
            t_25.extend((
                '\n',
                to_string(l_1_variable),
                ' = decoder',
                to_string(l_1_level),
                '.',
                to_string(t_3(context, l_1_kind, l_1_offset, l_1_bit)),
                ';',
            ))
            if (t_8(l_1_kind) and t_9(environment.getattr(l_1_kind, 'kind'))):
                pass
                if t_11(l_1_kind):
                    pass
                    t_25.extend((
                        '\nif (',
                        to_string(l_1_variable),
                        ' != null) {',
                    ))
                else:
                    pass
                    t_25.append(
                        '\n{',
                    )
                t_25.extend((
                    '\n    for (int i',
                    to_string((l_1_level + 1)),
                    ' = 0; i',
                    to_string((l_1_level + 1)),
                    ' < ',
                    to_string(l_1_variable),
                    '.length; ++i',
                    to_string((l_1_level + 1)),
                    ') {\n        ',
                    to_string(t_16(context, environment.getattr(l_1_kind, 'kind'))),
                    '.validate(',
                    to_string(l_1_variable),
                    '[i',
                    to_string((l_1_level + 1)),
                    ']);\n    }\n}',
                ))
            elif t_9(l_1_kind):
                pass
                t_25.extend((
                    '\n    ',
                    to_string(t_16(context, l_1_kind)),
                    '.validate(',
                    to_string(l_1_variable),
                    ');\n    ',
                    to_string(l_1_variable),
                    ' = ',
                    to_string(t_16(context, l_1_kind)),
                    '.toKnownValue(',
                    to_string(l_1_variable),
                    ');',
                ))
        return concat(t_25)
    context.exported_vars.add('decode')
    context.vars['decode'] = l_0_decode = Macro(environment, macro, 'decode', ('variable', 'kind', 'offset', 'bit', 'level'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_struct, l_1_inner_class):
        t_26 = []
        l_1_prev_ver = missing
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        if l_1_inner_class is missing:
            l_1_inner_class = False
        pass
        t_26.extend((
            '\n',
            to_string(('static' if l_1_inner_class else 'public')),
            ' final class ',
            to_string(t_20(l_1_struct)),
            ' extends org.chromium.mojo.bindings.Struct {\n\n    private static final int STRUCT_SIZE = ',
            to_string(environment.getattr(environment.getitem(environment.getattr(l_1_struct, 'versions'), -1), 'num_bytes')),
            ';\n    private static final org.chromium.mojo.bindings.DataHeader[] VERSION_ARRAY = new org.chromium.mojo.bindings.DataHeader[] {',
        ))
        l_2_loop = missing
        for l_2_version, l_2_loop in LoopContext(environment.getattr(l_1_struct, 'versions'), undefined):
            pass
            t_26.extend((
                'new org.chromium.mojo.bindings.DataHeader(',
                to_string(environment.getattr(l_2_version, 'num_bytes')),
                ', ',
                to_string(environment.getattr(l_2_version, 'version')),
                ')',
            ))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_26.append(
                    ',',
                )
        l_2_loop = l_2_version = missing
        t_26.extend((
            '};\n    private static final org.chromium.mojo.bindings.DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[',
            to_string((t_19(environment.getattr(l_1_struct, 'versions')) - 1)),
            '];',
        ))
        for l_2_constant in environment.getattr(l_1_struct, 'constants'):
            pass
            t_26.extend((
                '\n\n    ',
                to_string(t_6(context.call((undefined(name='constant_def') if l_0_constant_def is missing else l_0_constant_def), l_2_constant), 4)),
            ))
        l_2_constant = missing
        for l_2_enum in environment.getattr(l_1_struct, 'enums'):
            pass
            t_26.extend((
                '\n\n    ',
                to_string(t_6(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), l_2_enum, False), 4)),
            ))
        l_2_enum = missing
        if environment.getattr(l_1_struct, 'fields'):
            pass
            for l_2_field in environment.getattr(l_1_struct, 'fields'):
                pass
                t_26.extend((
                    '\n    public ',
                    to_string(t_18(context, environment.getattr(l_2_field, 'kind'))),
                    ' ',
                    to_string(t_20(l_2_field)),
                    ';',
                ))
            l_2_field = missing
        t_26.extend((
            '\n\n    private ',
            to_string(t_20(l_1_struct)),
            '(int version) {\n        super(STRUCT_SIZE, version);',
        ))
        for l_2_field in environment.getattr(l_1_struct, 'fields'):
            pass
            if environment.getattr(l_2_field, 'default'):
                pass
                t_26.extend((
                    '\n        this.',
                    to_string(t_20(l_2_field)),
                    ' = ',
                    to_string(t_4(context, l_2_field)),
                    ';',
                ))
            elif t_7(environment.getattr(l_2_field, 'kind')):
                pass
                t_26.extend((
                    '\n        this.',
                    to_string(t_20(l_2_field)),
                    ' = org.chromium.mojo.system.InvalidHandle.INSTANCE;',
                ))
        l_2_field = missing
        t_26.extend((
            '\n    }\n\n    public ',
            to_string(t_20(l_1_struct)),
            '() {\n        this(',
            to_string(environment.getattr(environment.getitem(environment.getattr(l_1_struct, 'versions'), -1), 'version')),
            ');\n    }\n\n    public static ',
            to_string(t_20(l_1_struct)),
            ' deserialize(org.chromium.mojo.bindings.Message message) {\n        return decode(new org.chromium.mojo.bindings.Decoder(message));\n    }\n\n    /**\n     * Similar to the method above, but deserializes from a |ByteBuffer| instance.\n     *\n     * @throws org.chromium.mojo.bindings.DeserializationException on deserialization failure.\n     */\n    public static ',
            to_string(t_20(l_1_struct)),
            ' deserialize(java.nio.ByteBuffer data) {\n        return deserialize(new org.chromium.mojo.bindings.Message(\n                data, new java.util.ArrayList<org.chromium.mojo.system.Handle>()));\n    }\n\n    @SuppressWarnings("unchecked")\n    public static ',
            to_string(t_20(l_1_struct)),
            ' decode(org.chromium.mojo.bindings.Decoder decoder0) {\n        if (decoder0 == null) {\n            return null;\n        }\n        decoder0.increaseStackDepth();\n        ',
            to_string(t_20(l_1_struct)),
            ' result;\n        try {\n            org.chromium.mojo.bindings.DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);\n            final int elementsOrVersion = mainDataHeader.elementsOrVersion;\n            result = new ',
            to_string(t_20(l_1_struct)),
            '(elementsOrVersion);',
        ))
        l_1_prev_ver = [0]
        for l_2_byte in environment.getattr(l_1_struct, 'bytes'):
            pass
            for l_3_packed_field in environment.getattr(l_2_byte, 'packed_fields'):
                l_3__ = resolve('_')
                pass
                if (environment.getattr(l_3_packed_field, 'min_version') != environment.getitem((undefined(name='prev_ver') if l_1_prev_ver is missing else l_1_prev_ver), -1)):
                    pass
                    if (environment.getitem((undefined(name='prev_ver') if l_1_prev_ver is missing else l_1_prev_ver), -1) != 0):
                        pass
                        t_26.append(
                            '\n            }',
                        )
                    l_3__ = context.call(environment.getattr((undefined(name='prev_ver') if l_1_prev_ver is missing else l_1_prev_ver), 'append'), environment.getattr(l_3_packed_field, 'min_version'))
                    if (environment.getitem((undefined(name='prev_ver') if l_1_prev_ver is missing else l_1_prev_ver), -1) != 0):
                        pass
                        t_26.extend((
                            '\n            if (elementsOrVersion >= ',
                            to_string(environment.getattr(l_3_packed_field, 'min_version')),
                            ') {',
                        ))
                t_26.extend((
                    '\n                {\n                    ',
                    to_string(t_6(context.call((undefined(name='decode') if l_0_decode is missing else l_0_decode), unicode_join(('result.', t_20(environment.getattr(l_3_packed_field, 'field')), )), environment.getattr(environment.getattr(l_3_packed_field, 'field'), 'kind'), (8 + environment.getattr(l_3_packed_field, 'offset')), environment.getattr(l_3_packed_field, 'bit')), 16)),
                    '\n                }',
                ))
            l_3_packed_field = l_3__ = missing
        l_2_byte = missing
        if (environment.getitem((undefined(name='prev_ver') if l_1_prev_ver is missing else l_1_prev_ver), -1) != 0):
            pass
            t_26.append(
                '\n            }',
            )
        t_26.append(
            '\n\n        } finally {\n            decoder0.decreaseStackDepth();\n        }\n        return result;\n    }\n\n    @SuppressWarnings("unchecked")\n    @Override\n    protected final void encode(org.chromium.mojo.bindings.Encoder encoder) {',
        )
        if (not environment.getattr(l_1_struct, 'bytes')):
            pass
            t_26.append(
                '\n        encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);',
            )
        else:
            pass
            t_26.append(
                '\n        org.chromium.mojo.bindings.Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);',
            )
        for l_2_byte in environment.getattr(l_1_struct, 'bytes'):
            pass
            for l_3_packed_field in environment.getattr(l_2_byte, 'packed_fields'):
                pass
                t_26.extend((
                    '\n        ',
                    to_string(t_6(context.call((undefined(name='encode') if l_0_encode is missing else l_0_encode), unicode_join(('this.', t_20(environment.getattr(l_3_packed_field, 'field')), )), environment.getattr(environment.getattr(l_3_packed_field, 'field'), 'kind'), (8 + environment.getattr(l_3_packed_field, 'offset')), environment.getattr(l_3_packed_field, 'bit')), 8)),
                ))
            l_3_packed_field = missing
        l_2_byte = missing
        t_26.append(
            '\n    }\n}',
        )
        return concat(t_26)
    context.exported_vars.add('struct_def')
    context.vars['struct_def'] = l_0_struct_def = Macro(environment, macro, 'struct_def', ('struct', 'inner_class'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_union):
        t_27 = []
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        pass
        t_27.extend((
            '\npublic final class ',
            to_string(t_20(l_1_union)),
            ' extends org.chromium.mojo.bindings.Union {\n\n    public static final class Tag {',
        ))
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_union, 'fields'), undefined):
            pass
            t_27.extend((
                '\n        public static final int ',
                to_string(t_22(l_2_field)),
                ' = ',
                to_string(environment.getattr(l_2_loop, 'index0')),
                ';',
            ))
        l_2_loop = l_2_field = missing
        t_27.append(
            '\n    };',
        )
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            pass
            t_27.extend((
                '\n    private ',
                to_string(t_18(context, environment.getattr(l_2_field, 'kind'))),
                ' m',
                to_string(t_22(l_2_field)),
                ';',
            ))
        l_2_field = missing
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            pass
            t_27.extend((
                '\n\n    public void set',
                to_string(t_22(l_2_field)),
                '(',
                to_string(t_18(context, environment.getattr(l_2_field, 'kind'))),
                ' ',
                to_string(t_20(l_2_field)),
                ') {\n        this.mTag = Tag.',
                to_string(t_22(l_2_field)),
                ';\n        this.m',
                to_string(t_22(l_2_field)),
                ' = ',
                to_string(t_20(l_2_field)),
                ';\n    }\n\n    public ',
                to_string(t_18(context, environment.getattr(l_2_field, 'kind'))),
                ' get',
                to_string(t_22(l_2_field)),
                '() {\n        assert this.mTag == Tag.',
                to_string(t_22(l_2_field)),
                ';\n        return this.m',
                to_string(t_22(l_2_field)),
                ';\n    }',
            ))
        l_2_field = missing
        t_27.append(
            '\n\n\n    @Override\n    protected final void encode(org.chromium.mojo.bindings.Encoder encoder0, int offset) {\n        encoder0.encode(org.chromium.mojo.bindings.BindingsHelper.UNION_SIZE, offset);\n        encoder0.encode(this.mTag, offset + 4);\n        switch (mTag) {',
        )
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            pass
            t_27.extend((
                '\n            case Tag.',
                to_string(t_22(l_2_field)),
                ': {',
            ))
            if t_15(environment.getattr(l_2_field, 'kind')):
                pass
                t_27.extend((
                    '\n                if (this.m',
                    to_string(t_22(l_2_field)),
                    ' == null) {\n                    encoder0.encodeNullPointer(offset + 8, ',
                    to_string(t_17(t_11(environment.getattr(l_2_field, 'kind')))),
                    ');\n                } else {\n                    encoder0.encoderForUnionPointer(offset + 8).encode(\n                        this.m',
                    to_string(t_22(l_2_field)),
                    ', 0, ',
                    to_string(t_17(t_11(environment.getattr(l_2_field, 'kind')))),
                    ');\n                }',
                ))
            else:
                pass
                t_27.extend((
                    '\n                ',
                    to_string(t_6(context.call((undefined(name='encode') if l_0_encode is missing else l_0_encode), unicode_join(('this.m', t_22(l_2_field), )), environment.getattr(l_2_field, 'kind'), 'offset + 8', 0), 16)),
                ))
            t_27.append(
                '\n                break;\n            }',
            )
        l_2_field = missing
        t_27.extend((
            '\n            default: {\n                break;\n            }\n        }\n    }\n\n    public static ',
            to_string(t_20(l_1_union)),
            ' deserialize(org.chromium.mojo.bindings.Message message) {\n        return decode(new org.chromium.mojo.bindings.Decoder(message).decoderForSerializedUnion(), 0);\n    }\n\n    public static final ',
            to_string(t_20(l_1_union)),
            ' decode(org.chromium.mojo.bindings.Decoder decoder0, int offset) {\n        org.chromium.mojo.bindings.DataHeader dataHeader = decoder0.readDataHeaderForUnion(offset);\n        if (dataHeader.size == 0) {\n            return null;\n        }\n        ',
            to_string(t_20(l_1_union)),
            ' result = new ',
            to_string(t_20(l_1_union)),
            '();\n        switch (dataHeader.elementsOrVersion) {',
        ))
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            pass
            t_27.extend((
                '\n            case Tag.',
                to_string(t_22(l_2_field)),
                ': {',
            ))
            if t_15(environment.getattr(l_2_field, 'kind')):
                pass
                t_27.extend((
                    '\n                org.chromium.mojo.bindings.Decoder decoder1 = decoder0.readPointer(offset + org.chromium.mojo.bindings.DataHeader.HEADER_SIZE, ',
                    to_string(t_17(t_11(environment.getattr(l_2_field, 'kind')))),
                    ');\n                if (decoder1 != null) {\n                    result.m',
                    to_string(t_22(l_2_field)),
                    ' = ',
                    to_string(t_18(context, environment.getattr(l_2_field, 'kind'))),
                    '.decode(decoder1, 0);\n                }',
                ))
            else:
                pass
                t_27.extend((
                    '\n                ',
                    to_string(t_6(context.call((undefined(name='decode') if l_0_decode is missing else l_0_decode), unicode_join(('result.m', t_22(l_2_field), )), environment.getattr(l_2_field, 'kind'), 'offset + org.chromium.mojo.bindings.DataHeader.HEADER_SIZE', 0), 16)),
                ))
            t_27.extend((
                '\n                result.mTag = Tag.',
                to_string(t_22(l_2_field)),
                ';\n                break;\n            }',
            ))
        l_2_field = missing
        t_27.append(
            '\n            default: {\n                break;\n            }\n        }\n        return result;\n    }\n}',
        )
        return concat(t_27)
    context.exported_vars.add('union_def')
    context.vars['union_def'] = l_0_union_def = Macro(environment, macro, 'union_def', ('union',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=34&2=40&4=46&5=51&12=64&13=81&14=83&15=84&16=88&17=90&22=102&23=104&25=107&27=110&28=122&29=130&32=133&33=137&34=139&36=145&37=151&38=155&39=161&40=167&41=169&42=177&43=183&44=189&46=191&47=193&50=200&54=208&55=221&59=225&60=234&61=238&63=247&64=251&65=253&70=261&71=265&72=267&73=271&75=275&78=277&80=279&81=285&82=293&85=308&86=314&87=318&88=326&93=332&94=336&96=349&97=356&98=358&99=362&103=372&104=380&107=387&108=391&109=395&114=405&115=415&117=419&119=423&120=427&123=440&124=443&126=447&128=450&130=454&132=457&134=459&135=463&139=471&141=474&142=476&143=480&144=485&145=489&150=495&151=497&154=499&163=501&169=503&174=505&178=507&180=510&181=511&182=513&183=516&184=518&187=523&188=524&189=528&193=533&197=538&210=546&215=556&216=558&217=562&225=572&226=579&229=583&230=587&234=596&235=600&238=606&240=610&241=616&242=618&245=622&246=626&247=628&257=635&258=639&259=642&260=646&261=648&264=650&267=659&278=667&282=669&287=671&289=676&290=680&291=683&292=687&294=689&297=698&299=702'