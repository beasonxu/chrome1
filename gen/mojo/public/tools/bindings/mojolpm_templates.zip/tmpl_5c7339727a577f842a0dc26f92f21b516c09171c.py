from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'mojolpm_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_not_null = l_0_value = l_0_add_instance = missing
    t_1 = environment.filters['cpp_wrapper_proto_type']
    t_2 = environment.filters['cpp_wrapper_type']
    t_3 = environment.filters['get_qualified_name_for_kind']
    t_4 = environment.filters['indent']
    t_5 = environment.filters['is_any_handle_kind']
    t_6 = environment.filters['is_array_kind']
    t_7 = environment.filters['is_map_kind']
    t_8 = environment.filters['is_move_only_kind']
    t_9 = environment.filters['is_nullable_kind']
    t_10 = environment.filters['is_pending_associated_remote_kind']
    t_11 = environment.filters['is_pending_remote_kind']
    t_12 = environment.filters['is_platform_handle_kind']
    t_13 = environment.filters['is_struct_kind']
    t_14 = environment.filters['is_typemapped_kind']
    t_15 = environment.filters['nullable_is_same_kind']
    t_16 = environment.filters['truncate']
    pass
    def macro(l_1_kind, l_1_name):
        t_17 = []
        l_1_data_view = resolve('data_view')
        l_1_data_type = resolve('data_type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if ((t_14(l_1_kind) and t_13(l_1_kind)) and t_15(l_1_kind)):
            pass
            l_1_data_view = unicode_join((t_3(l_1_kind), 'DataView', ))
            l_1_data_type = t_2(l_1_kind, ignore_nullable=True)
            if (t_16(environment, (undefined(name='data_type') if l_1_data_type is missing else l_1_data_type), 16, True, '', 0) == '::scoped_refptr<'):
                pass
                t_17.extend((
                    '\n',
                    to_string(l_1_name),
                ))
            else:
                pass
                t_17.extend((
                    '\n!::mojo::internal::CallIsNullIfExists<::mojo::StructTraits<',
                    to_string((undefined(name='data_view') if l_1_data_view is missing else l_1_data_view)),
                    ', ',
                    to_string((undefined(name='data_type') if l_1_data_type is missing else l_1_data_type)),
                    '>>(',
                    to_string(l_1_name),
                    ')',
                ))
        elif t_12(l_1_kind):
            pass
            t_17.extend((
                to_string(l_1_name),
                '.is_valid()',
            ))
        else:
            pass
            t_17.append(
                to_string(l_1_name),
            )
        return concat(t_17)
    context.exported_vars.add('not_null')
    context.vars['not_null'] = l_0_not_null = Macro(environment, macro, 'not_null', ('kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_kind, l_1_name):
        t_18 = []
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (t_9(l_1_kind) and (not t_15(l_1_kind))):
            pass
            t_18.extend((
                '*',
                to_string(l_1_name),
            ))
        else:
            pass
            t_18.append(
                to_string(l_1_name),
            )
        return concat(t_18)
    context.exported_vars.add('value')
    context.vars['value'] = l_0_value = Macro(environment, macro, 'value', ('kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_kind, l_1_name, l_1_nested):
        t_19 = []
        l_1_mojom_type = resolve('mojom_type')
        l_1_proto_type = resolve('proto_type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        if l_1_nested is missing:
            l_1_nested = undefined("parameter 'nested' was not provided", name='nested')
        pass
        if t_6(l_1_kind):
            pass
            t_19.extend((
                '\n  for (auto& ',
                to_string(l_1_name),
                '_iter : ',
                to_string(context.call((undefined(name='value') if l_0_value is missing else l_0_value), l_1_kind, l_1_name)),
                ') {\n',
                to_string(t_4(context.call((undefined(name='add_instance') if l_0_add_instance is missing else l_0_add_instance), environment.getattr(l_1_kind, 'kind'), unicode_join((l_1_name, '_iter', )), True), 2, True)),
                '\n  }',
            ))
        elif t_7(l_1_kind):
            pass
            t_19.extend((
                '\n  for (auto& ',
                to_string(l_1_name),
                '_iter : ',
                to_string(context.call((undefined(name='value') if l_0_value is missing else l_0_value), l_1_kind, l_1_name)),
                ') {\n    auto& ',
                to_string(l_1_name),
                '_key = ',
                to_string(l_1_name),
                '_iter.first;\n    auto& ',
                to_string(l_1_name),
                '_value = ',
                to_string(l_1_name),
                '_iter.second;\n',
                to_string(t_4(context.call((undefined(name='add_instance') if l_0_add_instance is missing else l_0_add_instance), environment.getattr(l_1_kind, 'key_kind'), unicode_join((l_1_name, '_key', )), True), 2, True)),
                '\n',
                to_string(t_4(context.call((undefined(name='add_instance') if l_0_add_instance is missing else l_0_add_instance), environment.getattr(l_1_kind, 'value_kind'), unicode_join((l_1_name, '_value', )), True), 2, True)),
                '\n  }',
            ))
        elif t_11(l_1_kind):
            pass
            l_1_mojom_type = t_3(environment.getattr(l_1_kind, 'kind'), flatten_nested_kind=True)
            t_19.extend((
                '\n  if (',
                to_string(l_1_name),
                ') {\n    ::mojo::Remote<',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '> tmp_',
                to_string(l_1_name),
                '(std::move(',
                to_string(l_1_name),
                '));\n    mojolpm::GetContext()->AddInstance(std::move(tmp_',
                to_string(l_1_name),
                '));\n  }',
            ))
        elif t_10(l_1_kind):
            pass
            l_1_mojom_type = t_3(environment.getattr(l_1_kind, 'kind'), flatten_nested_kind=True)
            t_19.extend((
                '\n  if (',
                to_string(l_1_name),
                ') {\n    ::mojo::AssociatedRemote<',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '> tmp_',
                to_string(l_1_name),
                '(std::move(',
                to_string(l_1_name),
                '));\n    mojolpm::GetContext()->AddInstance(std::move(tmp_',
                to_string(l_1_name),
                '));\n  }',
            ))
        elif t_5(l_1_kind):
            pass
            t_19.extend((
                '\n  mojolpm::GetContext()->AddInstance(std::move(',
                to_string(l_1_name),
                '));',
            ))
        else:
            pass
            if t_9(l_1_kind):
                pass
                l_1_proto_type = t_1(l_1_kind, add_same_module_namespaces=True)
                t_19.extend((
                    '\n  ',
                    to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
                    ' tmp_',
                    to_string(l_1_name),
                    ';\n  if (',
                    to_string(context.call((undefined(name='not_null') if l_0_not_null is missing else l_0_not_null), l_1_kind, l_1_name)),
                    ') {',
                ))
                if t_8(l_1_kind):
                    pass
                    t_19.extend((
                        '\n    if (ToProto(std::move(',
                        to_string(context.call((undefined(name='value') if l_0_value is missing else l_0_value), l_1_kind, l_1_name)),
                        '), tmp_',
                        to_string(l_1_name),
                        ')) {',
                    ))
                else:
                    pass
                    t_19.extend((
                        '\n    if (ToProto(',
                        to_string(context.call((undefined(name='value') if l_0_value is missing else l_0_value), l_1_kind, l_1_name)),
                        ', tmp_',
                        to_string(l_1_name),
                        ')) {',
                    ))
                t_19.extend((
                    '\n      mojolpm::GetContext()->AddInstance(tmp_',
                    to_string(l_1_name),
                    ');\n    }\n  }',
                ))
            else:
                pass
                l_1_proto_type = t_1(l_1_kind, add_same_module_namespaces=True)
                t_19.extend((
                    '\n  ',
                    to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
                    ' tmp_',
                    to_string(l_1_name),
                    ';',
                ))
                if t_8(l_1_kind):
                    pass
                    t_19.extend((
                        '\n  if (ToProto(std::move(',
                        to_string(l_1_name),
                        '), tmp_',
                        to_string(l_1_name),
                        ')) {',
                    ))
                else:
                    pass
                    t_19.extend((
                        '\n  if (ToProto(',
                        to_string(l_1_name),
                        ', tmp_',
                        to_string(l_1_name),
                        ')) {',
                    ))
                t_19.extend((
                    '\n    mojolpm::GetContext()->AddInstance(tmp_',
                    to_string(l_1_name),
                    ');\n  }',
                ))
        return concat(t_19)
    context.exported_vars.add('add_instance')
    context.vars['add_instance'] = l_0_add_instance = Macro(environment, macro, 'add_instance', ('kind', 'name', 'nested'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=28&2=37&3=39&4=40&5=41&6=45&8=51&10=58&11=67&15=72&16=79&17=88&21=93&22=104&23=108&24=112&26=115&27=119&28=123&29=127&30=131&31=133&33=136&34=138&35=141&36=143&37=149&39=152&40=154&41=157&42=159&43=165&45=168&46=172&48=177&49=179&50=182&51=186&52=189&53=193&55=202&57=209&61=214&62=217&63=222&64=226&66=235&68=242'