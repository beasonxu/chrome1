from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'mojolpm_traits_specialization_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_util = l_0_define_struct = l_0_define_union = missing
    t_1 = environment.filters['camel_to_under']
    t_2 = environment.filters['cpp_wrapper_type']
    t_3 = environment.filters['get_qualified_name_for_kind']
    t_4 = environment.filters['is_nullable_kind']
    t_5 = environment.filters['is_typemapped_kind']
    t_6 = environment.filters['nullable_is_same_kind']
    t_7 = environment.filters['under_to_camel']
    pass
    l_0_util = context.vars['util'] = environment.get_template('mojolpm_macros.tmpl', 'mojolpm_traits_specialization_macros.tmpl')._get_default_module()
    context.exported_vars.discard('util')
    def macro(l_1_struct):
        t_8 = []
        l_1_mojom_type = l_1_proto_type = l_1_struct_type = l_1_dataview_type = missing
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        pass
        l_1_mojom_type = t_2(l_1_struct, add_same_module_namespaces=True)
        l_1_proto_type = unicode_join(('::mojolpm', t_3(l_1_struct, flatten_nested_kind=True), ))
        l_1_struct_type = unicode_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoStruct', ))
        l_1_dataview_type = unicode_join((t_3(l_1_struct, flatten_nested_kind=True), 'DataView', ))
        t_8.extend((
            '\ntemplate <>\nstruct StructTraits<',
            to_string((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
            ', ',
            to_string((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
            '> {',
        ))
        for l_2_field in environment.getattr(l_1_struct, 'fields'):
            l_2_field_mojom_type = resolve('field_mojom_type')
            l_2_field_maybe_mojom_type = resolve('field_maybe_mojom_type')
            l_2_name = l_2_kind = missing
            pass
            l_2_name = t_1(environment.getattr(l_2_field, 'name'))
            l_2_kind = environment.getattr(l_2_field, 'kind')
            if (t_4(environment.getattr(l_2_field, 'kind')) and (not t_6(environment.getattr(l_2_field, 'kind')))):
                pass
                l_2_field_mojom_type = t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)
                l_2_field_maybe_mojom_type = t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True, ignore_nullable=True)
                t_8.extend((
                    '\n  static ',
                    to_string((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                    ' ',
                    to_string(environment.getattr(l_2_field, 'name')),
                    '(\n      const ',
                    to_string((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
                    '& input) {\n    ',
                    to_string((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                    ' maybe_local_',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ';\n    ',
                    to_string((undefined(name='field_maybe_mojom_type') if l_2_field_maybe_mojom_type is missing else l_2_field_maybe_mojom_type)),
                    ' local_',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ';\n    if (input.has_m_',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    '() && mojolpm::FromProto(\n      input.m_',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    '(),\n      local_',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ')) {\n      maybe_local_',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ' = std::move(local_',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ');\n    }\n    return maybe_local_',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ';\n  }\n',
                ))
            else:
                pass
                l_2_field_mojom_type = t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)
                t_8.extend((
                    '\n  static ',
                    to_string((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                    ' ',
                    to_string(environment.getattr(l_2_field, 'name')),
                    '(\n      const ',
                    to_string((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
                    '& input) {\n    ',
                    to_string((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                    ' local_',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ';\n    (void) mojolpm::FromProto(\n      input.m_',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    '(),\n      local_',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ');\n    return local_',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ';\n  }\n',
                ))
        l_2_field = l_2_name = l_2_kind = l_2_field_mojom_type = l_2_field_maybe_mojom_type = missing
        t_8.append(
            '};\n',
        )
        return concat(t_8)
    context.exported_vars.add('define_struct')
    context.vars['define_struct'] = l_0_define_struct = Macro(environment, macro, 'define_struct', ('struct',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_union):
        t_9 = []
        l_1_dataview_type = resolve('dataview_type')
        l_1_mojom_type = l_1_proto_type = l_1_union_type = missing
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        pass
        l_1_mojom_type = t_2(l_1_union, add_same_module_namespaces=True)
        l_1_proto_type = unicode_join(('::mojolpm', t_3(l_1_union, flatten_nested_kind=True), ))
        l_1_union_type = unicode_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoUnion', ))
        if t_5(l_1_union):
            pass
            l_1_dataview_type = unicode_join((t_3(l_1_union, flatten_nested_kind=True), 'DataView', ))
            t_9.extend((
                '\ntemplate<>\nstruct UnionTraits<',
                to_string((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                ', ',
                to_string((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                '> {\n  static ',
                to_string((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                '::Tag GetTag(\n      const ',
                to_string((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                '& input) {\n    switch (input.union_member_case()) {',
            ))
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                l_2_name = l_2_kind = l_2_field_mojom_type = missing
                pass
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                l_2_kind = environment.getattr(l_2_field, 'kind')
                l_2_field_mojom_type = t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)
                t_9.extend((
                    '\n      case ',
                    to_string((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                    '::k',
                    to_string(t_7(unicode_join(('m_', (undefined(name='name') if l_2_name is missing else l_2_name), )))),
                    ':\n        return ',
                    to_string((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                    '::Tag::k',
                    to_string(t_7((undefined(name='name') if l_2_name is missing else l_2_name))),
                    ';',
                ))
            l_2_field = l_2_name = l_2_kind = l_2_field_mojom_type = missing
            t_9.extend((
                '\n      default:\n        return static_cast<',
                to_string((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                '::Tag>(0);\n    }\n  }\n',
            ))
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                l_2_field_mojom_type = resolve('field_mojom_type')
                l_2_field_maybe_mojom_type = resolve('field_maybe_mojom_type')
                l_2_name = l_2_kind = missing
                pass
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                l_2_kind = environment.getattr(l_2_field, 'kind')
                if (t_4(environment.getattr(l_2_field, 'kind')) and (not t_6(environment.getattr(l_2_field, 'kind')))):
                    pass
                    l_2_field_mojom_type = t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)
                    l_2_field_maybe_mojom_type = t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True, ignore_nullable=True)
                    t_9.extend((
                        '\n  static ',
                        to_string((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                        ' ',
                        to_string(environment.getattr(l_2_field, 'name')),
                        '(\n      const ',
                        to_string((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                        '& input) {\n    ',
                        to_string((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                        ' maybe_local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n    ',
                        to_string((undefined(name='field_maybe_mojom_type') if l_2_field_maybe_mojom_type is missing else l_2_field_maybe_mojom_type)),
                        ' local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n    if (mojolpm::FromProto(\n      input.m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(),\n      local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ')) {\n      maybe_local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ' = std::move(local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n    }\n    return maybe_local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n  }\n',
                    ))
                else:
                    pass
                    l_2_field_mojom_type = t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)
                    t_9.extend((
                        '\n  static ',
                        to_string((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                        ' ',
                        to_string(environment.getattr(l_2_field, 'name')),
                        '(\n      const ',
                        to_string((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                        '& input) {\n    ',
                        to_string((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                        ' local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n    (void) mojolpm::FromProto(\n      input.m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(),\n      local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n    return local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n  }\n',
                    ))
            l_2_field = l_2_name = l_2_kind = l_2_field_mojom_type = l_2_field_maybe_mojom_type = missing
            t_9.append(
                '};\n',
            )
        t_9.append(
            '\n',
        )
        return concat(t_9)
    context.exported_vars.add('define_union')
    context.vars['define_union'] = l_0_define_union = Macro(environment, macro, 'define_union', ('union',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=19&3=21&4=27&5=28&6=29&7=30&9=33&10=38&11=43&12=44&13=45&14=47&15=48&16=51&17=55&18=57&19=61&20=65&21=67&22=69&23=71&25=75&28=80&29=83&30=87&31=89&33=93&34=95&35=97&42=107&43=114&44=115&45=116&46=117&47=119&49=122&50=126&51=128&53=131&54=134&55=135&56=136&57=139&58=143&61=151&64=154&65=159&66=160&67=161&68=163&69=164&70=167&71=171&72=173&73=177&75=181&76=183&77=185&79=189&82=194&83=197&84=201&85=203&87=207&88=209&89=211'