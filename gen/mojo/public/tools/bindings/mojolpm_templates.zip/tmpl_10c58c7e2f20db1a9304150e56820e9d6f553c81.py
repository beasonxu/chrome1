from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'mojolpm.proto.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_proto_imports = resolve('proto_imports')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_enums = resolve('enums')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_interfaces = resolve('interfaces')
    l_0_module_prefix = l_0_optional_or_required = l_0_forward_declare_field_types_inner = l_0_forward_declare_field_types = missing
    t_1 = environment.filters['camel_to_under']
    t_2 = environment.filters['enum_field_name']
    t_3 = environment.filters['format']
    t_4 = environment.filters['get_name_for_kind']
    t_5 = environment.filters['has_duplicate_values']
    t_6 = environment.filters['indent']
    t_7 = environment.filters['is_array_kind']
    t_8 = environment.filters['is_map_kind']
    t_9 = environment.filters['is_native_only_kind']
    t_10 = environment.filters['is_nullable_kind']
    t_11 = environment.filters['join']
    t_12 = environment.filters['length']
    t_13 = environment.filters['lower']
    t_14 = environment.filters['proto_field_type']
    t_15 = environment.filters['proto_id']
    t_16 = environment.filters['replace']
    t_17 = environment.filters['under_to_camel']
    pass
    yield '// Copyright 2019 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.\n\nsyntax = "proto2";\n\npackage mojolpm.'
    yield to_string(t_16(context.eval_ctx, environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'mojom_namespace'), '/', '.'))
    yield ';\n\n'
    for l_1_proto_import in (undefined(name='proto_imports') if l_0_proto_imports is missing else l_0_proto_imports):
        pass
        yield '\nimport "'
        yield to_string(l_1_proto_import)
        yield '";'
    l_1_proto_import = missing
    l_0_module_prefix = t_3('%s', t_11(context.eval_ctx, (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), '.'))
    context.vars['module_prefix'] = l_0_module_prefix
    context.exported_vars.add('module_prefix')
    def macro(l_1_kind):
        t_18 = []
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        if t_10(l_1_kind):
            pass
            t_18.append(
                'optional',
            )
        else:
            pass
            t_18.append(
                'required',
            )
        return concat(t_18)
    context.exported_vars.add('optional_or_required')
    context.vars['optional_or_required'] = l_0_optional_or_required = Macro(environment, macro, 'optional_or_required', ('kind',), False, False, False, context.eval_ctx.autoescape)
    for l_1_enum in (undefined(name='enums') if l_0_enums is missing else l_0_enums):
        l_1_i = resolve('i')
        l_1_enum_name = missing
        pass
        l_1_enum_name = t_4(l_1_enum, flatten_nested_kind=True)
        if t_9(l_1_enum):
            pass
            yield '\n// WARNING Native only enum support '
            yield to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name))
            yield ' is very basic.\nenum '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield ' {\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_0 = 0;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_1 = 1;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_2 = 2;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_3 = 3;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_4 = 4;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_5 = 5;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_6 = 6;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_7 = 7;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_8 = 8;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_9 = 9;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_10 = 10;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_11 = 11;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_12 = 12;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_13 = 13;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_14 = 14;\n  '
            yield to_string(environment.getattr(l_1_enum, 'name'))
            yield '_15 = 15;\n}'
        else:
            pass
            yield '\n\nenum '
            yield to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name))
            yield ' {'
            if t_5(l_1_enum):
                pass
                yield '\n  option allow_alias = true;'
            l_1_i = 0
            for l_2_field in environment.getattr(l_1_enum, 'fields'):
                pass
                if (environment.getattr(l_2_field, 'name') != 'MAX'):
                    pass
                    yield '\n  '
                    yield to_string(environment.getattr(l_1_enum, 'name'))
                    yield '_'
                    yield to_string(t_2(environment.getattr(l_2_field, 'name'), l_1_enum))
                    yield ' = '
                    yield to_string(environment.getattr(l_2_field, 'numeric_value'))
                    yield ';'
            l_2_field = missing
            yield '\n}'
    l_1_enum = l_1_enum_name = l_1_i = missing
    def macro(l_1_kind, l_1_name):
        t_19 = []
        l_1_entry_name = resolve('entry_name')
        l_1_key_name = resolve('key_name')
        l_1_value_name = resolve('value_name')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_7(l_1_kind):
            pass
            l_1_entry_name = unicode_join((l_1_name, 'Entry', ))
            if (t_7(environment.getattr(l_1_kind, 'kind')) or t_8(environment.getattr(l_1_kind, 'kind'))):
                pass
                t_19.extend((
                    '\n',
                    to_string(context.call((undefined(name='forward_declare_field_types_inner') if l_0_forward_declare_field_types_inner is missing else l_0_forward_declare_field_types_inner), environment.getattr(l_1_kind, 'kind'), (undefined(name='entry_name') if l_1_entry_name is missing else l_1_entry_name))),
                ))
            else:
                pass
                t_19.extend((
                    '\n  message ',
                    to_string((undefined(name='entry_name') if l_1_entry_name is missing else l_1_entry_name)),
                    ' {\n    ',
                    to_string(t_14(environment.getattr(l_1_kind, 'kind'))),
                    ' value = 1;\n  }',
                ))
            t_19.extend((
                '\n\n  message ',
                to_string(l_1_name),
                ' {\n    repeated ',
                to_string((undefined(name='entry_name') if l_1_entry_name is missing else l_1_entry_name)),
                ' values = 1;\n  }',
            ))
        elif t_8(l_1_kind):
            pass
            l_1_entry_name = unicode_join((l_1_name, 'Entry', ))
            l_1_key_name = unicode_join((l_1_name, 'Key', ))
            l_1_value_name = unicode_join((l_1_name, 'Value', ))
            if (t_7(environment.getattr(l_1_kind, 'key_kind')) or t_8(environment.getattr(l_1_kind, 'key_kind'))):
                pass
                t_19.append(
                    to_string(context.call((undefined(name='forward_declare_field_types_inner') if l_0_forward_declare_field_types_inner is missing else l_0_forward_declare_field_types_inner), environment.getattr(l_1_kind, 'key_kind'), (undefined(name='key_name') if l_1_key_name is missing else l_1_key_name))),
                )
            else:
                pass
                t_19.extend((
                    '\n  message ',
                    to_string((undefined(name='key_name') if l_1_key_name is missing else l_1_key_name)),
                    ' {\n    ',
                    to_string(t_14(environment.getattr(l_1_kind, 'key_kind'))),
                    ' value = 1;\n  }\n',
                ))
            if (t_7(environment.getattr(l_1_kind, 'value_kind')) or t_8(environment.getattr(l_1_kind, 'value_kind'))):
                pass
                t_19.append(
                    to_string(context.call((undefined(name='forward_declare_field_types_inner') if l_0_forward_declare_field_types_inner is missing else l_0_forward_declare_field_types_inner), environment.getattr(l_1_kind, 'value_kind'), (undefined(name='value_name') if l_1_value_name is missing else l_1_value_name))),
                )
            else:
                pass
                t_19.extend((
                    '\n  message ',
                    to_string((undefined(name='value_name') if l_1_value_name is missing else l_1_value_name)),
                    ' {\n    ',
                    to_string(t_14(environment.getattr(l_1_kind, 'value_kind'))),
                    ' value = 1;\n  }\n',
                ))
            t_19.extend((
                '\n  message ',
                to_string((undefined(name='entry_name') if l_1_entry_name is missing else l_1_entry_name)),
                ' {\n    required ',
                to_string((undefined(name='key_name') if l_1_key_name is missing else l_1_key_name)),
                ' key = 1;\n    required ',
                to_string((undefined(name='value_name') if l_1_value_name is missing else l_1_value_name)),
                ' value = 2;\n  }\n\n  message ',
                to_string(l_1_name),
                ' {\n    repeated ',
                to_string((undefined(name='entry_name') if l_1_entry_name is missing else l_1_entry_name)),
                ' values = 1;\n  }',
            ))
        t_19.append(
            '\n',
        )
        return concat(t_19)
    context.exported_vars.add('forward_declare_field_types_inner')
    context.vars['forward_declare_field_types_inner'] = l_0_forward_declare_field_types_inner = Macro(environment, macro, 'forward_declare_field_types_inner', ('kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_kind, l_1_name):
        t_20 = []
        l_1_array_name = resolve('array_name')
        l_1_map_name = resolve('map_name')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_7(l_1_kind):
            pass
            l_1_array_name = unicode_join((t_17(l_1_name), '_Array', ))
            t_20.append(
                to_string(context.call((undefined(name='forward_declare_field_types_inner') if l_0_forward_declare_field_types_inner is missing else l_0_forward_declare_field_types_inner), l_1_kind, (undefined(name='array_name') if l_1_array_name is missing else l_1_array_name))),
            )
        elif t_8(l_1_kind):
            pass
            l_1_map_name = unicode_join((t_17(l_1_name), '_Map', ))
            t_20.extend((
                '\n',
                to_string(context.call((undefined(name='forward_declare_field_types_inner') if l_0_forward_declare_field_types_inner is missing else l_0_forward_declare_field_types_inner), l_1_kind, (undefined(name='map_name') if l_1_map_name is missing else l_1_map_name))),
            ))
        t_20.append(
            '\n',
        )
        return concat(t_20)
    context.exported_vars.add('forward_declare_field_types')
    context.vars['forward_declare_field_types'] = l_0_forward_declare_field_types = Macro(environment, macro, 'forward_declare_field_types', ('kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        l_1_struct_name = missing
        pass
        l_1_struct_name = t_4(l_1_struct, flatten_nested_kind=True)
        if t_9(l_1_struct):
            pass
            yield '\nmessage '
            yield to_string((undefined(name='struct_name') if l_1_struct_name is missing else l_1_struct_name))
            yield '_ProtoStruct {\n  // native-only struct\n  required uint32 id = 1;\n  required bytes native_bytes = 2;\n}'
        else:
            pass
            yield '\n\nmessage '
            yield to_string((undefined(name='struct_name') if l_1_struct_name is missing else l_1_struct_name))
            yield '_ProtoStruct {\n  required uint32 id = 1;'
            for l_2_pf in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields_in_ordinal_order'):
                l_2_name = l_2_kind = missing
                pass
                l_2_name = t_1(environment.getattr(environment.getattr(l_2_pf, 'field'), 'name'))
                l_2_kind = environment.getattr(environment.getattr(l_2_pf, 'field'), 'kind')
                if (t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    yield to_string(context.call((undefined(name='forward_declare_field_types') if l_0_forward_declare_field_types is missing else l_0_forward_declare_field_types), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name)))
            l_2_pf = l_2_name = l_2_kind = missing
            for l_2_pf in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields_in_ordinal_order'):
                l_2_name = l_2_kind = missing
                pass
                l_2_name = t_1(environment.getattr(environment.getattr(l_2_pf, 'field'), 'name'))
                l_2_kind = environment.getattr(environment.getattr(l_2_pf, 'field'), 'kind')
                if t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    yield '\n  '
                    yield to_string(context.call((undefined(name='optional_or_required') if l_0_optional_or_required is missing else l_0_optional_or_required), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                    yield ' '
                    yield to_string(t_17((undefined(name='name') if l_2_name is missing else l_2_name)))
                    yield '_Array m_'
                    yield to_string((undefined(name='name') if l_2_name is missing else l_2_name))
                    yield ' = '
                    yield to_string(t_15((undefined(name='name') if l_2_name is missing else l_2_name), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                    yield ';'
                elif t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    yield '\n  '
                    yield to_string(context.call((undefined(name='optional_or_required') if l_0_optional_or_required is missing else l_0_optional_or_required), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                    yield ' '
                    yield to_string(t_17((undefined(name='name') if l_2_name is missing else l_2_name)))
                    yield '_Map m_'
                    yield to_string((undefined(name='name') if l_2_name is missing else l_2_name))
                    yield ' = '
                    yield to_string(t_15((undefined(name='name') if l_2_name is missing else l_2_name), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                    yield ';'
                else:
                    pass
                    yield '\n  '
                    yield to_string(t_14((undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                    yield ' m_'
                    yield to_string((undefined(name='name') if l_2_name is missing else l_2_name))
                    yield ' = '
                    yield to_string(t_15((undefined(name='name') if l_2_name is missing else l_2_name), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                    yield ';'
            l_2_pf = l_2_name = l_2_kind = missing
            yield '\n}'
        yield '\n\nmessage '
        yield to_string((undefined(name='struct_name') if l_1_struct_name is missing else l_1_struct_name))
        yield ' {'
        for l_2_enum in environment.getattr(l_1_struct, 'enums'):
            l_2_i = resolve('i')
            l_2_enum_name = missing
            pass
            l_2_enum_name = t_4(l_2_enum, flatten_nested_kind=True)
            if t_9(l_2_enum):
                pass
                yield '\n  // WARNING Native only enum support '
                yield to_string((undefined(name='enum_name') if l_2_enum_name is missing else l_2_enum_name))
                yield ' is very basic.\n  enum '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield ' {\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_0 = 0;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_1 = 1;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_2 = 2;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_3 = 3;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_4 = 4;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_5 = 5;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_6 = 6;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_7 = 7;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_8 = 8;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_9 = 9;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_10 = 10;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_11 = 11;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_12 = 12;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_13 = 13;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_14 = 14;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_15 = 15;\n  }'
            else:
                pass
                yield '\n\n  enum '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield ' {'
                if t_5(l_2_enum):
                    pass
                    yield '\n    option allow_alias = true;'
                l_2_i = 0
                for l_3_field in environment.getattr(l_2_enum, 'fields'):
                    pass
                    yield '\n    '
                    yield to_string((undefined(name='enum_name') if l_2_enum_name is missing else l_2_enum_name))
                    yield '_'
                    yield to_string(environment.getattr(l_3_field, 'name'))
                    yield ' = '
                    yield to_string(environment.getattr(l_3_field, 'numeric_value'))
                    yield ';'
                l_3_field = missing
                yield '\n  }'
        l_2_enum = l_2_enum_name = l_2_i = missing
        yield '\n\n  oneof instance {\n    uint32 old = 1;\n    '
        yield to_string((undefined(name='struct_name') if l_1_struct_name is missing else l_1_struct_name))
        yield '_ProtoStruct new = 2;\n  }\n}'
    l_1_struct = l_1_struct_name = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        l_1_union_name = missing
        pass
        l_1_union_name = t_4(l_1_union, flatten_nested_kind=True)
        if t_9(l_1_union):
            pass
            yield '\n// ERROR native-only union kind'
        else:
            pass
            yield '\n\nmessage '
            yield to_string((undefined(name='union_name') if l_1_union_name is missing else l_1_union_name))
            yield '_ProtoUnion {\n  required uint32 id = 1;'
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                l_2_name = l_2_kind = missing
                pass
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                l_2_kind = environment.getattr(l_2_field, 'kind')
                if (t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    yield to_string(context.call((undefined(name='forward_declare_field_types') if l_0_forward_declare_field_types is missing else l_0_forward_declare_field_types), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name)))
            l_2_field = l_2_name = l_2_kind = missing
            yield '\n  oneof union_member {'
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                l_2_name = l_2_kind = missing
                pass
                l_2_name = t_13(environment.getattr(l_2_field, 'name'))
                l_2_kind = environment.getattr(l_2_field, 'kind')
                if t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    yield '\n    '
                    yield to_string(t_17((undefined(name='name') if l_2_name is missing else l_2_name)))
                    yield '_Array m_'
                    yield to_string((undefined(name='name') if l_2_name is missing else l_2_name))
                    yield ' = '
                    yield to_string(t_15((undefined(name='name') if l_2_name is missing else l_2_name), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                    yield ';'
                elif t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    yield '\n    '
                    yield to_string(t_17((undefined(name='name') if l_2_name is missing else l_2_name)))
                    yield '_Map m_'
                    yield to_string((undefined(name='name') if l_2_name is missing else l_2_name))
                    yield ' = '
                    yield to_string(t_15((undefined(name='name') if l_2_name is missing else l_2_name), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                    yield ';'
                else:
                    pass
                    yield '\n    '
                    yield to_string(t_14((undefined(name='kind') if l_2_kind is missing else l_2_kind), quantified=False))
                    yield ' m_'
                    yield to_string((undefined(name='name') if l_2_name is missing else l_2_name))
                    yield ' = '
                    yield to_string(t_15((undefined(name='name') if l_2_name is missing else l_2_name), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                    yield ';'
            l_2_field = l_2_name = l_2_kind = missing
            yield '\n  }\n}\n\nmessage '
            yield to_string((undefined(name='union_name') if l_1_union_name is missing else l_1_union_name))
            yield ' {\n  oneof instance {\n    uint32 old = 1;\n    '
            yield to_string((undefined(name='union_name') if l_1_union_name is missing else l_1_union_name))
            yield '_ProtoUnion new = 2;\n  }\n}'
    l_1_union = l_1_union_name = missing
    l_1_loop = missing
    for l_1_interface, l_1_loop in LoopContext((undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces), undefined):
        pass
        yield '\n\nmessage '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield ' {\n  message Reset {\n  }'
        for l_2_enum in environment.getattr(l_1_interface, 'enums'):
            l_2_i = resolve('i')
            l_2_enum_name = missing
            pass
            l_2_enum_name = t_4(l_2_enum, flatten_nested_kind=True)
            if t_9(l_2_enum):
                pass
                yield '\n  // WARNING Native only enum support '
                yield to_string((undefined(name='enum_name') if l_2_enum_name is missing else l_2_enum_name))
                yield ' is very basic.\n  enum '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield ' {\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_0 = 0;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_1 = 1;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_2 = 2;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_3 = 3;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_4 = 4;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_5 = 5;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_6 = 6;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_7 = 7;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_8 = 8;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_9 = 9;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_10 = 10;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_11 = 11;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_12 = 12;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_13 = 13;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_14 = 14;\n    '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield '_15 = 15;\n  }'
            else:
                pass
                yield '\n\n  enum '
                yield to_string(environment.getattr(l_2_enum, 'name'))
                yield ' {'
                if t_5(l_2_enum):
                    pass
                    yield '\n    option allow_alias = true;'
                l_2_i = 0
                for l_3_field in environment.getattr(l_2_enum, 'fields'):
                    pass
                    yield '\n    '
                    yield to_string(environment.getattr(l_2_enum, 'name'))
                    yield '_'
                    yield to_string(environment.getattr(l_3_field, 'name'))
                    yield ' = '
                    yield to_string(environment.getattr(l_3_field, 'numeric_value'))
                    yield ';'
                l_3_field = missing
                yield '\n  }'
        l_2_enum = l_2_enum_name = l_2_i = missing
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            pass
            yield '\n\n  message '
            yield to_string(environment.getattr(l_1_interface, 'name'))
            yield '_'
            yield to_string(environment.getattr(l_2_method, 'name'))
            yield ' {'
            for l_3_parameter in environment.getattr(l_2_method, 'parameters'):
                l_3_name = l_3_kind = missing
                pass
                l_3_name = t_1(environment.getattr(l_3_parameter, 'name'))
                l_3_kind = environment.getattr(l_3_parameter, 'kind')
                if (t_7((undefined(name='kind') if l_3_kind is missing else l_3_kind)) or t_8((undefined(name='kind') if l_3_kind is missing else l_3_kind))):
                    pass
                    yield to_string(t_6(context.call((undefined(name='forward_declare_field_types') if l_0_forward_declare_field_types is missing else l_0_forward_declare_field_types), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name)), width=2))
            l_3_parameter = l_3_name = l_3_kind = missing
            for l_3_parameter in environment.getattr(l_2_method, 'parameters'):
                l_3_name = l_3_kind = missing
                pass
                l_3_name = t_1(environment.getattr(l_3_parameter, 'name'))
                l_3_kind = environment.getattr(l_3_parameter, 'kind')
                if t_7((undefined(name='kind') if l_3_kind is missing else l_3_kind)):
                    pass
                    yield '\n    '
                    yield to_string(context.call((undefined(name='optional_or_required') if l_0_optional_or_required is missing else l_0_optional_or_required), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                    yield ' '
                    yield to_string(t_17((undefined(name='name') if l_3_name is missing else l_3_name)))
                    yield '_Array m_'
                    yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                    yield ' = '
                    yield to_string(t_15((undefined(name='name') if l_3_name is missing else l_3_name), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                    yield ';'
                elif t_8((undefined(name='kind') if l_3_kind is missing else l_3_kind)):
                    pass
                    yield '\n    '
                    yield to_string(context.call((undefined(name='optional_or_required') if l_0_optional_or_required is missing else l_0_optional_or_required), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                    yield ' '
                    yield to_string(t_17((undefined(name='name') if l_3_name is missing else l_3_name)))
                    yield '_Map m_'
                    yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                    yield ' = '
                    yield to_string(t_15((undefined(name='name') if l_3_name is missing else l_3_name), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                    yield ';'
                else:
                    pass
                    yield '\n    '
                    yield to_string(t_14((undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                    yield ' m_'
                    yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                    yield ' = '
                    yield to_string(t_15((undefined(name='name') if l_3_name is missing else l_3_name), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                    yield ';'
            l_3_parameter = l_3_name = l_3_kind = missing
            yield '\n  }\n\n  message '
            yield to_string(environment.getattr(l_1_interface, 'name'))
            yield '_'
            yield to_string(environment.getattr(l_2_method, 'name'))
            yield 'Response {'
            if environment.getattr(l_2_method, 'response_parameters'):
                pass
                for l_3_parameter in environment.getattr(l_2_method, 'response_parameters'):
                    l_3_name = l_3_kind = missing
                    pass
                    l_3_name = t_1(environment.getattr(l_3_parameter, 'name'))
                    l_3_kind = environment.getattr(l_3_parameter, 'kind')
                    if (t_7((undefined(name='kind') if l_3_kind is missing else l_3_kind)) or t_8((undefined(name='kind') if l_3_kind is missing else l_3_kind))):
                        pass
                        yield to_string(t_6(context.call((undefined(name='forward_declare_field_types') if l_0_forward_declare_field_types is missing else l_0_forward_declare_field_types), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name)), width=2))
                l_3_parameter = l_3_name = l_3_kind = missing
                for l_3_parameter in environment.getattr(l_2_method, 'response_parameters'):
                    l_3_name = l_3_kind = missing
                    pass
                    l_3_name = t_1(environment.getattr(l_3_parameter, 'name'))
                    l_3_kind = environment.getattr(l_3_parameter, 'kind')
                    if t_7((undefined(name='kind') if l_3_kind is missing else l_3_kind)):
                        pass
                        yield '\n    '
                        yield to_string(context.call((undefined(name='optional_or_required') if l_0_optional_or_required is missing else l_0_optional_or_required), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                        yield ' '
                        yield to_string(t_17((undefined(name='name') if l_3_name is missing else l_3_name)))
                        yield '_Array m_'
                        yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                        yield ' = '
                        yield to_string(t_15((undefined(name='name') if l_3_name is missing else l_3_name), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                        yield ';'
                    elif t_8((undefined(name='kind') if l_3_kind is missing else l_3_kind)):
                        pass
                        yield '\n    '
                        yield to_string(context.call((undefined(name='optional_or_required') if l_0_optional_or_required is missing else l_0_optional_or_required), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                        yield ' '
                        yield to_string(t_17((undefined(name='name') if l_3_name is missing else l_3_name)))
                        yield '_Map m_'
                        yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                        yield ' = '
                        yield to_string(t_15((undefined(name='name') if l_3_name is missing else l_3_name), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                        yield ';'
                    else:
                        pass
                        yield '\n    '
                        yield to_string(t_14((undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                        yield ' m_'
                        yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                        yield ' = '
                        yield to_string(t_15((undefined(name='name') if l_3_name is missing else l_3_name), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                        yield ';'
                l_3_parameter = l_3_name = l_3_kind = missing
            yield '\n  }'
        l_2_method = missing
        if t_12(environment.getattr(l_1_interface, 'methods')):
            pass
            yield '\n  message RemoteAction {\n    required uint32 id = 1;\n\n    oneof method {\n      Reset reset = 2;'
            l_2_loop = missing
            for l_2_method, l_2_loop in LoopContext(environment.getattr(l_1_interface, 'methods'), undefined):
                pass
                yield '\n      '
                yield to_string(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield ' m_'
                yield to_string(t_1(environment.getattr(l_2_method, 'name')))
                yield ' = '
                yield to_string((environment.getattr(l_2_loop, 'index') + 2))
                yield ';'
            l_2_loop = l_2_method = missing
            yield '\n    }\n  }\n\n  message AssociatedRemoteAction {\n    required uint32 id = 1;\n\n    oneof method {\n      Reset reset = 2;'
            l_2_loop = missing
            for l_2_method, l_2_loop in LoopContext(environment.getattr(l_1_interface, 'methods'), undefined):
                pass
                yield '\n      '
                yield to_string(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield ' m_'
                yield to_string(t_1(environment.getattr(l_2_method, 'name')))
                yield ' = '
                yield to_string((environment.getattr(l_2_loop, 'index') + 2))
                yield ';'
            l_2_loop = l_2_method = missing
            yield '\n    }\n  }\n\n  message ReceiverAction {\n    required uint32 id = 1;\n\n    oneof response {'
            l_2_loop = missing
            for l_2_method, l_2_loop in LoopContext(environment.getattr(l_1_interface, 'methods'), undefined):
                pass
                yield '\n      '
                yield to_string(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield 'Response m_'
                yield to_string(t_1(environment.getattr(l_2_method, 'name')))
                yield '_response = '
                yield to_string((environment.getattr(l_2_loop, 'index') + 2))
                yield ';'
            l_2_loop = l_2_method = missing
            yield '\n    }\n  }'
        yield '\n}'
    l_1_loop = l_1_interface = missing

blocks = {}
debug_info = '7=37&9=39&10=42&13=45&15=48&16=53&21=66&22=70&23=71&24=74&25=76&26=78&27=80&28=82&29=84&30=86&31=88&32=90&33=92&34=94&35=96&36=98&37=100&38=102&39=104&40=106&41=108&45=113&46=115&49=118&50=119&51=121&52=124&59=133&60=143&61=145&62=146&63=150&65=156&66=158&70=163&71=165&74=168&75=170&76=171&77=172&78=173&79=176&81=182&82=184&85=187&86=190&88=196&89=198&92=203&93=205&94=207&97=209&98=211&103=220&104=229&105=231&106=233&107=235&108=237&109=240&113=248&114=251&115=252&116=255&123=260&125=262&126=265&127=266&128=267&129=269&132=271&133=274&134=275&135=276&136=279&137=287&138=290&140=301&146=310&147=312&148=316&149=317&150=320&151=322&152=324&153=326&154=328&155=330&156=332&157=334&158=336&159=338&160=340&161=342&162=344&163=346&164=348&165=350&166=352&167=354&171=359&172=361&175=364&176=365&177=368&185=378&190=381&191=384&192=385&196=391&198=393&199=396&200=397&201=398&202=400&206=403&207=406&208=407&209=408&210=411&211=417&212=420&214=429&220=437&223=439&229=443&231=446&235=448&236=452&237=453&238=456&239=458&240=460&241=462&242=464&243=466&244=468&245=470&246=472&247=474&248=476&249=478&250=480&251=482&252=484&253=486&254=488&255=490&259=495&260=497&263=500&264=501&265=504&271=513&273=516&274=520&275=523&276=524&277=525&278=527&281=529&282=532&283=533&284=534&285=537&286=545&287=548&289=559&294=567&295=571&296=573&297=576&298=577&299=578&300=580&303=582&304=585&305=586&306=587&307=590&308=598&309=601&311=612&318=621&324=625&325=628&335=639&336=642&345=653&346=656'