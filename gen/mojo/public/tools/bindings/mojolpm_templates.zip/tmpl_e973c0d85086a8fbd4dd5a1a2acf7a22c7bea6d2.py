from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'mojolpm.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_extra_public_headers = resolve('extra_public_headers')
    l_0_imports = resolve('imports')
    l_0_all_enums = resolve('all_enums')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_interfaces = resolve('interfaces')
    l_0_header_guard = l_0_namespace_begin = l_0_namespace_end = l_0_util = l_0_from_proto = l_0_to_proto = missing
    t_1 = environment.filters['contains_handles_or_interfaces']
    t_2 = environment.filters['cpp_wrapper_call_type']
    t_3 = environment.filters['cpp_wrapper_param_type']
    t_4 = environment.filters['cpp_wrapper_type']
    t_5 = environment.filters['format']
    t_6 = environment.filters['get_qualified_name_for_kind']
    t_7 = environment.filters['is_array_kind']
    t_8 = environment.filters['is_map_kind']
    t_9 = environment.filters['is_native_only_kind']
    t_10 = environment.filters['replace']
    t_11 = environment.filters['reverse']
    t_12 = environment.filters['upper']
    pass
    yield '// Copyright 2019 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    l_0_header_guard = t_5('%s_MOJOLPM_H_', t_10(context.eval_ctx, t_10(context.eval_ctx, t_10(context.eval_ctx, t_12(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path')), '/', '_'), '.', '_'), '-', '_'))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    def macro():
        t_13 = []
        l_1_namespaces_as_array = resolve('namespaces_as_array')
        pass
        t_13.append(
            '\nnamespace mojolpm {',
        )
        for l_2_namespace in (undefined(name='namespaces_as_array') if l_1_namespaces_as_array is missing else l_1_namespaces_as_array):
            pass
            t_13.extend((
                '\nnamespace ',
                to_string(l_2_namespace),
                ' {',
            ))
        l_2_namespace = missing
        return concat(t_13)
    context.exported_vars.add('namespace_begin')
    context.vars['namespace_begin'] = l_0_namespace_begin = Macro(environment, macro, 'namespace_begin', (), False, False, False, context.eval_ctx.autoescape)
    def macro():
        t_14 = []
        l_1_namespaces_as_array = resolve('namespaces_as_array')
        pass
        for l_2_namespace in t_11((undefined(name='namespaces_as_array') if l_1_namespaces_as_array is missing else l_1_namespaces_as_array)):
            pass
            t_14.extend((
                '\n}  // namespace ',
                to_string(l_2_namespace),
            ))
        l_2_namespace = missing
        t_14.append(
            '\n}  // namespace mojolpm',
        )
        return concat(t_14)
    context.exported_vars.add('namespace_end')
    context.vars['namespace_end'] = l_0_namespace_end = Macro(environment, macro, 'namespace_end', (), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n#ifndef '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include "mojo/public/cpp/bindings/associated_receiver.h"\n#include "mojo/public/cpp/bindings/associated_remote.h"\n#include "mojo/public/cpp/bindings/receiver.h"\n#include "mojo/public/cpp/bindings/remote.h"\n#include "mojo/public/tools/fuzzers/mojolpm.h"\n\n'
    for l_1_extra_public_header in (undefined(name='extra_public_headers') if l_0_extra_public_headers is missing else l_0_extra_public_headers):
        pass
        yield '\n#include "'
        yield to_string(l_1_extra_public_header)
        yield '"'
    l_1_extra_public_header = missing
    yield '\n\n'
    for l_1_import in (undefined(name='imports') if l_0_imports is missing else l_0_imports):
        pass
        yield '\n#include "'
        yield to_string(environment.getattr(l_1_import, 'path'))
        yield '-mojolpm.h"\n#include "'
        yield to_string(environment.getattr(l_1_import, 'path'))
        yield '.h"'
    l_1_import = missing
    yield '\n\n#include "'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '.mojolpm.pb.h"\n#include "'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '.h"'
    l_0_util = context.vars['util'] = environment.get_template('mojolpm_macros.tmpl', 'mojolpm.h.tmpl')._get_default_module()
    context.exported_vars.discard('util')
    l_0_from_proto = context.vars['from_proto'] = environment.get_template('mojolpm_from_proto_macros.tmpl', 'mojolpm.h.tmpl')._get_default_module()
    context.exported_vars.discard('from_proto')
    l_0_to_proto = context.vars['to_proto'] = environment.get_template('mojolpm_to_proto_macros.tmpl', 'mojolpm.h.tmpl')._get_default_module()
    context.exported_vars.discard('to_proto')
    yield '\n\nnamespace mojolpm {'
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        l_1_mojom_type = l_1_proto_type = missing
        pass
        l_1_mojom_type = t_4(l_1_enum, add_same_module_namespaces=True)
        l_1_proto_type = unicode_join(('::mojolpm', t_6(l_1_enum, flatten_nested_kind=True), ))
        yield '\n// enum '
        yield to_string(environment.getattr(l_1_enum, 'name'))
        yield '\nbool FromProto(\n  const '
        yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
        yield '& input,\n  '
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '& output);\n\nbool ToProto(\n  const '
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '& input,\n  '
        yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
        yield '& output);\n'
    l_1_enum = l_1_mojom_type = l_1_proto_type = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        l_1_mojom_in_type = l_1_mojom_out_type = l_1_maybe_const = l_1_proto_type = l_1_struct_type = missing
        pass
        l_1_mojom_in_type = t_3(l_1_struct, add_same_module_namespaces=True)
        l_1_mojom_out_type = t_2(l_1_struct, add_same_module_namespaces=True)
        l_1_maybe_const = ('const ' if (not t_1(l_1_struct)) else '')
        l_1_proto_type = unicode_join(('::mojolpm', t_6(l_1_struct, flatten_nested_kind=True), ))
        l_1_struct_type = unicode_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoStruct', ))
        yield '\n// struct '
        yield to_string(environment.getattr(l_1_struct, 'name'))
        yield '\nbool FromProto(\n  const '
        yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
        yield '& input,\n  '
        yield to_string((undefined(name='mojom_out_type') if l_1_mojom_out_type is missing else l_1_mojom_out_type))
        yield '& output);\n\nbool ToProto(\n  '
        yield to_string((undefined(name='mojom_in_type') if l_1_mojom_in_type is missing else l_1_mojom_in_type))
        yield ' input,\n  '
        yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
        yield '& output);\n'
        for l_2_field in environment.getattr(l_1_struct, 'fields'):
            l_2_name = l_2_kind = missing
            pass
            l_2_name = environment.getattr(l_2_field, 'name')
            l_2_kind = environment.getattr(l_2_field, 'kind')
            if (t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                pass
                yield to_string(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'declare'), (undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name)))
                yield to_string(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'declare'), (undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name)))
        l_2_field = l_2_name = l_2_kind = missing
    l_1_struct = l_1_mojom_in_type = l_1_mojom_out_type = l_1_maybe_const = l_1_proto_type = l_1_struct_type = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        l_1_mojom_in_type = l_1_mojom_out_type = l_1_maybe_const = l_1_proto_type = l_1_union_type = missing
        pass
        l_1_mojom_in_type = t_3(l_1_union, add_same_module_namespaces=True)
        l_1_mojom_out_type = t_2(l_1_union, add_same_module_namespaces=True)
        l_1_maybe_const = ('const ' if (not t_1(l_1_union)) else '')
        l_1_proto_type = unicode_join(('::mojolpm', t_6(l_1_union, flatten_nested_kind=True), ))
        l_1_union_type = unicode_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoUnion', ))
        if t_9(l_1_union):
            pass
            yield '\n#error "Mojo native-only union '
            yield to_string(environment.getattr(l_1_union, 'name'))
            yield ' - don\'t think this is possible"'
        else:
            pass
            yield '\n// union '
            yield to_string(environment.getattr(l_1_union, 'name'))
            yield '\nbool FromProto(\n  const '
            yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '& input,\n  '
            yield to_string((undefined(name='mojom_out_type') if l_1_mojom_out_type is missing else l_1_mojom_out_type))
            yield '& output);\n\nbool ToProto(\n  '
            yield to_string((undefined(name='mojom_in_type') if l_1_mojom_in_type is missing else l_1_mojom_in_type))
            yield ' input,\n  '
            yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '& output);\n'
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            l_2_name = l_2_kind = missing
            pass
            l_2_name = environment.getattr(l_2_field, 'name')
            l_2_kind = environment.getattr(l_2_field, 'kind')
            if (t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                pass
                yield to_string(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'declare'), (undefined(name='union_type') if l_1_union_type is missing else l_1_union_type), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name)))
                yield to_string(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'declare'), (undefined(name='union_type') if l_1_union_type is missing else l_1_union_type), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name)))
        l_2_field = l_2_name = l_2_kind = missing
    l_1_union = l_1_mojom_in_type = l_1_mojom_out_type = l_1_maybe_const = l_1_proto_type = l_1_union_type = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        l_1_mojom_type = l_1_proto_type = missing
        pass
        l_1_mojom_type = t_6(l_1_interface, flatten_nested_kind=True)
        l_1_proto_type = unicode_join(('::mojolpm', t_6(l_1_interface, flatten_nested_kind=True), ))
        yield '\n// interface '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield '\nbool FromProto(\n  uint32_t input,\n  ::mojo::PendingRemote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>& output);\n\nbool ToProto(\n  ::mojo::PendingRemote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>&& input,\n  uint32_t& output);\n\nbool FromProto(\n  uint32_t input,\n  ::mojo::PendingReceiver<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>& output);\n\nbool ToProto(\n  ::mojo::PendingReceiver<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>&& input,\n  uint32_t& output);\n\nbool FromProto(\n  uint32_t input,\n  ::mojo::PendingAssociatedRemote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>& output);\n\nbool ToProto(\n  ::mojo::PendingAssociatedRemote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>&& input,\n  uint32_t& output);\n\nbool FromProto(\n  uint32_t input,\n  ::mojo::PendingAssociatedReceiver<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>& output);\n\nbool ToProto(\n  ::mojo::PendingAssociatedReceiver<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>&& input,\n  uint32_t& output);\n'
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_method_type = missing
            pass
            l_2_method_type = unicode_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '::', environment.getattr(l_1_interface, 'name'), '_', environment.getattr(l_2_method, 'name'), ))
            for l_3_param in environment.getattr(l_2_method, 'parameters'):
                l_3_name = l_3_kind = missing
                pass
                l_3_name = environment.getattr(l_3_param, 'name')
                l_3_kind = environment.getattr(l_3_param, 'kind')
                if (t_7((undefined(name='kind') if l_3_kind is missing else l_3_kind)) or t_8((undefined(name='kind') if l_3_kind is missing else l_3_kind))):
                    pass
                    yield to_string(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'declare'), (undefined(name='method_type') if l_2_method_type is missing else l_2_method_type), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name)))
                    yield to_string(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'declare'), (undefined(name='method_type') if l_2_method_type is missing else l_2_method_type), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name)))
            l_3_param = l_3_name = l_3_kind = missing
        l_2_method = l_2_method_type = missing
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_method_type = resolve('method_type')
            pass
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                l_2_method_type = unicode_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '::', environment.getattr(l_1_interface, 'name'), '_', environment.getattr(l_2_method, 'name'), 'Response', ))
                for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                    l_3_name = l_3_kind = missing
                    pass
                    l_3_name = environment.getattr(l_3_param, 'name')
                    l_3_kind = environment.getattr(l_3_param, 'kind')
                    if (t_7((undefined(name='kind') if l_3_kind is missing else l_3_kind)) or t_8((undefined(name='kind') if l_3_kind is missing else l_3_kind))):
                        pass
                        yield to_string(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'declare'), (undefined(name='method_type') if l_2_method_type is missing else l_2_method_type), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name)))
                        yield to_string(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'declare'), (undefined(name='method_type') if l_2_method_type is missing else l_2_method_type), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name)))
                l_3_param = l_3_name = l_3_kind = missing
        l_2_method = l_2_method_type = missing
    l_1_interface = l_1_mojom_type = l_1_proto_type = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        l_1_mojom_type = l_1_proto_type = missing
        pass
        l_1_mojom_type = t_6(l_1_interface, flatten_nested_kind=True)
        l_1_proto_type = unicode_join(('::mojolpm', t_6(l_1_interface, flatten_nested_kind=True), ))
        if environment.getattr(l_1_interface, 'methods'):
            pass
            yield '\nbool HandleRemoteAction(\n  const '
            yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '::RemoteAction& input);\n\nbool HandleAssociatedRemoteAction(\n  const '
            yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '::AssociatedRemoteAction& input);\n\nbool HandleReceiverAction(\n  const '
            yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '::ReceiverAction& input);\n'
            for l_2_method in environment.getattr(l_1_interface, 'methods'):
                pass
                yield '\nbool HandleRemoteCall(\n  uint32_t instance_id,\n  const '
                yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
                yield '::'
                yield to_string(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield '& input);\n\nbool HandleAssociatedRemoteCall(\n  uint32_t instance_id,\n  const '
                yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
                yield '::'
                yield to_string(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield '& input);\n\nbool HandleResponse(\n  uint32_t callback_id,\n  const '
                yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
                yield '::'
                yield to_string(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield 'Response& input);\n'
            l_2_method = missing
    l_1_interface = l_1_mojom_type = l_1_proto_type = missing
    yield '}  // namespace mojolpm\n\n#endif  // '
    yield to_string((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=32&9=35&11=42&12=46&16=53&17=57&18=61&23=71&24=73&32=75&33=78&36=82&37=85&38=87&41=91&42=93&44=95&45=97&46=99&50=102&51=105&52=106&53=108&55=110&56=112&59=114&60=116&63=119&64=122&65=123&66=124&67=125&68=126&69=128&71=130&72=132&75=134&76=136&77=138&78=141&79=142&80=143&81=145&82=146&87=149&88=152&89=153&90=154&91=155&92=156&93=157&94=160&96=165&98=167&99=169&102=171&103=173&105=175&106=178&107=179&108=180&109=182&110=183&115=186&116=189&117=190&118=192&121=194&124=196&129=198&132=200&137=202&140=204&145=206&148=208&150=210&151=213&152=214&153=217&154=218&155=219&156=221&157=222&161=225&162=228&163=230&164=231&165=234&166=235&167=236&168=238&169=239&176=243&177=246&178=247&179=248&181=251&184=253&187=255&188=257&191=260&195=266&199=272&205=281'