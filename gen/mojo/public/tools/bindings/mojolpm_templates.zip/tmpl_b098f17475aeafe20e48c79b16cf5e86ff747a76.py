from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'mojolpm_from_proto_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_util = l_0_declare_array = l_0_declare_map = l_0_declare = l_0_define_array = l_0_define_map = l_0_define = l_0_define_enum = l_0_define_struct = l_0_define_union = missing
    t_1 = environment.filters['camel_to_under']
    t_2 = environment.filters['cpp_wrapper_call_type']
    t_3 = environment.filters['cpp_wrapper_type']
    t_4 = environment.filters['get_qualified_name_for_kind']
    t_5 = environment.filters['is_array_kind']
    t_6 = environment.filters['is_map_kind']
    t_7 = environment.filters['is_native_only_kind']
    t_8 = environment.filters['is_nullable_kind']
    t_9 = environment.filters['is_typemapped_kind']
    t_10 = environment.filters['under_to_camel']
    pass
    l_0_util = context.vars['util'] = environment.get_template('mojolpm_macros.tmpl', 'mojolpm_from_proto_macros.tmpl')._get_default_module()
    context.exported_vars.discard('util')
    def macro(l_1_type, l_1_kind):
        t_11 = []
        l_1_mojom_type = l_1_mojom_maybe_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_mojom_type = t_3(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True)
        l_1_mojom_maybe_type = t_3(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True, ignore_nullable=True)
        t_11.extend((
            '\nbool FromProto(\n  const ',
            to_string(l_1_type),
            '& input,\n  std::vector<',
            to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '>& output);\n',
        ))
        if t_5(environment.getattr(l_1_kind, 'kind')):
            pass
            t_11.extend((
                '\n',
                to_string(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), unicode_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            ))
        elif t_6(environment.getattr(l_1_kind, 'kind')):
            pass
            t_11.extend((
                '\n',
                to_string(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), unicode_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            ))
        elif t_8(environment.getattr(l_1_kind, 'kind')):
            pass
            t_11.extend((
                '\nbool FromProto(\n  const ',
                to_string(l_1_type),
                'Entry& input,\n  ',
                to_string((undefined(name='mojom_maybe_type') if l_1_mojom_maybe_type is missing else l_1_mojom_maybe_type)),
                '& output);\n',
            ))
        else:
            pass
            t_11.extend((
                '\nbool FromProto(\n  const ',
                to_string(l_1_type),
                'Entry& input,\n  ',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '& output);\n',
            ))
        return concat(t_11)
    context.exported_vars.add('declare_array')
    context.vars['declare_array'] = l_0_declare_array = Macro(environment, macro, 'declare_array', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_type, l_1_kind):
        t_12 = []
        l_1_mojom_key_type = l_1_mojom_value_type = l_1_mojom_maybe_value_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_mojom_key_type = t_3(environment.getattr(l_1_kind, 'key_kind'), add_same_module_namespaces=True)
        l_1_mojom_value_type = t_3(environment.getattr(l_1_kind, 'value_kind'), add_same_module_namespaces=True)
        l_1_mojom_maybe_value_type = t_3(environment.getattr(l_1_kind, 'value_kind'), add_same_module_namespaces=True, ignore_nullable=True)
        t_12.extend((
            '\nbool FromProto(\n  const ',
            to_string(l_1_type),
            '& input,\n  base::flat_map<',
            to_string((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
            ',\n  ',
            to_string((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
            '>& output);\n',
        ))
        if t_5(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_12.append(
                to_string(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), unicode_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            )
        elif t_6(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_12.append(
                to_string(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), unicode_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            )
        else:
            pass
            t_12.extend((
                '\nbool FromProto(\n  const ',
                to_string(l_1_type),
                'Key& input,\n  ',
                to_string((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                '& output);\n',
            ))
        if t_5(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_12.append(
                to_string(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), unicode_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        elif t_6(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_12.append(
                to_string(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), unicode_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        elif t_8(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_12.extend((
                '\nbool FromProto(\n  const ',
                to_string(l_1_type),
                'Value& input,\n  ',
                to_string((undefined(name='mojom_maybe_value_type') if l_1_mojom_maybe_value_type is missing else l_1_mojom_maybe_value_type)),
                '& output);\n',
            ))
        else:
            pass
            t_12.extend((
                '\nbool FromProto(\n  const ',
                to_string(l_1_type),
                'Value& input,\n  ',
                to_string((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                '& output);\n',
            ))
        return concat(t_12)
    context.exported_vars.add('declare_map')
    context.vars['declare_map'] = l_0_declare_map = Macro(environment, macro, 'declare_map', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_parent_name, l_1_kind, l_1_name):
        t_13 = []
        l_1_array_type = resolve('array_type')
        l_1_map_type = resolve('map_type')
        if l_1_parent_name is missing:
            l_1_parent_name = undefined("parameter 'parent_name' was not provided", name='parent_name')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_5(l_1_kind):
            pass
            l_1_array_type = unicode_join((l_1_parent_name, '::', t_10(l_1_name), '_Array', ))
            t_13.append(
                to_string(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), (undefined(name='array_type') if l_1_array_type is missing else l_1_array_type), l_1_kind)),
            )
        elif t_6(l_1_kind):
            pass
            l_1_map_type = unicode_join((l_1_parent_name, '::', t_10(l_1_name), '_Map', ))
            t_13.append(
                to_string(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), (undefined(name='map_type') if l_1_map_type is missing else l_1_map_type), l_1_kind)),
            )
        return concat(t_13)
    context.exported_vars.add('declare')
    context.vars['declare'] = l_0_declare = Macro(environment, macro, 'declare', ('parent_name', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_type, l_1_kind):
        t_14 = []
        l_1_mojom_type = l_1_mojom_maybe_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_mojom_type = t_3(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True)
        l_1_mojom_maybe_type = t_3(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True, ignore_nullable=True)
        t_14.extend((
            '\nbool FromProto(\n    const ',
            to_string(l_1_type),
            '& input,\n    std::vector<',
            to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '>& output) {\n  bool result = true;\n  size_t i = 0;\n\n  output.resize(input.values_size());\n\n  for (const auto& entry : input.values()) {',
        ))
        if t_8(environment.getattr(l_1_kind, 'kind')):
            pass
            t_14.extend((
                '\n    ',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                ' value;\n    ',
                to_string((undefined(name='mojom_maybe_type') if l_1_mojom_maybe_type is missing else l_1_mojom_maybe_type)),
                ' maybe_value;\n    if (FromProto(entry.value(), maybe_value)) {\n      value = std::move(maybe_value);\n    }\n    output[i++] = std::move(value);',
            ))
        elif (t_6(environment.getattr(l_1_kind, 'kind')) or t_5(environment.getattr(l_1_kind, 'kind'))):
            pass
            t_14.extend((
                '\n    ',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                ' values;\n    result = FromProto(entry, values);\n    if (!result) {\n      break;\n    }\n    output[i++] = std::move(values);',
            ))
        else:
            pass
            t_14.extend((
                '\n    ',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                ' value;\n    result = FromProto(entry.value(), value);\n    if (!result) {\n      break;\n    }\n    output[i++] = std::move(value);',
            ))
        t_14.append(
            '\n  }\n\n  return result;\n}\n',
        )
        if t_5(environment.getattr(l_1_kind, 'kind')):
            pass
            t_14.append(
                to_string(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), unicode_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            )
        elif t_6(environment.getattr(l_1_kind, 'kind')):
            pass
            t_14.append(
                to_string(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), unicode_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            )
        elif t_8(environment.getattr(l_1_kind, 'kind')):
            pass
            t_14.extend((
                '\nbool FromProto(\n    const ',
                to_string(l_1_type),
                'Entry& input,\n    ',
                to_string((undefined(name='mojom_maybe_type') if l_1_mojom_maybe_type is missing else l_1_mojom_maybe_type)),
                '& output) {\n  return FromProto(input.value(), output);\n}\n',
            ))
        else:
            pass
            t_14.extend((
                '\nbool FromProto(\n    const ',
                to_string(l_1_type),
                'Entry& input,\n    ',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '& output) {\n  return FromProto(input.value(), output);\n}\n',
            ))
        return concat(t_14)
    context.exported_vars.add('define_array')
    context.vars['define_array'] = l_0_define_array = Macro(environment, macro, 'define_array', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_type, l_1_kind):
        t_15 = []
        l_1_mojom_key_type = l_1_mojom_value_type = l_1_mojom_maybe_value_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_mojom_key_type = t_3(environment.getattr(l_1_kind, 'key_kind'), add_same_module_namespaces=True)
        l_1_mojom_value_type = t_3(environment.getattr(l_1_kind, 'value_kind'), add_same_module_namespaces=True)
        l_1_mojom_maybe_value_type = t_3(environment.getattr(l_1_kind, 'value_kind'), add_same_module_namespaces=True, ignore_nullable=True)
        t_15.extend((
            '\nbool FromProto(\n    const ',
            to_string(l_1_type),
            '& input,\n    base::flat_map<',
            to_string((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
            ',\n                   ',
            to_string((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
            '>& output) {\n  bool result = true;\n  for (const auto& entry : input.values()) {',
        ))
        if t_8(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_15.extend((
                '\n    ',
                to_string((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ' key;\n    ',
                to_string((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                ' value;\n    ',
                to_string((undefined(name='mojom_maybe_value_type') if l_1_mojom_maybe_value_type is missing else l_1_mojom_maybe_value_type)),
                ' maybe_value;\n\n    if (FromProto(entry.key(), key)) {\n      if (FromProto(entry.value(), maybe_value)) {\n        value = std::move(maybe_value);\n      }\n      output.emplace(std::move(key), std::move(value));\n    } else {\n      result = false;\n      break;\n    }',
            ))
        else:
            pass
            t_15.extend((
                '\n    ',
                to_string((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ' key;\n    ',
                to_string((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                ' value;\n\n    if (FromProto(entry.key(), key)\n        && FromProto(entry.value(), value)) {\n      output.emplace(std::move(key), std::move(value));\n    } else {\n      result = false;\n      break;\n    }',
            ))
        t_15.append(
            '\n  }\n\n  return result;\n}\n',
        )
        if t_5(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_15.extend((
                '\n',
                to_string(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), unicode_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            ))
        elif t_6(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_15.extend((
                '\n',
                to_string(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), unicode_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            ))
        else:
            pass
            t_15.extend((
                '\nbool FromProto(\n    const ',
                to_string(l_1_type),
                'Key& input,\n    ',
                to_string((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                '& output) {\n  return FromProto(input.value(), output);\n}\n',
            ))
        if t_5(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_15.append(
                to_string(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), unicode_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        elif t_6(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_15.append(
                to_string(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), unicode_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        elif t_8(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_15.extend((
                '\nbool FromProto(\n    const ',
                to_string(l_1_type),
                'Value& input,\n    ',
                to_string((undefined(name='mojom_maybe_value_type') if l_1_mojom_maybe_value_type is missing else l_1_mojom_maybe_value_type)),
                '& output) {\n  return FromProto(input.value(), output);\n}\n',
            ))
        else:
            pass
            t_15.extend((
                '\nbool FromProto(\n    const ',
                to_string(l_1_type),
                'Value& input,\n    ',
                to_string((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                '& output) {\n  return FromProto(input.value(), output);\n}\n',
            ))
        return concat(t_15)
    context.exported_vars.add('define_map')
    context.vars['define_map'] = l_0_define_map = Macro(environment, macro, 'define_map', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_parent_name, l_1_kind, l_1_name):
        t_16 = []
        l_1_array_type = resolve('array_type')
        l_1_map_type = resolve('map_type')
        if l_1_parent_name is missing:
            l_1_parent_name = undefined("parameter 'parent_name' was not provided", name='parent_name')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_5(l_1_kind):
            pass
            l_1_array_type = unicode_join((l_1_parent_name, '::', t_10(l_1_name), '_Array', ))
            t_16.append(
                to_string(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), (undefined(name='array_type') if l_1_array_type is missing else l_1_array_type), l_1_kind)),
            )
        elif t_6(l_1_kind):
            pass
            l_1_map_type = unicode_join((l_1_parent_name, '::', t_10(l_1_name), '_Map', ))
            t_16.append(
                to_string(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), (undefined(name='map_type') if l_1_map_type is missing else l_1_map_type), l_1_kind)),
            )
        return concat(t_16)
    context.exported_vars.add('define')
    context.vars['define'] = l_0_define = Macro(environment, macro, 'define', ('parent_name', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_17 = []
        l_1_mojom_type = l_1_proto_type = l_1_enum_type = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_mojom_type = t_2(l_1_enum, add_same_module_namespaces=True)
        l_1_proto_type = unicode_join(('::mojolpm', t_4(l_1_enum, flatten_nested_kind=True), ))
        l_1_enum_type = t_4(l_1_enum, flatten_nested_kind=True)
        t_17.extend((
            '\nbool FromProto(\n    const ',
            to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '& input,\n    ',
            to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '& output) {',
        ))
        if (t_7(l_1_enum) or (not t_9(l_1_enum))):
            pass
            t_17.extend((
                "\n  // This ignores IPC_PARAM_TRAITS for native IPC enums, but internal to the\n  // fuzzer we don't want the overhead of the serialization layer if we don't\n  // need it. This doesn't change the actual checks on the receiving end.\n  output = static_cast<",
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>(input);\n  return true;',
            ))
        else:
            pass
            t_17.extend((
                '\n  return mojo::EnumTraits<',
                to_string((undefined(name='enum_type') if l_1_enum_type is missing else l_1_enum_type)),
                ', ',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>::FromMojom(\n    static_cast<',
                to_string((undefined(name='enum_type') if l_1_enum_type is missing else l_1_enum_type)),
                '>(input), &output);',
            ))
        t_17.append(
            '\n}',
        )
        return concat(t_17)
    context.exported_vars.add('define_enum')
    context.vars['define_enum'] = l_0_define_enum = Macro(environment, macro, 'define_enum', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_struct):
        t_18 = []
        l_1_dataview_type = resolve('dataview_type')
        l_1_data_type = resolve('data_type')
        l_1_mojom_type = l_1_proto_type = l_1_struct_type = missing
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        pass
        l_1_mojom_type = t_2(l_1_struct, add_same_module_namespaces=True)
        l_1_proto_type = unicode_join(('::mojolpm', t_4(l_1_struct, flatten_nested_kind=True), ))
        l_1_struct_type = unicode_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoStruct', ))
        t_18.extend((
            '\nbool FromProto(\n    const ',
            to_string((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
            '& input,\n    ',
            to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '& output) {',
        ))
        if t_7(l_1_struct):
            pass
            t_18.append(
                '\n  memset((void*)&output, 0, sizeof(output));\n  if (input.native_bytes().size() < sizeof(output)) {\n    memcpy((void*)&output, input.native_bytes().data(), input.native_bytes().size());\n  } else {\n    memcpy((void*)&output, input.native_bytes().data(), sizeof(output));\n  }\n  return true;',
            )
        elif t_9(l_1_struct):
            pass
            l_1_dataview_type = unicode_join((t_4(l_1_struct, flatten_nested_kind=True), 'DataView', ))
            l_1_data_type = t_4(l_1_struct, flatten_nested_kind=True, internal=True)
            t_18.extend((
                '\n  ::mojo::Message mojolpm_message(0, 0, 0, 0, nullptr);\n  ::mojo::internal::MessageFragment<',
                to_string((undefined(name='data_type') if l_1_data_type is missing else l_1_data_type)),
                '> mojolpm_fragment(\n      mojolpm_message);\n  bool result = false;\n\n  ::mojo::internal::Serializer<',
                to_string((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                ', const ',
                to_string((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
                '>::Serialize(\n    input, mojolpm_fragment);\n  result = ::mojo::internal::Serializer<',
                to_string((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                ', ',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>::Deserialize(\n    mojolpm_fragment.data(), &output, &mojolpm_message);\n\n  return result;',
            ))
        elif environment.getattr(l_1_struct, 'fields'):
            pass
            t_18.append(
                '\n  bool mojolpm_result = true;',
            )
            for l_2_field in environment.getattr(l_1_struct, 'fields'):
                l_2_name = l_2_kind = l_2_field_mojom_type = l_2_field_maybe_mojom_type = missing
                pass
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                l_2_kind = environment.getattr(l_2_field, 'kind')
                l_2_field_mojom_type = t_3((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)
                l_2_field_maybe_mojom_type = t_3((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True, ignore_nullable=True)
                t_18.extend((
                    '\n  ',
                    to_string((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                    ' local_',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ';',
                ))
                if t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_18.extend((
                        '\n  ',
                        to_string((undefined(name='field_maybe_mojom_type') if l_2_field_maybe_mojom_type is missing else l_2_field_maybe_mojom_type)),
                        ' local_maybe_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';',
                    ))
            l_2_field = l_2_name = l_2_kind = l_2_field_mojom_type = l_2_field_maybe_mojom_type = missing
            for l_2_field in environment.getattr(l_1_struct, 'fields'):
                l_2_name = l_2_kind = missing
                pass
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                l_2_kind = environment.getattr(l_2_field, 'kind')
                if (not t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    t_18.extend((
                        '\n  mojolpm_result &= FromProto(input.m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(), local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');',
                    ))
                else:
                    pass
                    t_18.extend((
                        '\n  if (input.has_m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '() && FromProto(input.m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(), local_maybe_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ')) {\n    local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ' = std::move(local_maybe_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n  }',
                    ))
            l_2_field = l_2_name = l_2_kind = missing
            t_18.extend((
                '\n  if (mojolpm_result) {\n    output = ',
                to_string(t_4(l_1_struct, flatten_nested_kind=True)),
                '::New(',
            ))
            l_2_loop = missing
            for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_struct, 'fields'), undefined):
                l_2_name = missing
                pass
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                t_18.extend((
                    '\n      std::move(local_',
                    to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ')',
                    to_string((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 289 in 'mojolpm_from_proto_macros.tmpl' evaluated to false and no else section was defined."))),
                ))
            l_2_loop = l_2_field = l_2_name = missing
            t_18.append(
                ');\n  }\n\n  return mojolpm_result;',
            )
        else:
            pass
            t_18.extend((
                '\n  output = ',
                to_string(t_4(l_1_struct, flatten_nested_kind=True)),
                '::New();\n  return true;',
            ))
        t_18.extend((
            '\n}\n\nbool FromProto(\n    const ',
            to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '& input,\n    ',
            to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '& output) {\n  if (input.instance_case() == ',
            to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '::kOld) {\n    ',
            to_string((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
            '* old = mojolpm::GetContext()->GetInstance<',
            to_string((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
            '>(input.old());\n    if (old) {\n      return FromProto(*old, output);\n    }\n  } else {\n    return FromProto(input.new_(), output);\n  }\n\n  return false;\n}',
        ))
        return concat(t_18)
    context.exported_vars.add('define_struct')
    context.vars['define_struct'] = l_0_define_struct = Macro(environment, macro, 'define_struct', ('struct',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_union):
        t_19 = []
        l_1_dataview_type = resolve('dataview_type')
        l_1_data_type = resolve('data_type')
        l_1_mojom_type = l_1_proto_type = l_1_union_type = missing
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        pass
        l_1_mojom_type = t_2(l_1_union, add_same_module_namespaces=True)
        l_1_proto_type = unicode_join(('::mojolpm', t_4(l_1_union, flatten_nested_kind=True), ))
        l_1_union_type = unicode_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoUnion', ))
        t_19.extend((
            '\nbool FromProto(\n    const ',
            to_string((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
            '& input,\n    ',
            to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '& output) {',
        ))
        if t_9(l_1_union):
            pass
            l_1_dataview_type = unicode_join((t_4(l_1_union, flatten_nested_kind=True), 'DataView', ))
            l_1_data_type = t_4(l_1_union, flatten_nested_kind=True, internal=True)
            t_19.extend((
                '\n  ::mojo::Message mojolpm_message(0, 0, 0, 0, nullptr);\n  mojo::internal::MessageFragment<',
                to_string((undefined(name='data_type') if l_1_data_type is missing else l_1_data_type)),
                '> mojolpm_fragment(\n      mojolpm_message);\n\n  ::mojo::internal::Serializer<',
                to_string((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                ', const ',
                to_string((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                '>::Serialize(\n    input, mojolpm_fragment, false);\n  return ::mojo::internal::Serializer<',
                to_string((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                ', ',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>::Deserialize(\n    mojolpm_fragment.data(), &output, &mojolpm_message);',
            ))
        else:
            pass
            t_19.append(
                '\n  switch (input.union_member_case()) {',
            )
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                l_2_field_maybe_mojom_type = resolve('field_maybe_mojom_type')
                l_2_name = l_2_kind = l_2_field_mojom_type = missing
                pass
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                l_2_kind = environment.getattr(l_2_field, 'kind')
                l_2_field_mojom_type = t_3((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)
                t_19.extend((
                    '\n    case ',
                    to_string((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                    '::k',
                    to_string(t_10(unicode_join(('m_', (undefined(name='name') if l_2_name is missing else l_2_name), )))),
                    ': {',
                ))
                if t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    l_2_field_maybe_mojom_type = t_3((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True, ignore_nullable=True)
                    t_19.extend((
                        '\n      ',
                        to_string((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                        ' local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n      ',
                        to_string((undefined(name='field_maybe_mojom_type') if l_2_field_maybe_mojom_type is missing else l_2_field_maybe_mojom_type)),
                        ' maybe_local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n      if (FromProto(input.m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(), maybe_local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ')) {\n        local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ' = std::move(maybe_local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n      }\n      output = ',
                        to_string(t_4(l_1_union, flatten_nested_kind=True)),
                        '::New',
                        to_string(t_10((undefined(name='name') if l_2_name is missing else l_2_name))),
                        '(std::move(local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '));\n      return true;',
                    ))
                else:
                    pass
                    t_19.extend((
                        '\n      ',
                        to_string((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                        ' local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n      if (FromProto(input.m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(), local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ')) {\n        output = ',
                        to_string(t_4(l_1_union, flatten_nested_kind=True)),
                        '::New',
                        to_string(t_10((undefined(name='name') if l_2_name is missing else l_2_name))),
                        '(std::move(local_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '));\n        return true;\n      }',
                    ))
                t_19.append(
                    '\n    } break;\n',
                )
            l_2_field = l_2_name = l_2_kind = l_2_field_mojom_type = l_2_field_maybe_mojom_type = missing
            t_19.append(
                '\n    default: {\n      return false;\n    }\n  }\n\n  return false;',
            )
        t_19.extend((
            '\n}\n\nbool FromProto(\n    const ',
            to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '& input,\n    ',
            to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '& output) {\n  if (input.instance_case() == ',
            to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '::kOld) {\n    ',
            to_string((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
            '* old = mojolpm::GetContext()->GetInstance<',
            to_string((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
            '>(input.old());\n    if (old) {\n      return FromProto(*old, output);\n    }\n  } else {\n    return FromProto(input.new_(), output);\n  }\n\n  return false;\n}',
        ))
        return concat(t_19)
    context.exported_vars.add('define_union')
    context.vars['define_union'] = l_0_define_union = Macro(environment, macro, 'define_union', ('union',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=22&4=24&5=32&6=33&8=36&9=38&10=41&11=45&12=47&13=51&14=53&16=57&17=59&20=66&21=68&26=74&27=82&28=83&29=84&31=87&32=89&33=91&34=94&35=97&36=99&37=102&40=108&41=110&43=113&44=116&45=118&46=121&47=123&49=127&50=129&53=136&54=138&59=144&60=155&61=157&62=159&63=161&64=163&65=165&70=170&71=178&72=179&74=182&75=184&82=187&83=191&84=193&89=196&90=200&97=207&108=213&109=216&110=218&111=221&112=223&114=227&115=229&120=236&121=238&128=244&129=252&130=253&131=254&133=257&134=259&135=261&138=264&139=268&140=270&141=272&153=279&154=281&168=287&169=291&170=293&171=297&174=303&175=305&179=308&180=311&181=313&182=316&183=318&185=322&186=324&191=331&192=333&199=339&200=350&201=352&202=354&203=356&204=358&205=360&210=365&211=371&212=372&213=373&215=376&216=378&217=381&221=385&224=392&225=396&231=405&232=413&233=414&234=415&236=418&237=420&238=423&246=428&247=430&248=431&250=434&254=436&256=440&261=445&263=450&264=453&265=454&266=455&267=456&268=459&269=464&270=468&274=474&275=477&276=478&277=479&278=483&280=492&281=498&286=506&287=510&288=513&289=516&295=528&301=533&302=535&303=537&304=539&317=547&318=555&319=556&320=557&322=560&323=562&324=565&325=567&326=568&328=571&331=573&333=577&337=587&338=591&339=592&340=593&341=596&342=601&343=603&344=606&345=610&346=614&347=618&349=622&352=633&353=637&354=641&370=657&371=659&372=661&373=663'