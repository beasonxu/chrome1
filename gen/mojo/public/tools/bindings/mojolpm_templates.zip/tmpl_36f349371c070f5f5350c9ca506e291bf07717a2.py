from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'mojolpm.cc.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_all_extra_traits_headers = resolve('all_extra_traits_headers')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_all_enums = resolve('all_enums')
    l_0_interfaces = resolve('interfaces')
    l_0_util = l_0_from_proto = l_0_to_proto = l_0_traits_specialization = missing
    t_1 = environment.filters['camel_to_under']
    t_2 = environment.filters['cpp_wrapper_param_type']
    t_3 = environment.filters['cpp_wrapper_type']
    t_4 = environment.filters['get_qualified_name_for_kind']
    t_5 = environment.filters['indent']
    t_6 = environment.filters['is_array_kind']
    t_7 = environment.filters['is_associated_kind']
    t_8 = environment.filters['is_interface_kind']
    t_9 = environment.filters['is_map_kind']
    t_10 = environment.filters['is_nullable_kind']
    t_11 = environment.filters['under_to_camel']
    pass
    yield '// Copyright 2019 The Chromium Authors. All rights reserved.\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.\n\n#include "'
    yield to_string(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-mojolpm.h"\n\n#include <functional>\n\n#include "base/bind.h"\n\n'
    for l_1_extra_traits_header in (undefined(name='all_extra_traits_headers') if l_0_all_extra_traits_headers is missing else l_0_all_extra_traits_headers):
        pass
        yield '\n#include "'
        yield to_string(l_1_extra_traits_header)
        yield '"'
    l_1_extra_traits_header = missing
    l_0_util = context.vars['util'] = environment.get_template('mojolpm_macros.tmpl', 'mojolpm.cc.tmpl')._get_default_module()
    context.exported_vars.discard('util')
    l_0_from_proto = context.vars['from_proto'] = environment.get_template('mojolpm_from_proto_macros.tmpl', 'mojolpm.cc.tmpl')._get_default_module()
    context.exported_vars.discard('from_proto')
    l_0_to_proto = context.vars['to_proto'] = environment.get_template('mojolpm_to_proto_macros.tmpl', 'mojolpm.cc.tmpl')._get_default_module()
    context.exported_vars.discard('to_proto')
    l_0_traits_specialization = context.vars['traits_specialization'] = environment.get_template('mojolpm_traits_specialization_macros.tmpl', 'mojolpm.cc.tmpl')._get_default_module()
    context.exported_vars.discard('traits_specialization')
    yield '\n\nnamespace mojo {'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        pass
        yield to_string(context.call(environment.getattr((undefined(name='traits_specialization') if l_0_traits_specialization is missing else l_0_traits_specialization), 'define_struct'), l_1_struct))
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        yield '\n'
        yield to_string(context.call(environment.getattr((undefined(name='traits_specialization') if l_0_traits_specialization is missing else l_0_traits_specialization), 'define_union'), l_1_union))
    l_1_union = missing
    yield '\n} // namespace mojo\n\nnamespace mojolpm {'
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        pass
        yield to_string(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'define_enum'), l_1_enum))
        yield to_string(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'define_enum'), l_1_enum))
    l_1_enum = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        l_1_proto_type = l_1_struct_type = missing
        pass
        l_1_proto_type = unicode_join(('::mojolpm', t_4(l_1_struct, flatten_nested_kind=True), ))
        l_1_struct_type = unicode_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoStruct', ))
        for l_2_field in environment.getattr(l_1_struct, 'fields'):
            l_2_name = l_2_kind = missing
            pass
            l_2_name = t_1(environment.getattr(l_2_field, 'name'))
            l_2_kind = environment.getattr(l_2_field, 'kind')
            if (t_6((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_9((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                pass
                yield to_string(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'define'), (undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name)))
                yield to_string(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'define'), (undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name)))
        l_2_field = l_2_name = l_2_kind = missing
        yield to_string(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'define_struct'), l_1_struct))
        yield to_string(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'define_struct'), l_1_struct))
    l_1_struct = l_1_proto_type = l_1_struct_type = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        l_1_proto_type = l_1_union_type = missing
        pass
        l_1_proto_type = unicode_join(('::mojolpm', t_4(l_1_union, flatten_nested_kind=True), ))
        l_1_union_type = unicode_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoUnion', ))
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            l_2_name = l_2_kind = missing
            pass
            l_2_name = t_1(environment.getattr(l_2_field, 'name'))
            l_2_kind = environment.getattr(l_2_field, 'kind')
            if (t_6((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_9((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                pass
                yield to_string(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'define'), (undefined(name='union_type') if l_1_union_type is missing else l_1_union_type), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name)))
                yield to_string(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'define'), (undefined(name='union_type') if l_1_union_type is missing else l_1_union_type), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name)))
        l_2_field = l_2_name = l_2_kind = missing
        yield to_string(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'define_union'), l_1_union))
        yield to_string(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'define_union'), l_1_union))
    l_1_union = l_1_proto_type = l_1_union_type = missing
    l_1_loop = missing
    for l_1_interface, l_1_loop in LoopContext((undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces), undefined):
        l_1_mojom_type = l_1_proto_type = missing
        pass
        l_1_mojom_type = t_4(l_1_interface, flatten_nested_kind=True)
        l_1_proto_type = unicode_join(('::mojolpm', t_4(l_1_interface, flatten_nested_kind=True), ))
        yield '\nclass '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'Impl : public '
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield ' {\n public:\n  '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'Impl() {\n  }'
        l_2_loop = missing
        for l_2_method, l_2_loop in LoopContext(environment.getattr(l_1_interface, 'methods'), undefined):
            pass
            yield '\n\n  void '
            yield to_string(environment.getattr(l_2_method, 'name'))
            yield '(\n'
            l_3_loop = missing
            for l_3_param, l_3_loop in LoopContext(environment.getattr(l_2_method, 'parameters'), undefined):
                l_3_name = l_3_kind = l_3_param_mojom_type = missing
                pass
                l_3_name = t_1(environment.getattr(l_3_param, 'name'))
                l_3_kind = environment.getattr(l_3_param, 'kind')
                l_3_param_mojom_type = t_2((undefined(name='kind') if l_3_kind is missing else l_3_kind), add_same_module_namespaces=True)
                yield to_string((',\n' if (not environment.getattr(l_3_loop, 'first')) else cond_expr_undefined("the inline if-expression on line 80 in 'mojolpm.cc.tmpl' evaluated to false and no else section was defined.")))
                yield '      '
                yield to_string((undefined(name='param_mojom_type') if l_3_param_mojom_type is missing else l_3_param_mojom_type))
                yield ' '
                yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
            l_3_loop = l_3_param = l_3_name = l_3_kind = l_3_param_mojom_type = missing
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                yield to_string((',\n' if environment.getattr(l_2_method, 'parameters') else cond_expr_undefined("the inline if-expression on line 83 in 'mojolpm.cc.tmpl' evaluated to false and no else section was defined.")))
                yield '    '
                yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
                yield '::'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield 'Callback callback'
            yield ') override {'
            for l_3_param in environment.getattr(l_2_method, 'parameters'):
                l_3_name = l_3_kind = missing
                pass
                l_3_name = t_1(environment.getattr(l_3_param, 'name'))
                l_3_kind = environment.getattr(l_3_param, 'kind')
                yield to_string(t_5(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'add_instance'), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name), False), 2, True))
            l_3_param = l_3_name = l_3_kind = missing
            yield '\n    mojolpmdbg("'
            yield to_string(environment.getattr(l_1_interface, 'name'))
            yield 'Impl.'
            yield to_string(environment.getattr(l_2_method, 'name'))
            yield '\\n");'
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                yield '\n    mojolpm::GetContext()->AddInstance<'
                yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
                yield '::'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield 'Callback>(std::move(callback));'
            yield '\n  }'
        l_2_loop = l_2_method = missing
        yield '\n};\n\nbool FromProto(uint32_t input,\n               ::mojo::PendingRemote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>& output) {\n  bool result = false;\n  ::mojo::Remote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>* output_ptr = nullptr;\n\n  if (input) {\n    output_ptr = mojolpm::GetContext()->GetInstance<::mojo::Remote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>>(input);\n    if (output_ptr) {\n      // TODO(markbrand): look for a cleaner way to handle this check.\n      if (!output_ptr->is_bound() || (output_ptr->internal_state()\n          && output_ptr->internal_state()->has_pending_callbacks())) {\n        // not safe to Unbind, so fail instead.\n        output_ptr = nullptr;\n      } else {\n        output = output_ptr->Unbind();\n        result = true;\n      }\n    }\n  } else {\n    auto impl = std::make_unique<'
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'Impl>();\n    auto receiver_ptr =\n      std::make_unique<::mojo::Receiver<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>>(\n        impl.get(), output.InitWithNewPipeAndPassReceiver());\n    mojolpm::GetContext()->AddInstance(std::move(impl));\n    mojolpm::GetContext()->AddInstance(std::move(receiver_ptr));\n    result = true;\n  }\n\n  return result;\n}\n\nbool ToProto(::mojo::PendingRemote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>&& input,\n             uint32_t& output) {\n  ::mojo::Remote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '> remote(std::move(input));\n  int next_id = NextId<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>();\n  output = mojolpm::GetContext()->AddInstance(next_id, std::move(remote));\n  return true;\n}\n\nbool FromProto(uint32_t input,\n               ::mojo::PendingReceiver<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>& output) {\n  ::mojo::Remote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '> remote = ::mojo::Remote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>();\n  output = remote.BindNewPipeAndPassReceiver();\n  mojolpm::GetContext()->AddInstance(input, std::move(remote));\n  return true;\n}\n\nbool ToProto(::mojo::PendingReceiver<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>&& input,\n             uint32_t& output) {\n  // This should only get called from callbacks into the fuzzer, ie from one of\n  // the XxxImpls or from a return callback. Since that is the case, we want to\n  // bind the receiver and store it.\n\n  auto impl = std::make_unique<'
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'Impl>();\n  auto receiver_ptr = std::make_unique<::mojo::Receiver<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>>(\n    impl.get(), std::move(input));\n  mojolpm::GetContext()->AddInstance(std::move(impl));\n  output = mojolpm::GetContext()->AddInstance(std::move(receiver_ptr));\n  return true;\n}\n\nbool FromProto(uint32_t input,\n               ::mojo::PendingAssociatedRemote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>& output) {\n  mojolpmdbg("PendingAssociatedRemote '
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield '\\n");\n  bool result = false;\n  ::mojo::AssociatedRemote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>* output_ptr;\n\n  if (input) {\n    output_ptr = mojolpm::GetContext()->GetInstance<::mojo::AssociatedRemote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>>(input);\n    if (output_ptr) {\n      // TODO(markbrand): look for a cleaner way to handle this check.\n      if (!output_ptr->is_bound() || (output_ptr->internal_state()\n          && output_ptr->internal_state()->has_pending_callbacks())) {\n        // not safe to Unbind, so fail instead.\n        output_ptr = nullptr;\n      } else {\n        output = output_ptr->Unbind();\n        result = true;\n      }\n    }\n  } else {\n    auto impl = std::make_unique<'
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'Impl>();\n    auto receiver_ptr = \n      std::make_unique<::mojo::AssociatedReceiver<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>>(\n        impl.get(), output.InitWithNewEndpointAndPassReceiver());\n    mojolpm::GetContext()->AddInstance(std::move(impl));\n    mojolpm::GetContext()->AddInstance(std::move(receiver_ptr));\n    result = true;\n  }\n\n  return result;\n}\n\nbool ToProto(::mojo::PendingAssociatedRemote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>&& input,\n             uint32_t& output) {\n  ::mojo::AssociatedRemote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '> remote(std::move(input));\n  int next_id = NextId<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>();\n  output = mojolpm::GetContext()->AddInstance(next_id, std::move(remote));\n  return true;\n}\n\nbool FromProto(uint32_t input,\n               ::mojo::PendingAssociatedReceiver<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>& output) {\n  ::mojo::AssociatedRemote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '> remote = ::mojo::AssociatedRemote<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>();\n  output = remote.BindNewEndpointAndPassReceiver();\n  mojolpm::GetContext()->AddInstance(input, std::move(remote));\n  return true;\n}\n\nbool ToProto(::mojo::PendingAssociatedReceiver<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>&& input,\n             uint32_t& output) {\n  // This should only get called from callbacks into the fuzzer, ie from one of\n  // the XxxImpls or from a return callback. Since that is the case, we want to\n  // bind the receiver and store it.\n\n  auto impl = std::make_unique<'
        yield to_string(environment.getattr(l_1_interface, 'name'))
        yield 'Impl>();\n  auto receiver_ptr = std::make_unique<::mojo::AssociatedReceiver<'
        yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>>(\n    impl.get(), std::move(input));\n  mojolpm::GetContext()->AddInstance(std::move(impl));\n  output = mojolpm::GetContext()->AddInstance(std::move(receiver_ptr));\n  return true;\n}\n'
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_method_type = missing
            pass
            l_2_method_type = unicode_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '::', environment.getattr(l_1_interface, 'name'), '_', environment.getattr(l_2_method, 'name'), ))
            for l_3_param in environment.getattr(l_2_method, 'parameters'):
                l_3_name = l_3_kind = missing
                pass
                l_3_name = t_1(environment.getattr(l_3_param, 'name'))
                l_3_kind = environment.getattr(l_3_param, 'kind')
                if (t_6((undefined(name='kind') if l_3_kind is missing else l_3_kind)) or t_9((undefined(name='kind') if l_3_kind is missing else l_3_kind))):
                    pass
                    yield to_string(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'define'), (undefined(name='method_type') if l_2_method_type is missing else l_2_method_type), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name)))
                    yield '\n'
                    yield to_string(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'define'), (undefined(name='method_type') if l_2_method_type is missing else l_2_method_type), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name)))
            l_3_param = l_3_name = l_3_kind = missing
        l_2_method = l_2_method_type = missing
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_method_type = resolve('method_type')
            pass
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                l_2_method_type = unicode_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '::', environment.getattr(l_1_interface, 'name'), '_', environment.getattr(l_2_method, 'name'), 'Response', ))
                for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                    l_3_name = l_3_kind = missing
                    pass
                    l_3_name = environment.getattr(l_3_param, 'name')
                    l_3_kind = environment.getattr(l_3_param, 'kind')
                    if (t_6((undefined(name='kind') if l_3_kind is missing else l_3_kind)) or t_9((undefined(name='kind') if l_3_kind is missing else l_3_kind))):
                        pass
                        yield to_string(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'define'), (undefined(name='method_type') if l_2_method_type is missing else l_2_method_type), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name)))
                        yield to_string(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'define'), (undefined(name='method_type') if l_2_method_type is missing else l_2_method_type), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name)))
                l_3_param = l_3_name = l_3_kind = missing
        l_2_method = l_2_method_type = missing
    l_1_loop = l_1_interface = l_1_mojom_type = l_1_proto_type = missing
    l_1_loop = missing
    for l_1_interface, l_1_loop in LoopContext((undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces), undefined):
        l_1_mojom_type = l_1_proto_type = missing
        pass
        l_1_mojom_type = t_4(l_1_interface, flatten_nested_kind=True)
        l_1_proto_type = unicode_join(('::mojolpm', t_4(l_1_interface, flatten_nested_kind=True), ))
        if environment.getattr(l_1_interface, 'methods'):
            pass
            yield '\nbool HandleRemoteAction(const '
            yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '::RemoteAction& input) {\n  bool result = true;\n\n  switch (input.method_case()) {'
            for l_2_method in environment.getattr(l_1_interface, 'methods'):
                pass
                yield '\n    case '
                yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
                yield '::RemoteAction::k'
                yield to_string(t_11(unicode_join(('m_', environment.getattr(l_2_method, 'name'), )), digits_split=True))
                yield ': {\n      result = HandleRemoteCall(input.id(), input.'
                yield to_string(t_1(unicode_join(('m', environment.getattr(l_2_method, 'name'), ))))
                yield '());\n    } break;'
            l_2_method = missing
            yield '\n    case '
            yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '::RemoteAction::kReset: {\n      mojolpm::GetContext()->GetAndRemoveInstance<::mojo::Remote<'
            yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
            yield '>>(input.id());\n    } break;\n\n    default: {\n      result = false;\n    }\n  }\n\n  return result;\n}\n\nbool HandleAssociatedRemoteAction(const '
            yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '::AssociatedRemoteAction& input) {\n  bool result = true;\n\n  switch (input.method_case()) {'
            for l_2_method in environment.getattr(l_1_interface, 'methods'):
                pass
                yield '\n    case '
                yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
                yield '::AssociatedRemoteAction::k'
                yield to_string(t_11(unicode_join(('m_', environment.getattr(l_2_method, 'name'), )), digits_split=True))
                yield ': {\n      result = HandleAssociatedRemoteCall(input.id(), input.'
                yield to_string(t_1(unicode_join(('m', environment.getattr(l_2_method, 'name'), ))))
                yield '());\n    } break;'
            l_2_method = missing
            yield '\n    case '
            yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '::AssociatedRemoteAction::kReset: {\n      mojolpm::GetContext()->GetAndRemoveInstance<::mojo::AssociatedRemote<'
            yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
            yield '>>(input.id());\n    } break;\n\n    default: {\n      result = false;\n    }\n  }\n\n  return result;\n}\n\nbool HandleReceiverAction(\n    const '
            yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '::ReceiverAction& input) {\n  bool result = true;\n  switch (input.response_case()) {'
            for l_2_method in environment.getattr(l_1_interface, 'methods'):
                pass
                yield '\n    case '
                yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
                yield '::ReceiverAction::k'
                yield to_string(t_11(unicode_join(('m_', environment.getattr(l_2_method, 'name'), '_response', )), digits_split=True))
                yield ': {\n      result = HandleResponse(input.id(), input.'
                yield to_string(t_1(unicode_join(('m', environment.getattr(l_2_method, 'name'), '_response', ))))
                yield '());\n    } break;'
            l_2_method = missing
            yield '\n\n    default: {\n      result = false;\n    }\n  }\n\n  return result;\n}\n'
            l_2_loop = missing
            for l_2_method, l_2_loop in LoopContext(environment.getattr(l_1_interface, 'methods'), undefined):
                pass
                if (environment.getattr(l_2_method, 'response_parameters') != None):
                    pass
                    yield '\nstatic void '
                    yield to_string(environment.getattr(l_1_interface, 'name'))
                    yield '_'
                    yield to_string(environment.getattr(l_2_method, 'name'))
                    yield 'Callback('
                    l_3_loop = missing
                    for l_3_param, l_3_loop in LoopContext(environment.getattr(l_2_method, 'response_parameters'), undefined):
                        l_3_name = l_3_kind = l_3_param_mojom_type = missing
                        pass
                        l_3_name = t_1(environment.getattr(l_3_param, 'name'))
                        l_3_kind = environment.getattr(l_3_param, 'kind')
                        l_3_param_mojom_type = t_2((undefined(name='kind') if l_3_kind is missing else l_3_kind), add_same_module_namespaces=True)
                        yield to_string((',' if (not environment.getattr(l_3_loop, 'first')) else cond_expr_undefined("the inline if-expression on line 317 in 'mojolpm.cc.tmpl' evaluated to false and no else section was defined.")))
                        yield '\n  '
                        yield to_string((undefined(name='param_mojom_type') if l_3_param_mojom_type is missing else l_3_param_mojom_type))
                        yield ' param_'
                        yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                    l_3_loop = l_3_param = l_3_name = l_3_kind = l_3_param_mojom_type = missing
                    yield ') {'
                    for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                        l_3_name = l_3_kind = missing
                        pass
                        l_3_name = t_1(environment.getattr(l_3_param, 'name'))
                        l_3_kind = environment.getattr(l_3_param, 'kind')
                        yield '\n'
                        yield to_string(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'add_instance'), (undefined(name='kind') if l_3_kind is missing else l_3_kind), unicode_join(('param_', (undefined(name='name') if l_3_name is missing else l_3_name), )), False))
                    l_3_param = l_3_name = l_3_kind = missing
                    yield '\n  mojolpmdbg("'
                    yield to_string(environment.getattr(l_1_interface, 'name'))
                    yield '.'
                    yield to_string(environment.getattr(l_2_method, 'name'))
                    yield 'Callback\\n");\n}\n'
                yield '\ntemplate <typename T>\nbool HandleCall(uint32_t instance_id,\n                      const '
                yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
                yield '::'
                yield to_string(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield '& input) {\n  T* instance =\n    mojolpm::GetContext()->GetInstance<T>(instance_id);\n  if (!instance || !instance->is_bound() || !instance->is_connected()) {\n    return false;\n  }\n\n  mojolpm::GetContext()->StartDeserialization();\n\n  bool mojolpm_result = true;'
                for l_3_param in environment.getattr(l_2_method, 'parameters'):
                    l_3_name = l_3_kind = l_3_param_mojom_type = l_3_param_maybe_mojom_type = missing
                    pass
                    l_3_name = t_1(environment.getattr(l_3_param, 'name'))
                    l_3_kind = environment.getattr(l_3_param, 'kind')
                    l_3_param_mojom_type = t_3((undefined(name='kind') if l_3_kind is missing else l_3_kind), add_same_module_namespaces=True)
                    l_3_param_maybe_mojom_type = t_3((undefined(name='kind') if l_3_kind is missing else l_3_kind), add_same_module_namespaces=True, ignore_nullable=True)
                    yield '\n  '
                    yield to_string((undefined(name='param_mojom_type') if l_3_param_mojom_type is missing else l_3_param_mojom_type))
                    yield ' local_'
                    yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                    yield ';'
                    if t_10((undefined(name='kind') if l_3_kind is missing else l_3_kind)):
                        pass
                        yield '\n  '
                        yield to_string((undefined(name='param_maybe_mojom_type') if l_3_param_maybe_mojom_type is missing else l_3_param_maybe_mojom_type))
                        yield ' local_maybe_'
                        yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                        yield ';'
                l_3_param = l_3_name = l_3_kind = l_3_param_mojom_type = l_3_param_maybe_mojom_type = missing
                for l_3_param in environment.getattr(l_2_method, 'parameters'):
                    l_3_name = l_3_kind = missing
                    pass
                    l_3_name = t_1(environment.getattr(l_3_param, 'name'))
                    l_3_kind = environment.getattr(l_3_param, 'kind')
                    if (not t_10((undefined(name='kind') if l_3_kind is missing else l_3_kind))):
                        pass
                        yield '\n  mojolpm_result &= FromProto(input.m_'
                        yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                        yield '(), local_'
                        yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                        yield ');'
                    else:
                        pass
                        yield '\n  if (FromProto(input.m_'
                        yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                        yield '(), local_maybe_'
                        yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                        yield ')) {\n    local_'
                        yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                        yield ' = std::move(local_maybe_'
                        yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                        yield ');\n  }'
                l_3_param = l_3_name = l_3_kind = missing
                yield '\n  if (mojolpm_result) {\n    (*instance)->'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield '('
                l_3_loop = missing
                for l_3_param, l_3_loop in LoopContext(environment.getattr(l_2_method, 'parameters'), undefined):
                    l_3_name = l_3_kind = missing
                    pass
                    l_3_name = t_1(environment.getattr(l_3_param, 'name'))
                    l_3_kind = environment.getattr(l_3_param, 'kind')
                    yield '\n      std::move(local_'
                    yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                    yield ')'
                    yield to_string((',' if (not environment.getattr(l_3_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 368 in 'mojolpm.cc.tmpl' evaluated to false and no else section was defined.")))
                l_3_loop = l_3_param = l_3_name = l_3_kind = missing
                if (environment.getattr(l_2_method, 'response_parameters') != None):
                    pass
                    yield to_string((',' if environment.getattr(l_2_method, 'parameters') else cond_expr_undefined("the inline if-expression on line 371 in 'mojolpm.cc.tmpl' evaluated to false and no else section was defined.")))
                    yield '\n      base::BindOnce(&'
                    yield to_string(environment.getattr(l_1_interface, 'name'))
                    yield '_'
                    yield to_string(environment.getattr(l_2_method, 'name'))
                    yield 'Callback));'
                else:
                    pass
                    yield ');'
                yield 'mojolpm::GetContext()->EndDeserialization(Context::Rollback::kNoRollback);\n  } else {\n    mojolpm::GetContext()->EndDeserialization(Context::Rollback::kRollback);\n    mojolpmdbg("call failed\\n");\n  }\n\n  return mojolpm_result;\n}\n\nbool HandleRemoteCall(\n    uint32_t instance_id, const '
                yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
                yield '::'
                yield to_string(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield '& input) {\n  mojolpmdbg("HandleRemoteCall('
                yield to_string(environment.getattr(l_1_interface, 'name'))
                yield '::'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield ')\\n");\n  return HandleCall<::mojo::Remote<'
                yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
                yield '>>(instance_id, input);\n}\n\nbool HandleAssociatedRemoteCall(\n    uint32_t instance_id, const '
                yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
                yield '::'
                yield to_string(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield '& input) {\n  mojolpmdbg("HandleAssociatedRemoteCall('
                yield to_string(environment.getattr(l_1_interface, 'name'))
                yield '::'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield ')\\n");\n  return HandleCall<::mojo::AssociatedRemote<'
                yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
                yield '>>(instance_id, input);\n}\n\nbool HandleResponse(\n    uint32_t callback_id, const '
                yield to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
                yield '::'
                yield to_string(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield 'Response& input) {\n  mojolpmdbg("HandleResponse('
                yield to_string(environment.getattr(l_1_interface, 'name'))
                yield '::'
                yield to_string(environment.getattr(l_2_method, 'name'))
                yield ')\\n");'
                if (environment.getattr(l_2_method, 'response_parameters') == None):
                    pass
                    yield '\n  return true;'
                else:
                    pass
                    yield '\n  auto mojolpm_callback = mojolpm::GetContext()->GetAndRemoveInstance<\n    '
                    yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
                    yield '::'
                    yield to_string(environment.getattr(l_2_method, 'name'))
                    yield 'Callback>(callback_id);\n\n  if (!mojolpm_callback) {\n    return true;\n  }\n\n  mojolpm::GetContext()->StartDeserialization();\n\n  bool mojolpm_result = true;'
                    for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                        l_3_name = l_3_kind = l_3_param_mojom_type = l_3_param_maybe_mojom_type = missing
                        pass
                        l_3_name = t_1(environment.getattr(l_3_param, 'name'))
                        l_3_kind = environment.getattr(l_3_param, 'kind')
                        l_3_param_mojom_type = t_3((undefined(name='kind') if l_3_kind is missing else l_3_kind), add_same_module_namespaces=True)
                        l_3_param_maybe_mojom_type = t_3((undefined(name='kind') if l_3_kind is missing else l_3_kind), add_same_module_namespaces=True, ignore_nullable=True)
                        yield '\n  '
                        yield to_string((undefined(name='param_mojom_type') if l_3_param_mojom_type is missing else l_3_param_mojom_type))
                        yield ' local_'
                        yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                        yield ';'
                        if t_10((undefined(name='kind') if l_3_kind is missing else l_3_kind)):
                            pass
                            yield '\n  '
                            yield to_string((undefined(name='param_maybe_mojom_type') if l_3_param_maybe_mojom_type is missing else l_3_param_maybe_mojom_type))
                            yield ' local_maybe_'
                            yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                            yield ';'
                    l_3_param = l_3_name = l_3_kind = l_3_param_mojom_type = l_3_param_maybe_mojom_type = missing
                    for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                        l_3_name = l_3_kind = missing
                        pass
                        l_3_name = t_1(environment.getattr(l_3_param, 'name'))
                        l_3_kind = environment.getattr(l_3_param, 'kind')
                        if (not t_10((undefined(name='kind') if l_3_kind is missing else l_3_kind))):
                            pass
                            yield '\n  mojolpm_result &= FromProto(input.m_'
                            yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                            yield '(), local_'
                            yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                            yield ');\n  mojolpmdbg("'
                            yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                            yield ' %i\\n", mojolpm_result);'
                        else:
                            pass
                            yield '\n  if (FromProto(input.m_'
                            yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                            yield '(), local_maybe_'
                            yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                            yield ')) {\n    local_'
                            yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                            yield ' = std::move(local_maybe_'
                            yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                            yield ');\n  }'
                    l_3_param = l_3_name = l_3_kind = missing
                    yield '\n  if (mojolpm_result) {\n    std::move(*mojolpm_callback).Run('
                    l_3_loop = missing
                    for l_3_param, l_3_loop in LoopContext(environment.getattr(l_2_method, 'response_parameters'), undefined):
                        l_3_name = l_3_kind = missing
                        pass
                        l_3_name = t_1(environment.getattr(l_3_param, 'name'))
                        l_3_kind = environment.getattr(l_3_param, 'kind')
                        if (t_8((undefined(name='kind') if l_3_kind is missing else l_3_kind)) or t_7((undefined(name='kind') if l_3_kind is missing else l_3_kind))):
                            pass
                            yield '\n      '
                            yield to_string(t_2((undefined(name='kind') if l_3_kind is missing else l_3_kind), add_same_module_namespaces=True))
                            yield '(std::move(local_'
                            yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                            yield '))'
                            yield to_string((',' if (not environment.getattr(l_3_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 442 in 'mojolpm.cc.tmpl' evaluated to false and no else section was defined.")))
                        else:
                            pass
                            yield '\n      std::move(local_'
                            yield to_string((undefined(name='name') if l_3_name is missing else l_3_name))
                            yield ')'
                            yield to_string((',' if (not environment.getattr(l_3_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 444 in 'mojolpm.cc.tmpl' evaluated to false and no else section was defined.")))
                    l_3_loop = l_3_param = l_3_name = l_3_kind = missing
                    yield ');\n    mojolpm::GetContext()->EndDeserialization(Context::Rollback::kNoRollback);\n  } else {\n    mojolpm::GetContext()->EndDeserialization(Context::Rollback::kRollback);\n    mojolpm::GetContext()->AddInstance<\n      '
                    yield to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
                    yield '::'
                    yield to_string(environment.getattr(l_2_method, 'name'))
                    yield 'Callback>(callback_id, std::move(*mojolpm_callback));\n  }\n\n  return mojolpm_result;'
                yield '\n}\n'
            l_2_loop = l_2_method = missing
    l_1_loop = l_1_interface = l_1_mojom_type = l_1_proto_type = missing
    yield '}  // namespace mojolpm'

blocks = {}
debug_info = '5=30&11=32&12=35&15=38&16=40&17=42&18=44&21=47&22=49&25=51&26=54&31=57&32=59&33=60&36=62&37=65&38=66&39=67&40=70&41=71&42=72&43=74&44=75&47=77&48=78&51=80&52=83&53=84&54=85&55=88&56=89&57=90&58=92&59=93&62=95&63=96&66=99&67=102&68=103&69=105&71=109&74=112&75=115&76=118&77=121&78=122&79=123&80=124&82=130&83=132&86=139&87=142&88=143&89=144&91=147&92=151&93=154&100=161&102=163&105=165&118=167&120=169&130=171&132=173&133=175&139=177&140=179&146=183&152=185&153=187&161=189&162=191&164=193&167=195&180=197&182=199&192=201&194=203&195=205&201=207&202=209&208=213&214=215&215=217&222=219&223=222&224=223&225=226&226=227&227=228&228=230&229=232&233=235&234=238&235=240&236=241&237=244&238=245&239=246&240=248&241=249&248=254&249=257&250=258&251=259&252=262&256=264&257=267&258=271&261=275&262=277&273=279&277=281&278=284&279=288&282=292&283=294&295=296&298=298&299=301&300=305&311=310&312=312&313=315&314=320&315=323&316=324&317=325&318=328&321=333&322=336&323=337&324=339&326=342&331=347&341=353&342=356&343=357&344=358&345=359&346=361&347=365&348=368&352=373&353=376&354=377&355=378&356=381&358=388&359=392&364=398&365=401&366=404&367=405&368=407&370=411&371=413&372=415&386=423&387=429&388=433&392=435&393=441&394=445&398=447&399=453&400=457&404=463&413=467&414=470&415=471&416=472&417=473&418=475&419=479&420=482&424=487&425=490&426=491&427=492&428=495&429=499&431=504&432=508&438=515&439=518&440=519&441=520&442=523&444=531&452=536'