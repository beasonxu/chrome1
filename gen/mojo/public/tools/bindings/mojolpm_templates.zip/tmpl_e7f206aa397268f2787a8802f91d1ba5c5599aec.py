from __future__ import division, generator_stop
from jinja2.runtime import LoopContext, TemplateReference, Macro, Markup, TemplateRuntimeError, missing, concat, escape, markup_join, unicode_join, to_string, identity, TemplateNotFound, Namespace, Undefined
name = 'mojolpm_to_proto_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_util = l_0_declare_array = l_0_declare_map = l_0_declare = l_0_define_array = l_0_define_map = l_0_define = l_0_define_enum = l_0_define_struct = l_0_define_union = missing
    t_1 = environment.filters['camel_to_under']
    t_2 = environment.filters['cpp_wrapper_call_type']
    t_3 = environment.filters['cpp_wrapper_param_type']
    t_4 = environment.filters['cpp_wrapper_proto_type']
    t_5 = environment.filters['cpp_wrapper_type']
    t_6 = environment.filters['get_qualified_name_for_kind']
    t_7 = environment.filters['is_any_interface_kind']
    t_8 = environment.filters['is_array_kind']
    t_9 = environment.filters['is_double_kind']
    t_10 = environment.filters['is_enum_kind']
    t_11 = environment.filters['is_float_kind']
    t_12 = environment.filters['is_integral_kind']
    t_13 = environment.filters['is_map_kind']
    t_14 = environment.filters['is_move_only_kind']
    t_15 = environment.filters['is_native_only_kind']
    t_16 = environment.filters['is_nullable_kind']
    t_17 = environment.filters['is_typemapped_kind']
    t_18 = environment.filters['nullable_is_same_kind']
    t_19 = environment.filters['under_to_camel']
    pass
    l_0_util = context.vars['util'] = environment.get_template('mojolpm_macros.tmpl', 'mojolpm_to_proto_macros.tmpl')._get_default_module()
    context.exported_vars.discard('util')
    def macro(l_1_type, l_1_kind):
        t_20 = []
        l_1_mojom_type = l_1_maybe_mojom_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_mojom_type = t_5(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True)
        l_1_maybe_mojom_type = t_5(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True, ignore_nullable=True)
        t_20.append(
            '\nbool ToProto(',
        )
        if t_14(environment.getattr(l_1_kind, 'kind')):
            pass
            t_20.extend((
                '\n  std::vector<',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>&& input,',
            ))
        else:
            pass
            t_20.extend((
                '\n  const std::vector<',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>& input,',
            ))
        t_20.extend((
            '\n  ',
            to_string(l_1_type),
            '& output);\n',
        ))
        if t_8(environment.getattr(l_1_kind, 'kind')):
            pass
            t_20.extend((
                '\n',
                to_string(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), unicode_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            ))
        elif t_13(environment.getattr(l_1_kind, 'kind')):
            pass
            t_20.extend((
                '\n',
                to_string(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), unicode_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            ))
        else:
            pass
            t_20.extend((
                '\nbool ToProto(\n  ',
                to_string((undefined(name='maybe_mojom_type') if l_1_maybe_mojom_type is missing else l_1_maybe_mojom_type)),
                ' input,\n  ',
                to_string(l_1_type),
                'Entry& output);\n',
            ))
        return concat(t_20)
    context.exported_vars.add('declare_array')
    context.vars['declare_array'] = l_0_declare_array = Macro(environment, macro, 'declare_array', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_type, l_1_kind):
        t_21 = []
        l_1_mojom_key_type = l_1_mojom_value_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_mojom_key_type = t_2(environment.getattr(l_1_kind, 'key_kind'), add_same_module_namespaces=True)
        l_1_mojom_value_type = t_2(environment.getattr(l_1_kind, 'value_kind'), add_same_module_namespaces=True)
        t_21.append(
            '\nbool ToProto(',
        )
        if (t_14(environment.getattr(l_1_kind, 'key_kind')) or t_14(environment.getattr(l_1_kind, 'value_kind'))):
            pass
            t_21.extend((
                '\n  base::flat_map<',
                to_string((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ',\n                 ',
                to_string((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                '>&& input,',
            ))
        else:
            pass
            t_21.extend((
                '\n  const base::flat_map<',
                to_string((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ',\n                 ',
                to_string((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                '>& input,',
            ))
        t_21.extend((
            '\n  ',
            to_string(l_1_type),
            '& output);\n',
        ))
        if t_8(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_21.append(
                to_string(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), unicode_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            )
        elif t_13(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_21.append(
                to_string(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), unicode_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            )
        else:
            pass
            t_21.extend((
                '\nbool ToProto(\n  ',
                to_string((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ' input,\n  ',
                to_string(l_1_type),
                'Key& output);\n',
            ))
        if t_8(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_21.append(
                to_string(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), unicode_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        elif t_13(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_21.append(
                to_string(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), unicode_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        elif t_16(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_21.extend((
                '\nbool ToProto(\n  ',
                to_string((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                ' input,\n  ',
                to_string(l_1_type),
                'Value& output);\n',
            ))
        else:
            pass
            t_21.extend((
                '\nbool ToProto(\n  ',
                to_string((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                ' input,\n  ',
                to_string(l_1_type),
                'Value& output);\n',
            ))
        return concat(t_21)
    context.exported_vars.add('declare_map')
    context.vars['declare_map'] = l_0_declare_map = Macro(environment, macro, 'declare_map', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_parent_name, l_1_kind, l_1_name):
        t_22 = []
        l_1_array_type = resolve('array_type')
        l_1_map_type = resolve('map_type')
        if l_1_parent_name is missing:
            l_1_parent_name = undefined("parameter 'parent_name' was not provided", name='parent_name')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_8(l_1_kind):
            pass
            l_1_array_type = unicode_join((l_1_parent_name, '::', t_19(l_1_name), '_Array', ))
            t_22.append(
                to_string(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), (undefined(name='array_type') if l_1_array_type is missing else l_1_array_type), l_1_kind)),
            )
        elif t_13(l_1_kind):
            pass
            l_1_map_type = unicode_join((l_1_parent_name, '::', t_19(l_1_name), '_Map', ))
            t_22.append(
                to_string(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), (undefined(name='map_type') if l_1_map_type is missing else l_1_map_type), l_1_kind)),
            )
        return concat(t_22)
    context.exported_vars.add('declare')
    context.vars['declare'] = l_0_declare = Macro(environment, macro, 'declare', ('parent_name', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_type, l_1_kind):
        t_23 = []
        l_1_maybe_const = l_1_mojom_type = l_1_maybe_mojom_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_maybe_const = ('const ' if (not t_14(environment.getattr(l_1_kind, 'kind'))) else '')
        l_1_mojom_type = t_5(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True)
        l_1_maybe_mojom_type = t_5(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True, ignore_nullable=True)
        t_23.append(
            '\nbool ToProto(',
        )
        if t_14(environment.getattr(l_1_kind, 'kind')):
            pass
            t_23.extend((
                '\n  std::vector<',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>&& input,',
            ))
        else:
            pass
            t_23.extend((
                '\n  const std::vector<',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>& input,',
            ))
        t_23.extend((
            '\n  ',
            to_string(l_1_type),
            '& output) {\n  bool result = true;\n\n  for (auto&& in_value : input) {',
        ))
        if t_16(environment.getattr(l_1_kind, 'kind')):
            pass
            t_23.extend((
                '\n    ',
                to_string(l_1_type),
                'Entry* out_value = output.mutable_values()->Add();\n    if (',
                to_string(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'not_null'), environment.getattr(l_1_kind, 'kind'), 'in_value')),
                ') {',
            ))
            if t_14(environment.getattr(l_1_kind, 'kind')):
                pass
                t_23.extend((
                    '\n      ToProto(std::move(',
                    to_string(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), environment.getattr(l_1_kind, 'kind'), 'in_value')),
                    '), *out_value);',
                ))
            else:
                pass
                t_23.extend((
                    '\n      ToProto(',
                    to_string(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), environment.getattr(l_1_kind, 'kind'), 'in_value')),
                    ', *out_value);',
                ))
            t_23.append(
                '\n    }',
            )
        else:
            pass
            t_23.extend((
                '\n    ',
                to_string(l_1_type),
                'Entry* out_value = output.mutable_values()->Add();',
            ))
            if t_14(environment.getattr(l_1_kind, 'kind')):
                pass
                t_23.extend((
                    '\n    ToProto(std::move(',
                    to_string(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), environment.getattr(l_1_kind, 'kind'), 'in_value')),
                    '), *out_value);',
                ))
            else:
                pass
                t_23.extend((
                    '\n    ToProto(',
                    to_string(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), environment.getattr(l_1_kind, 'kind'), 'in_value')),
                    ', *out_value);',
                ))
        t_23.append(
            '\n  }\n\n  return result;\n}\n',
        )
        if t_8(environment.getattr(l_1_kind, 'kind')):
            pass
            t_23.append(
                to_string(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), unicode_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            )
        elif t_13(environment.getattr(l_1_kind, 'kind')):
            pass
            t_23.append(
                to_string(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), unicode_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            )
        elif t_16(environment.getattr(l_1_kind, 'kind')):
            pass
            t_23.extend((
                '\nbool ToProto(\n    ',
                to_string((undefined(name='maybe_const') if l_1_maybe_const is missing else l_1_maybe_const)),
                to_string((undefined(name='maybe_mojom_type') if l_1_maybe_mojom_type is missing else l_1_maybe_mojom_type)),
                ' input,\n    ',
                to_string(l_1_type),
                'Entry& output) {',
            ))
            if t_14(environment.getattr(l_1_kind, 'kind')):
                pass
                t_23.append(
                    '\n  return ToProto(std::move(input), *output.mutable_value());',
                )
            else:
                pass
                t_23.append(
                    '\n  return ToProto(input, *output.mutable_value());',
                )
            t_23.append(
                '\n}\n',
            )
        else:
            pass
            t_23.extend((
                '\nbool ToProto(\n    ',
                to_string((undefined(name='maybe_const') if l_1_maybe_const is missing else l_1_maybe_const)),
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                ' input,\n    ',
                to_string(l_1_type),
                'Entry& output) {',
            ))
            if (((t_12(environment.getattr(l_1_kind, 'kind')) or t_10(environment.getattr(l_1_kind, 'kind'))) or t_11(environment.getattr(l_1_kind, 'kind'))) or t_9(environment.getattr(l_1_kind, 'kind'))):
                pass
                t_23.extend((
                    '\n  bool mojolpm_result;\n  ',
                    to_string(t_4(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True)),
                    ' value;\n  mojolpm_result = ToProto(input, value);\n  output.set_value(value);\n  return mojolpm_result;',
                ))
            elif t_7(environment.getattr(l_1_kind, 'kind')):
                pass
                t_23.extend((
                    '\n  bool mojolpm_result;\n  ',
                    to_string(t_4(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True)),
                    ' value;\n  mojolpm_result = ToProto(std::move(input), value);\n  output.set_value(value);\n  return mojolpm_result;',
                ))
            elif t_14(environment.getattr(l_1_kind, 'kind')):
                pass
                t_23.append(
                    '\n  return ToProto(std::move(input), *output.mutable_value());',
                )
            elif (t_16(environment.getattr(l_1_kind, 'kind')) and (not t_18(environment.getattr(l_1_kind, 'kind')))):
                pass
                t_23.append(
                    '\n  if (input) {\n    return ToProto(*input, *output.mutable_value());\n  } else {\n    return true;\n  }',
                )
            else:
                pass
                t_23.append(
                    '\n  return ToProto(input, *output.mutable_value());',
                )
            t_23.append(
                '\n}\n',
            )
        return concat(t_23)
    context.exported_vars.add('define_array')
    context.vars['define_array'] = l_0_define_array = Macro(environment, macro, 'define_array', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_type, l_1_kind):
        t_24 = []
        l_1_maybe_const_key = l_1_mojom_key_type = l_1_maybe_const_value = l_1_mojom_value_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_maybe_const_key = ('const ' if (not t_14(environment.getattr(l_1_kind, 'key_kind'))) else '')
        l_1_mojom_key_type = t_2(environment.getattr(l_1_kind, 'key_kind'), add_same_module_namespaces=True)
        l_1_maybe_const_value = ('const ' if (not t_14(environment.getattr(l_1_kind, 'key_kind'))) else '')
        l_1_mojom_value_type = t_2(environment.getattr(l_1_kind, 'value_kind'), add_same_module_namespaces=True)
        t_24.append(
            '\nbool ToProto(',
        )
        if (t_14(environment.getattr(l_1_kind, 'key_kind')) or t_14(environment.getattr(l_1_kind, 'value_kind'))):
            pass
            t_24.extend((
                '\n    base::flat_map<',
                to_string((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ',\n                   ',
                to_string((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                '>&& input,',
            ))
        else:
            pass
            t_24.extend((
                '\n    const base::flat_map<',
                to_string((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ',\n                         ',
                to_string((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                '>& input,',
            ))
        t_24.extend((
            '\n    ',
            to_string(l_1_type),
            '& output) {\n  bool result = true;\n\n  for (auto& in_entry : input) {\n    auto out_entry = output.mutable_values()->Add();',
        ))
        if t_14(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_24.append(
                '\n    result = ToProto(std::move(in_entry.first), *out_entry->mutable_key());',
            )
        else:
            pass
            t_24.append(
                '\n    result = ToProto(in_entry.first, *out_entry->mutable_key());',
            )
        t_24.append(
            '\n    if (!result) {\n      break;\n    }',
        )
        if t_16(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_24.extend((
                '\n    if (',
                to_string(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'not_null'), environment.getattr(l_1_kind, 'value_kind'), 'in_entry.second')),
                ') {',
            ))
            if t_14(environment.getattr(l_1_kind, 'value_kind')):
                pass
                t_24.append(
                    '\n      result = ToProto(std::move(*in_entry.second), *out_entry->mutable_value());',
                )
            else:
                pass
                t_24.append(
                    '\n      result = ToProto(*in_entry.second, *out_entry->mutable_value());',
                )
            t_24.append(
                '\n    }',
            )
        elif t_14(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_24.append(
                '\n    result = ToProto(std::move(in_entry.second), *out_entry->mutable_value());',
            )
        else:
            pass
            t_24.append(
                '\n    result = ToProto(in_entry.second, *out_entry->mutable_value());',
            )
        t_24.append(
            '\n    if (!result) {\n      break;\n    }\n  }\n\n  return result;\n}\n',
        )
        if t_8(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_24.extend((
                '\n',
                to_string(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), unicode_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            ))
        elif t_13(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_24.extend((
                '\n',
                to_string(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), unicode_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            ))
        else:
            pass
            t_24.extend((
                '\nbool ToProto(\n    ',
                to_string((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ' input,\n    ',
                to_string(l_1_type),
                'Key& output) {',
            ))
            if (((t_12(environment.getattr(l_1_kind, 'key_kind')) or t_10(environment.getattr(l_1_kind, 'key_kind'))) or t_11(environment.getattr(l_1_kind, 'key_kind'))) or t_9(environment.getattr(l_1_kind, 'key_kind'))):
                pass
                t_24.extend((
                    '\n  bool mojolpm_result;\n  ',
                    to_string(t_4(environment.getattr(l_1_kind, 'key_kind'), add_same_module_namespaces=True)),
                    ' value;\n  mojolpm_result = ToProto(input, value);\n  output.set_value(value);\n  return mojolpm_result;',
                ))
            elif t_14(environment.getattr(l_1_kind, 'key_kind')):
                pass
                t_24.append(
                    '\n  return ToProto(std::move(input), *output.mutable_value());',
                )
            elif (t_16(environment.getattr(l_1_kind, 'key_kind')) and (not t_18(environment.getattr(l_1_kind, 'key_kind')))):
                pass
                t_24.append(
                    '\n  if (input) {\n    return ToProto(*input, *output.mutable_value());\n  } else {\n    return true;\n  }',
                )
            else:
                pass
                t_24.append(
                    '\n  return ToProto(input, *output.mutable_value());',
                )
            t_24.append(
                '\n}\n',
            )
        if t_8(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_24.append(
                to_string(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), unicode_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        elif t_13(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_24.append(
                to_string(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), unicode_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        else:
            pass
            t_24.extend((
                '\nbool ToProto(\n    ',
                to_string((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                ' input,\n    ',
                to_string(l_1_type),
                'Value& output) {',
            ))
            if (((t_12(environment.getattr(l_1_kind, 'value_kind')) or t_10(environment.getattr(l_1_kind, 'value_kind'))) or t_11(environment.getattr(l_1_kind, 'value_kind'))) or t_9(environment.getattr(l_1_kind, 'value_kind'))):
                pass
                t_24.extend((
                    '\n  bool mojolpm_result;\n  ',
                    to_string(t_4(environment.getattr(l_1_kind, 'value_kind'), add_same_module_namespaces=True)),
                    ' value;\n  mojolpm_result = ToProto(input, value);\n  output.set_value(value);\n  return mojolpm_result;',
                ))
            elif t_7(environment.getattr(l_1_kind, 'value_kind')):
                pass
                t_24.extend((
                    '\n  bool mojolpm_result;\n  ',
                    to_string(t_4(environment.getattr(l_1_kind, 'value_kind'), add_same_module_namespaces=True)),
                    ' value;\n  mojolpm_result = ToProto(std::move(input), value);\n  output.set_value(value);\n  return mojolpm_result;',
                ))
            elif t_14(environment.getattr(l_1_kind, 'value_kind')):
                pass
                t_24.append(
                    '\n  return ToProto(std::move(input), *output.mutable_value());',
                )
            elif (t_16(environment.getattr(l_1_kind, 'value_kind')) and (not t_18(environment.getattr(l_1_kind, 'value_kind')))):
                pass
                t_24.append(
                    '\n  if (input) {\n    return ToProto(*input, *output.mutable_value());\n  } else {\n    return true;\n  }',
                )
            else:
                pass
                t_24.append(
                    '\n  return ToProto(input, *output.mutable_value());',
                )
            t_24.append(
                '\n}\n',
            )
        return concat(t_24)
    context.exported_vars.add('define_map')
    context.vars['define_map'] = l_0_define_map = Macro(environment, macro, 'define_map', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_parent_name, l_1_kind, l_1_name):
        t_25 = []
        l_1_array_type = resolve('array_type')
        l_1_map_type = resolve('map_type')
        if l_1_parent_name is missing:
            l_1_parent_name = undefined("parameter 'parent_name' was not provided", name='parent_name')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_8(l_1_kind):
            pass
            l_1_array_type = unicode_join((l_1_parent_name, '::', t_19(l_1_name), '_Array', ))
            t_25.append(
                to_string(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), (undefined(name='array_type') if l_1_array_type is missing else l_1_array_type), l_1_kind)),
            )
        elif t_13(l_1_kind):
            pass
            l_1_map_type = unicode_join((l_1_parent_name, '::', t_19(l_1_name), '_Map', ))
            t_25.append(
                to_string(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), (undefined(name='map_type') if l_1_map_type is missing else l_1_map_type), l_1_kind)),
            )
        return concat(t_25)
    context.exported_vars.add('define')
    context.vars['define'] = l_0_define = Macro(environment, macro, 'define', ('parent_name', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_26 = []
        l_1_mojom_type = l_1_proto_type = l_1_enum_type = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_mojom_type = t_2(l_1_enum, add_same_module_namespaces=True)
        l_1_proto_type = unicode_join(('::mojolpm', t_6(l_1_enum, flatten_nested_kind=True), ))
        l_1_enum_type = t_6(l_1_enum, flatten_nested_kind=True)
        t_26.extend((
            '\nbool ToProto(\n  const ',
            to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '& input,\n  ',
            to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '& output) {',
        ))
        if (t_15(l_1_enum) or (not t_17(l_1_enum))):
            pass
            t_26.extend((
                "\n  // This ignores IPC_PARAM_TRAITS for native IPC enums, but internal to the\n  // fuzzer we don't want the overhead of the serialization layer if we don't\n  // need it. This doesn't change the actual checks on the receiving end.\n  output = static_cast<",
                to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
                '>(input);\n  return true;',
            ))
        else:
            pass
            t_26.extend((
                '\n  output = static_cast<',
                to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
                '>(\n    mojo::EnumTraits<',
                to_string((undefined(name='enum_type') if l_1_enum_type is missing else l_1_enum_type)),
                ', ',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>::ToMojom(input));\n  return true;',
            ))
        t_26.append(
            '\n}\n',
        )
        return concat(t_26)
    context.exported_vars.add('define_enum')
    context.vars['define_enum'] = l_0_define_enum = Macro(environment, macro, 'define_enum', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_struct):
        t_27 = []
        l_1_mojom_type = l_1_proto_type = l_1_struct_type = missing
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        pass
        l_1_mojom_type = t_3(l_1_struct, add_same_module_namespaces=True)
        l_1_proto_type = unicode_join(('::mojolpm', t_6(l_1_struct, flatten_nested_kind=True), ))
        l_1_struct_type = unicode_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoStruct', ))
        t_27.extend((
            '\nbool ToProto(\n    ',
            to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            ' input,\n    ',
            to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '& output) {',
        ))
        if t_15(l_1_struct):
            pass
            t_27.extend((
                '\n  ',
                to_string((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
                '* new_instance = output.mutable_new_();\n  new_instance->mutable_native_bytes()->resize(sizeof(',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '), 0);\n  memcpy(&new_instance->mutable_native_bytes()[0], (void*)&input, sizeof(',
                to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '));\n  return true;',
            ))
        elif t_17(l_1_struct):
            pass
            t_27.append(
                '\n  // TODO(markbrand): ToProto for typemapped struct kind\n  return false;',
            )
        elif environment.getattr(l_1_struct, 'fields'):
            pass
            t_27.extend((
                '\n   ',
                to_string((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
                '* new_instance = output.mutable_new_();\n  bool mojolpm_result = true;',
            ))
            for l_2_field in environment.getattr(l_1_struct, 'fields'):
                l_2_raw_name = l_2_name = l_2_kind = missing
                pass
                l_2_raw_name = environment.getattr(l_2_field, 'name')
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                l_2_kind = environment.getattr(l_2_field, 'kind')
                if (((t_12((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_10((undefined(name='kind') if l_2_kind is missing else l_2_kind))) or t_11((undefined(name='kind') if l_2_kind is missing else l_2_kind))) or t_9((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    t_27.extend((
                        '\n  ',
                        to_string(t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)),
                        ' tmp_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n  mojolpm_result &= ToProto(input->',
                        to_string((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        ', tmp_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n  new_instance->set_m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(tmp_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');',
                    ))
                elif t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_27.extend((
                        '\n  ',
                        to_string(t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)),
                        ' tmp_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n  mojolpm_result &= ToProto(std::move(input->',
                        to_string((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        '), tmp_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n  new_instance->set_m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(tmp_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');',
                    ))
                elif t_16((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_27.extend((
                        '\n  if (',
                        to_string(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'not_null'), (undefined(name='kind') if l_2_kind is missing else l_2_kind), unicode_join(('input->', (undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name), )))),
                        ') {',
                    ))
                    if t_14((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                        pass
                        t_27.extend((
                            '\n    mojolpm_result &= ToProto(std::move(',
                            to_string(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), (undefined(name='kind') if l_2_kind is missing else l_2_kind), unicode_join(('input->', (undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name), )))),
                            '), *new_instance->mutable_m_',
                            to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '());',
                        ))
                    else:
                        pass
                        t_27.extend((
                            '\n    mojolpm_result &= ToProto(',
                            to_string(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), (undefined(name='kind') if l_2_kind is missing else l_2_kind), unicode_join(('input->', (undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name), )))),
                            ', *new_instance->mutable_m_',
                            to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '());',
                        ))
                    t_27.append(
                        '\n  }',
                    )
                elif t_14((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_27.extend((
                        '\n  mojolpm_result &= ToProto(std::move(input->',
                        to_string((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        '), *new_instance->mutable_m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '());',
                    ))
                else:
                    pass
                    t_27.extend((
                        '\n  mojolpm_result &= ToProto(input->',
                        to_string((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        ', *new_instance->mutable_m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '());',
                    ))
            l_2_field = l_2_raw_name = l_2_name = l_2_kind = missing
            t_27.append(
                '\n  return mojolpm_result;',
            )
        else:
            pass
            t_27.append(
                '\n  output.new_();\n  return true;',
            )
        t_27.append(
            '\n}\n',
        )
        return concat(t_27)
    context.exported_vars.add('define_struct')
    context.vars['define_struct'] = l_0_define_struct = Macro(environment, macro, 'define_struct', ('struct',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_union):
        t_28 = []
        l_1_enum_name = resolve('enum_name')
        l_1_mojom_type = l_1_proto_type = l_1_union_type = missing
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        pass
        l_1_mojom_type = t_3(l_1_union, add_same_module_namespaces=True)
        l_1_proto_type = unicode_join(('::mojolpm', t_6(l_1_union, flatten_nested_kind=True), ))
        l_1_union_type = unicode_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoUnion', ))
        t_28.extend((
            '\nbool ToProto(\n    ',
            to_string((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            ' input,\n    ',
            to_string((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '& output) {',
        ))
        if t_17(l_1_union):
            pass
            t_28.append(
                '\n  // TODO(markbrand): ToProto for typemapped union kind.\n  return false;',
            )
        else:
            pass
            l_1_enum_name = unicode_join((t_6(l_1_union, flatten_nested_kind=True, internal=True), '::', environment.getattr(l_1_union, 'name'), '_Tag', ))
            t_28.extend((
                '\n  ',
                to_string((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                '* new_instance = output.mutable_new_();\n  bool mojolpm_result = true;\n  switch (input->which()) {',
            ))
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                l_2_raw_name = l_2_name = l_2_kind = missing
                pass
                l_2_raw_name = environment.getattr(l_2_field, 'name')
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                l_2_kind = environment.getattr(l_2_field, 'kind')
                t_28.extend((
                    '\n    case ',
                    to_string((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
                    '::k',
                    to_string(t_19(environment.getattr(l_2_field, 'name'))),
                    ': {',
                ))
                if (((t_12((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_10((undefined(name='kind') if l_2_kind is missing else l_2_kind))) or t_11((undefined(name='kind') if l_2_kind is missing else l_2_kind))) or t_9((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    t_28.extend((
                        '\n  ',
                        to_string(t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)),
                        ' tmp_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n  mojolpm_result &= ToProto(input->get_',
                        to_string((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        '(), tmp_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n  new_instance->set_m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(tmp_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');',
                    ))
                elif t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_28.extend((
                        '\n  ',
                        to_string(t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)),
                        ' tmp_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n  mojolpm_result &= ToProto(std::move(input->get_',
                        to_string((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        '()), tmp_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n  new_instance->set_m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(tmp_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');',
                    ))
                elif t_16((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_28.extend((
                        '\n  if (',
                        to_string(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'not_null'), (undefined(name='kind') if l_2_kind is missing else l_2_kind), unicode_join(('input->get_', (undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name), '()', )))),
                        ') {',
                    ))
                    if t_14((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                        pass
                        t_28.extend((
                            '\n    mojolpm_result &= ToProto(std::move(',
                            to_string(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), (undefined(name='kind') if l_2_kind is missing else l_2_kind), unicode_join(('input->get_', (undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name), '()', )))),
                            '), *new_instance->mutable_m_',
                            to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '());',
                        ))
                    else:
                        pass
                        t_28.extend((
                            '\n    mojolpm_result &= ToProto(',
                            to_string(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), (undefined(name='kind') if l_2_kind is missing else l_2_kind), unicode_join(('input->get_', (undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name), '()', )))),
                            ', *new_instance->mutable_m_',
                            to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '());',
                        ))
                    t_28.append(
                        '\n  }',
                    )
                elif t_14((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_28.extend((
                        '\n  mojolpm_result &= ToProto(std::move(input->get_',
                        to_string((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        '()), *new_instance->mutable_m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '());',
                    ))
                else:
                    pass
                    t_28.extend((
                        '\n  mojolpm_result &= ToProto(input->get_',
                        to_string((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        '(), *new_instance->mutable_m_',
                        to_string((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '());',
                    ))
                t_28.append(
                    '\n    } break;',
                )
            l_2_field = l_2_raw_name = l_2_name = l_2_kind = missing
            t_28.append(
                '\n  }\n  return mojolpm_result;',
            )
        t_28.append(
            '\n}\n',
        )
        return concat(t_28)
    context.exported_vars.add('define_union')
    context.vars['define_union'] = l_0_define_union = Macro(environment, macro, 'define_union', ('union',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=31&4=33&5=41&6=42&8=46&9=50&11=57&13=62&14=65&15=69&16=71&17=75&20=81&21=83&25=89&26=97&27=98&29=102&30=106&31=108&33=115&34=117&36=122&37=125&38=128&39=130&40=133&43=139&44=141&46=144&47=147&48=149&49=152&50=154&52=158&53=160&56=167&57=169&62=175&63=186&64=188&65=190&66=192&67=194&68=196&73=201&74=209&75=210&76=211&78=215&79=219&81=226&83=231&87=234&88=238&89=240&90=243&91=247&93=254&97=264&98=267&99=271&101=278&108=284&109=287&110=289&111=292&112=294&114=298&115=301&116=304&124=321&125=324&126=327&128=331&132=334&134=338&138=341&140=346&154=362&155=370&156=371&157=372&158=373&160=377&161=381&162=383&164=390&165=392&167=397&172=400&180=413&181=417&182=420&188=433&200=446&201=450&202=452&203=456&206=462&207=464&208=467&210=471&214=474&216=479&227=492&228=495&229=497&230=500&233=506&234=508&235=511&237=515&241=518&243=522&247=525&249=530&263=546&264=557&265=559&266=561&267=563&268=565&269=567&274=572&275=578&276=579&277=580&279=583&280=585&281=588&285=592&288=599&289=601&296=612&297=618&298=619&299=620&301=623&302=625&303=628&304=632&305=634&306=636&308=639&311=644&312=648&314=651&315=654&316=655&317=656&318=657&319=661&320=665&321=669&322=674&323=678&324=682&325=686&326=691&327=695&328=698&329=702&331=711&334=719&335=723&337=732&349=752&350=759&351=760&352=761&354=764&355=766&356=769&360=776&361=779&364=782&365=785&366=786&367=787&368=790&369=795&370=799&371=803&372=807&373=812&374=816&375=820&376=824&377=829&378=833&379=836&380=840&382=849&385=857&386=861&388=870'